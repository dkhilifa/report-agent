---
mode: agent
agent: MCU-Benchmark-Agent
description: "Run a full autonomous benchmark campaign from just a scenario, benchmark, or firmware name. The agent acquires missing materials, builds, debugs, measures, and reports — asking only before physical hardware programming."
---

# Autonomous Benchmark From Name

I'm giving you a benchmark scenario (it might be just a name, firmware name, board name, or partial description).

**Your job:**
1. Resolve the scenario — identify what benchmark, board, MCU, and firmware are involved.
2. Acquire any missing materials autonomously (firmware, examples, startup, linker, CMSIS, BSP, device files) from official vendor sources. Record provenance.
3. Analyze benchmark semantics and portability boundaries.
4. Create or port the target project as needed.
5. Configure and build using IAR automatically.
6. Fix build issues if clearly fixable, and rebuild.
7. Prepare debug session.
8. **Ask me only before flashing/programming/attaching to a real physical board.**
9. After I approve, continue autonomously through runtime validation and measurement extraction.
10. Assess fairness and semantic equivalence if comparison is involved.
11. Produce a structured final summary.

**My input:**
{{input}}
