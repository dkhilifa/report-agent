---
mode: agent
agent: MCU-Benchmark-Agent
description: "Port a competitor reference benchmark to an STM32 target fairly. Acquires STM32 materials autonomously, maps competitor APIs to STM32 HAL/LL equivalents while preserving semantics, and asks only before hardware programming."
---

# Port Competitor Benchmark to STM32

I have a competitor reference benchmark and I want it ported to an STM32 target platform — fairly and with exact semantic preservation.

**Your job:**
1. Identify the competitor reference benchmark and the STM32 target (board, MCU) from my input.
2. Analyze the competitor reference semantics completely.
3. Identify portability boundaries (portable vs RTOS vs competitor-vendor-specific vs build surface).
4. Acquire any missing STM32 materials autonomously (startup, linker, CMSIS, BSP, HAL/LL drivers, device descriptions, CubeMX examples). Record provenance.
5. Generate a new STM32 target project — do NOT modify the competitor reference.
6. Map competitor-vendor APIs to STM32 HAL/LL/CMSIS equivalents while preserving all benchmark-observable behaviors.
7. **Reuse the STM32 vendor baseline firmware as-is** (startup, linker, HAL, BSP, CubeMX-generated files). Integrate through application-layer code only. If a protected-surface edit is truly needed, surface it as an approval-required deviation.
8. Configure and build using IAR automatically.
9. Fix build issues if clearly fixable, and rebuild.
10. **Ask me only before flashing/programming/attaching to the STM32 board.**
11. After I approve, continue autonomously through runtime validation and measurement extraction.
12. Run semantic equivalence check and fairness review.
13. Produce a structured final summary.

**My input:**
{{input}}
