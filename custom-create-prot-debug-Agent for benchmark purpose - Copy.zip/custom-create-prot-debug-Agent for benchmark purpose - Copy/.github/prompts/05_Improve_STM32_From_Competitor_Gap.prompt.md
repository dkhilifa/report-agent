---
mode: agent
agent: MCU-Benchmark-Agent
description: "Recommend STM32 benchmark improvements based on a competitor comparison gap. Distinguishes fairness artifacts from real gaps, does not change benchmark meaning, and ranks recommendations by effort and risk."
---

# Improve STM32 Benchmark From Competitor Gap

I have an STM32 benchmark scenario plus evidence of a competitor comparison showing a gap. I want actionable STM32 improvement recommendations.

**Your job:**
1. Identify the STM32 scenario, competitor scenario, and the observed performance gap from my input.
2. Verify semantic equivalence — are both benchmarks measuring the same thing?
3. Separate the gap into:
   - **Fairness artifacts** — differences caused by unequal build settings, clocks, measurement scope, or configuration (fix these first for a fair baseline).
   - **Real capability gaps** — differences that remain after fairness normalization.
4. For fairness artifacts, recommend corrections to achieve a fair comparison baseline.
5. For real capability gaps, recommend STM32-specific improvements that:
   - Do NOT change the benchmark's meaning or observable behavior.
   - Use legitimate STM32 hardware/peripheral features (DMA, cache, ART, prefetch, memory placement, clock optimization).
   - Are achievable with the current STM32 part/board.
6. Rank each recommendation by:
   - Expected impact (high/medium/low)
   - Implementation effort (high/medium/low)
   - Risk of introducing semantic drift (high/medium/low)
7. Clearly mark any recommendation that would change benchmark semantics — these must be user-approved before implementation.
8. Produce a structured summary with gap classification, fairness corrections, ranked improvements, and implementation plan.

**My input:**
{{input}}
