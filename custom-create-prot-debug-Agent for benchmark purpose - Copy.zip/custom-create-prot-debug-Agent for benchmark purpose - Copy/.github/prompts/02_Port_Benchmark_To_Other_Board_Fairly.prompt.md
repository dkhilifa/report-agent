---
mode: agent
agent: MCU-Benchmark-Agent
description: "Port an existing benchmark from one board to another fairly, in any direction (STM32→competitor, competitor→STM32, vendor→vendor, board→board). Preserves semantics exactly, fetches missing vendor files autonomously, and asks only before flashing the target board."
---

# Port Benchmark to Another Board Fairly

I have a reference benchmark on one board and I want it ported to a different target board — fairly and with exact semantic preservation. This can be any direction (STM32→competitor, competitor→STM32, or between any vendors/boards).

**Your job:**
1. Identify the reference benchmark, source board/vendor, and target board/vendor from my input.
2. Analyze the reference benchmark semantics completely.
3. Identify portability boundaries (portable vs RTOS vs board-specific vs build surface).
4. Acquire any missing target vendor files autonomously (startup, linker, CMSIS, BSP, device descriptions). Record provenance.
5. Generate a new target project — do NOT modify the reference project.
6. Map vendor APIs to target equivalents while preserving all benchmark-observable behaviors exactly.
7. **Reuse the target vendor’s baseline firmware as-is** (startup, linker, HAL, BSP, middleware). Integrate through application-layer code only. If a protected-surface edit is truly needed, surface it as an approval-required deviation.
8. Configure and build using IAR automatically.
9. Fix build issues if clearly fixable, and rebuild.
10. **Ask me only before flashing/programming/attaching to the target board.**
11. After I approve, continue autonomously through runtime validation and measurement extraction.
12. Assess and report fairness — explicitly list all fairness-sensitive differences between source and target (optimization, clock, timer, RTOS, memory, instrumentation).
13. Produce a structured final summary including semantic equivalence status.

**My input:**
{{input}}
