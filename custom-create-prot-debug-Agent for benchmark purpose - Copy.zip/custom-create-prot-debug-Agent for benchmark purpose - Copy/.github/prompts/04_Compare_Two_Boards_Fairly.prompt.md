---
mode: agent
agent: MCU-Benchmark-Agent
description: "Compare benchmark results between two boards/platforms fairly. Checks semantic equivalence first, then reports per-metric deltas and separates real capability gaps from fairness artifacts."
---

# Compare Two Boards Fairly

I have benchmark evidence for two platforms (board A and board B). I want a fair comparison.

**Your job:**
1. Identify the two platforms, scenarios, and available evidence from my input.
2. **Check semantic equivalence first** — are both benchmarks measuring the same thing in the same way?
3. Identify all fairness-sensitive differences:
   - Optimization level and build mode
   - Clock frequency and timer source
   - RTOS wrapper and scheduling behavior
   - Memory placement, cache, DMA configuration
   - Measurement start/stop scope and instrumentation overhead
   - Interrupt/DMA/polling differences
   - Startup and initialization differences
4. For each metric, report:
   - Platform A value
   - Platform B value
   - Delta (absolute and percentage)
   - Whether the delta reflects a real capability gap or a fairness/measurement artifact
5. Separate conclusions into:
   - **Confirmed real gaps** — differences that remain after fairness normalization
   - **Fairness artifacts** — differences caused by unequal test conditions
   - **Uncertain** — differences that cannot be classified without more evidence
6. Produce a structured summary with equivalence status, per-metric comparison, and recommendations.

**My input:**
{{input}}
