---
mode: agent
agent: MCU-Benchmark-Agent
description: "Port an STM32 reference benchmark to a competitor target fairly. Acquires target vendor files autonomously, maps APIs to target equivalents while preserving semantics, and asks only before hardware programming."
---

# Port STM32 Benchmark to Competitor

I have an STM32 reference benchmark and I want it ported to a competitor target platform — fairly and with exact semantic preservation.

**Your job:**
1. Identify the STM32 reference benchmark and the competitor target (board, MCU, vendor) from my input.
2. Analyze the STM32 reference semantics completely.
3. Identify portability boundaries (portable vs RTOS/CMSIS-RTOS2 vs STM32 HAL/BSP vs build surface).
4. Acquire any missing competitor vendor files autonomously (startup, linker, CMSIS, BSP, device descriptions, SDK examples). Record provenance.
5. Generate a new target project — do NOT modify the STM32 reference.
6. Map STM32 HAL/LL/CMSIS calls to competitor-native equivalents while preserving all benchmark-observable behaviors.
7. **Reuse the competitor’s vendor baseline firmware as-is** (startup, linker, HAL, BSP). Integrate through application-layer code only. If a protected-surface edit is truly needed, surface it as an approval-required deviation.
8. Configure and build using IAR automatically.
9. Fix build issues if clearly fixable, and rebuild.
10. **Ask me only before flashing/programming/attaching to the competitor board.**
11. After I approve, continue autonomously through runtime validation and measurement extraction.
12. Run semantic equivalence check and fairness review.
13. Produce a structured final summary.

**My input:**
{{input}}
