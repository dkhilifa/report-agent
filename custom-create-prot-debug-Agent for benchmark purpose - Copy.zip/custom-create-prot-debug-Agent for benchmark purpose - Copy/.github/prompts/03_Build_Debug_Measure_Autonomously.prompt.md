---
mode: agent
agent: MCU-Benchmark-Agent
description: "Build, debug, and measure an existing benchmark project autonomously using IAR. Fixes build/config issues if possible, asks only before physical board programming, and extracts measurements."
---

# Build, Debug, and Measure Autonomously

I have an existing benchmark project. I want you to build it, debug it if needed, and extract measurements — all autonomously.

**Your job:**
1. Locate and inspect the project (.ewp/.eww files, configuration).
2. Verify IAR binaries are available.
3. Check project consistency (startup, linker, device, debugger, includes, defines).
4. Run the build using IarBuild.exe.
5. If the build fails with project-configuration issues, fix them and rebuild (up to 3 iterations).
6. If the build fails with source-logic issues, report findings and stop.
7. Prepare the debug session.
8. **Ask me only before flashing/programming/attaching to a real physical board.**
9. After I approve, continue autonomously through the debug session.
10. Extract measurements from runtime output, UART logs, or debugger captures.
11. Report build settings that affect fairness (optimization, FPU, debug info).
12. Produce a structured summary with commands executed, build status, measurements, and any unresolved issues.

**My input:**
{{input}}
