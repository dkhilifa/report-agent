---
mode: agent
agent: MCU-Benchmark-Agent
description: "Port a benchmark between two non-ST vendors (e.g., NXP→Renesas, GD32→TI) fairly. Acquires target vendor files, maps APIs while preserving semantics, and asks only before hardware programming."
---

# Port Benchmark Between Vendors

I have a reference benchmark on one vendor's platform and I want it ported to a different vendor's platform — fairly and with exact semantic preservation. Neither platform is necessarily STM32.

**Your job:**
1. Identify the reference benchmark, source vendor/board, and target vendor/board from my input.
2. Analyze the reference benchmark semantics completely.
3. Identify portability boundaries (portable vs RTOS vs vendor-specific vs build surface).
4. Acquire any missing target vendor files autonomously (startup, linker, CMSIS, BSP, device descriptions, SDK examples). Record provenance.
5. Generate a new target project — do NOT modify the reference project.
6. Map source vendor APIs to target vendor equivalents while preserving all benchmark-observable behaviors.
7. **Reuse the target vendor’s baseline firmware as-is** (startup, linker, HAL, BSP, middleware). Integrate through application-layer code only. If a protected-surface edit is truly needed, surface it as an approval-required deviation.
8. Configure and build using IAR automatically.
9. Fix build issues if clearly fixable, and rebuild.
10. **Ask me only before flashing/programming/attaching to the target board.**
11. After I approve, continue autonomously through runtime validation and measurement extraction.
12. Run semantic equivalence check and fairness review.
13. Produce a structured final summary.

**My input:**
{{input}}
