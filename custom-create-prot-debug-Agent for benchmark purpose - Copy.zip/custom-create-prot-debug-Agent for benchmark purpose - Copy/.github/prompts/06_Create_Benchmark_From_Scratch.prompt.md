---
mode: agent
agent: MCU-Benchmark-Agent
description: "Create a benchmark project from scratch from only a scenario description. The agent designs the benchmark architecture, defines observable behaviors, acquires needed materials, generates all project layers, and builds — asking only before physical hardware programming."
---

# Create Benchmark Project From Scratch

I'm describing a benchmark scenario. There is no existing reference project — I want you to create one from scratch.

**Your job:**
1. Understand the scenario description and define the benchmark's observable behaviors explicitly (task structure, measurement scope, success/error conditions, output format).
2. Identify the target board/MCU/vendor from my description.
3. Acquire any needed materials autonomously (CMSIS headers, startup files, linker files, BSP, device descriptions, vendor examples for reference). Record provenance.
4. Design the project architecture with proper layer separation:
   - Portable benchmark logic (vendor-independent) — **writable, default working surface**
   - RTOS/middleware layer — **select existing vendor files, do not modify**
   - Board-specific layer (clock, pins, peripherals, startup) — **select existing vendor baseline, do not modify**
   - Build surface (IAR project, includes, defines) — **configure references freely**
5. Generate all **application-layer** project files. Reference existing vendor baseline files for board/middleware layers without modifying them. If a protected-surface edit is truly needed, surface it as an approval-required deviation.
6. Configure and build using IAR automatically.
7. Fix build issues if clearly fixable, and rebuild.
8. **Ask me only before flashing/programming/attaching to a real physical board.**
9. After I approve, continue autonomously through runtime validation and measurement extraction.
10. Produce a structured summary with the defined semantics, generated files, build status, and any unresolved unknowns.

**My scenario description:**
{{input}}
