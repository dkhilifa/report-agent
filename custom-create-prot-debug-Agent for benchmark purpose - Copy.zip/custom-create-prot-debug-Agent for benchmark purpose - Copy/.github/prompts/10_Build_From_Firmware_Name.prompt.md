---
mode: agent
agent: MCU-Benchmark-Agent
description: "Build a benchmark from only a firmware or benchmark name. The agent resolves the name, acquires the firmware from official sources, prepares the project, and builds — asking only before physical hardware programming."
---

# Build Benchmark From Firmware Name

I'm giving you only a firmware or benchmark name. I want you to find it, acquire it, prepare a buildable project, and build it.

**Your job:**
1. Resolve the firmware/benchmark name — identify what it is, which vendor/SDK it belongs to, and what board/MCU it targets.
2. Acquire the firmware and all supporting files autonomously from official sources (vendor GitHub, SDK packages, CMSIS packs). Record provenance.
3. Analyze the acquired firmware to understand its structure and semantics.
4. Set up or verify the IAR project configuration (startup, linker, device, includes, defines).
5. Build using IarBuild.exe automatically.
6. Fix build issues if clearly fixable, and rebuild.
7. **Ask me only before flashing/programming/attaching to a real physical board.**
8. After I approve, continue autonomously through runtime validation.
9. Produce a structured summary with: what was resolved, sources acquired (with provenance), build status, and any unresolved unknowns.

**My input:**
{{input}}
