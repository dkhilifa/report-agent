# MCU Benchmark Agent

**Autonomous benchmark coordinator for ARM Cortex-M — specialized for STM32 vs competitor benchmark campaigns.**

This is a VS Code custom agent system that takes a scenario description and autonomously delivers a fair, measured, verified benchmark result. It handles firmware acquisition, project creation, IAR builds, debug, measurement extraction, semantic equivalence checking, and fairness review — asking you only before programming real hardware.

---

## Quick Start

1. Open this workspace in VS Code with GitHub Copilot enabled.
2. Use the chat panel and invoke `@MCU-Benchmark-Agent` or select a prompt from `.github/prompts/`.
3. Describe your scenario — the agent handles the rest autonomously.

**Example first request:**

```
@MCU-Benchmark-Agent Build and measure the FreeRTOS task-switch benchmark on NUCLEO-U575ZI
```

The agent will resolve the scenario, acquire missing files, build using IAR, and ask you only when it's time to flash the board.

---

## Key Capabilities

| Capability | Description |
|---|---|
| **Autonomous acquisition** | Fetches firmware, CMSIS headers, BSP, startup/linker files from official vendor sources |
| **Benchmark analysis** | Extracts exact observable behaviors and portability boundaries |
| **Cross-vendor porting** | Ports benchmarks between STM32, GD32, NXP, Renesas, TI, etc. |
| **IAR build automation** | Runs IarBuild.exe autonomously with fix-and-retry loops |
| **Debug automation** | Parses logs, applies minimal fixes, runs revalidation |
| **Measurement extraction** | Captures runtime metrics from UART, debugger, or batch sessions |
| **Semantic equivalence** | Verifies that ports preserve all benchmark-observable behaviors |
| **Fairness review** | Identifies and reports fairness-sensitive differences before conclusions |
| **STM32 enhancement** | Recommends legitimate improvements when gaps are real |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────┐
│                     User                         │
└──────────────────────┬──────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────┐
│          MCU-Benchmark-Agent (coordinator)        │
│     Routes, acquires, orchestrates campaigns      │
│     Tools: web, execute, agent, read, edit        │
└──┬──────────────────┬────────────────────────┬──┘
   │                  │                        │
┌──▼────────┐  ┌──────▼───────┐  ┌────────────▼──┐
│ Creation- │  │ Build-Project │  │   Debugger    │
│ Porting   │  │              │  │               │
│ +web +exec│  │ +exec +web   │  │ +exec +web    │
└───────────┘  └──────────────┘  └───────────────┘
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
  ┌────────────┐ ┌──────────┐ ┌──────────────┐
  │ benchmark- │ │ semantic-│ │ result-      │
  │ analysis   │ │equivalence│ │interpretation│
  └────────────┘ └──────────┘ └──────────────┘
  ┌────────────┐ ┌──────────────┐
  │ stm32-     │ │ diagram-     │
  │enhancement │ │ generation   │
  └────────────┘ └──────────────┘
```

### Agents (isolated context, multi-step reasoning)

| Agent | Role |
|---|---|
| `MCU-Benchmark-Agent` | User-facing coordinator, routes to specialists, drives end-to-end campaigns |
| `Creation-Porting` | Creates new benchmarks, ports across vendors, acquires missing sources |
| `Build-Project` | Autonomous IAR project configuration and build execution |
| `Debugger` | Evidence-driven diagnosis, measurement extraction, revalidation |

### Skills (stateless checklists and workflows)

| Skill | Role |
|---|---|
| `benchmark-analysis` | Project understanding, file classification, semantics extraction |
| `semantic-equivalence` | Reference-vs-target behavior comparison and drift analysis |
| `result-interpretation` | Benchmark log, measurement, and result-file interpretation |
| `stm32-enhancement` | STM32 portability and improvement recommendations |
| `diagram-generation` | Mermaid, draw.io, and presentation diagrams |

---

## Permission Model

### Autonomous (no confirmation needed)

- Inspect, read, and search any workspace file
- Create, edit, or reorganize **application-layer** project files and source code
- Run IarBuild.exe and other local build commands
- Parse build logs, linker maps, and diagnostics
- Fix project configuration issues (includes, defines, startup, linker, device)
- Re-run build/debug loops when the issue is clearly fixable
- Fetch firmware, examples, CMSIS headers, BSP, and documentation from official vendor sources
- Run cspybat.exe in simulation/batch mode (no real hardware)
- Generate reports and summaries
- **Select and reference** existing vendor baseline files in project configuration

### Requires user approval

- **Flash or program** a physical board
- **Erase or reset** a physical device
- **Attach a live debug probe** to real hardware that changes device state
- **Modify vendor baseline file contents** (startup, linker, HAL, BSP, middleware, vendor drivers) — treated as an approval-required deviation

> After you grant one explicit board-programming approval in a session, the agent continues autonomously through the remaining flash → debug → measure → report sequence for that board.

---

## Board Firmware Baseline Immutability

The agent preserves vendor board firmware as read-only baseline infrastructure:

| Surface | Policy | Examples |
|---|---|---|
| **Application layer** | Writable (default working surface) | `main.c`, `benchmark_tasks.c`, app wrappers |
| **Middleware / RTOS** | Protected (read-only) | FreeRTOS kernel, USB stack, filesystem |
| **HAL / BSP / Startup / Linker** | Protected (read-only) | `startup_*.s`, `.icf`, `stm32xx_hal_*.c` |
| **Build surface** | Configure only | `.ewp` project references, includes, defines |

**Selection is allowed** — choosing which vendor file to reference in the project.  
**Modification is not** — editing the content of a vendor file requires explicit approval.

If a benchmark cannot be implemented at the application layer alone, the agent surfaces the need as an **approval-required deviation** and records it in `baseline_exceptions.yaml`.

---

## Deterministic Workflow

Every autonomous benchmark campaign follows this stable order:

| Step | Action | Autonomous? |
|---:|---|---|
| 1 | **Resolve scenario** — identify benchmark, board, MCU, firmware | Yes |
| 2 | **Acquire materials** — fetch from official sources, record provenance | Yes |
| 3 | **Analyze semantics** — extract behaviors, identify portability boundaries | Yes |
| 4 | **Create / port project** — generate new target (never modify reference) | Yes |
| 5 | **Configure build** — IAR project settings, startup, linker, device | Yes |
| 6 | **Build** — IarBuild.exe, classify failures, fix, rebuild | Yes |
| 7 | **Debug preparation** — parse logs, apply fixes, prepare session | Yes |
| 8 | **Hardware gate** — ask before flash / attach / reset | **Ask user** |
| 9 | **Extract measurements** — capture runtime data | Yes (after approval) |
| 10 | **Check equivalence** — verify semantic preservation | Yes |
| 11 | **Fairness review** — report all fairness-sensitive differences | Yes |
| 12 | **Report results** — structured output with provenance | Yes |

---

## Prompt-Driven Usage

Pre-built prompts are available in `.github/prompts/`. Select them from the Copilot chat prompt picker or reference them directly.

### Available Prompts

| Prompt | Purpose |
|---|---|
| `01_Autonomous_Benchmark_From_Name` | Give only a scenario/firmware name — agent does everything else |
| `02_Port_Benchmark_To_Other_Board_Fairly` | Port from source board to target board with fairness guarantee |
| `03_Build_Debug_Measure_Autonomously` | Build an existing project, debug, and extract measurements |
| `04_Compare_Two_Boards_Fairly` | Compare two platforms with semantic equivalence check first |
| `05_Improve_STM32_From_Competitor_Gap` | Recommend STM32 improvements after a measured gap |
| `06_Create_Benchmark_From_Scratch` | Create a new benchmark from a scenario description |
| `07_Port_STM32_To_Competitor` | Port STM32 reference to a competitor platform |
| `08_Port_Competitor_To_STM32` | Port competitor benchmark to STM32 |
| `09_Port_Between_Vendors` | Port between non-ST vendors (e.g., NXP → Infineon) |
| `10_Build_From_Firmware_Name` | You know only a firmware/SDK package name — agent finds and builds it |

---

## Example User Requests

Copy-paste these into the Copilot chat to get started:

```
Port STM32 USB HID benchmark to GD32E507
```

```
Download CoreMark firmware from EEMBC and prepare it for NUCLEO-U575ZI
```

```
Build and debug the GD32E507 benchmark project using IAR without asking me
```

```
Compare STM32U5 vs NXP RT1060 fairly on FreeRTOS task-switch benchmark
```

```
STM32 is 15% slower than competitor on this scenario — recommend improvements
```

```
I only have the firmware name "USB_Device_HID" — find it, port it to GD32, build it
```

---

## Fairness Philosophy

Fairness is mandatory, not optional. The agent enforces these principles:

- **Semantics matter more than vendor API names.** A port is fair when observable behavior matches, regardless of how the code is structured internally.
- **Fairness-sensitive differences must be reported explicitly** before any performance conclusions. These include:
  - Optimization level (debug vs release)
  - Clock tree and timer source
  - RTOS wrapper or scheduling differences
  - Interrupt / DMA / callback / polling differences
  - Startup and linker differences
  - Memory placement and cache configuration
  - Instrumentation and logging overhead
  - Measurement start/stop scope
- **The agent will not claim one platform is superior** based on incomplete or unfair evidence.
- **Real capability gaps are separated from fairness artifacts.** Only differences that remain after fairness normalization are reported as real.

---

## Source Acquisition Policy

When materials are missing, the agent acquires them autonomously using this preference order:

1. **Workspace files** already present
2. **Local SDK content** (IAR device/config directories, installed CMSIS packs)
3. **Official vendor GitHub repositories** (tagged releases preferred)
4. **Official vendor websites**, SDK packages, CMSIS pack index
5. **Third-party mirrors** — only as last resort

For every acquired resource, the agent records:
- Source URL
- Version / branch / tag / commit
- Package name (if applicable)
- Date of acquisition

---

## IAR Automation

The build workflow accesses IAR EWARM 9.60.3 automatically for local, non-destructive tasks.

**Known binary paths:**

| Binary | Path |
|---|---|
| IarBuild.exe | `C:\iar\ewarm-9.60.3\common\bin\IarBuild.exe` |
| iccarm.exe | `C:\iar\ewarm-9.60.3\arm\bin\iccarm.exe` |
| ilinkarm.exe | `C:\iar\ewarm-9.60.3\arm\bin\ilinkarm.exe` |
| cspybat.exe | `C:\iar\ewarm-9.60.3\common\bin\cspybat.exe` |

**Typical build command:**

```
C:\iar\ewarm-9.60.3\common\bin\IarBuild.exe "project.ewp" -make "Debug" -log all
```

The agent verifies binary existence before first use, runs builds autonomously, classifies failures, applies minimal project-level fixes when clearly justified, and rebuilds — without user intervention.

---

## Limitations / Approval Gates

The agent cannot perform these actions without your explicit approval:

| Action | Why approval is needed |
|---|---|
| Flash/program board | Changes physical device state irreversibly |
| Erase/reset device | Destroys data on physical hardware |
| Live debug probe attach | May alter device state or halt running firmware |

Everything else — including web downloads, file creation, builds, and local debug — is autonomous.

---

## Best Practices

For the best results, provide:

| Input type | How to provide |
|---|---|
| **Scenario name** | e.g., "FreeRTOS task-switch", "USB HID latency", "CoreMark" |
| **Board name** | e.g., "NUCLEO-U575ZI", "GD32E507V-EVAL" |
| **MCU name** | e.g., "STM32U575ZIT6", "GD32E507VE" |
| **Firmware name** | e.g., "USB_Device_HID", "FreeRTOS_Queues" |
| **Build logs** | Paste compiler/linker output directly into chat |
| **Runtime logs** | Paste UART output, debugger captures, or measurement data |
| **Comparison evidence** | Provide measurements for both platforms together |

You don't need all of these — the agent resolves what it can from partial input and acquires what's missing.

---

## Repository Structure

```
.github/
├── copilot-instructions.md    # Always-on benchmark rules + autonomous execution policy
├── README.md                  # This file
├── MCU_Benchmark_Agent_Presentation.html   # Marketing/use-case presentation
├── MCU_Benchmark_Agent_Technical_Overview.html  # Full technical architecture
├── agents/
│   ├── MCU-Benchmark-Agent.agent.md   # Campaign coordinator
│   ├── Creation-Porting.agent.md      # Benchmark creation & porting
│   ├── Build-Project.agent.md         # IAR build automation
│   └── Debugger.agent.md              # Debug & measurement
├── skills/
│   ├── benchmark-analysis/SKILL.md
│   ├── semantic-equivalence/SKILL.md
│   ├── result-interpretation/SKILL.md
│   ├── stm32-enhancement/SKILL.md
│   └── diagram-generation/SKILL.md
├── prompts/                           # 10 user-facing prompt templates
│   ├── 01_Autonomous_Benchmark_From_Name.prompt.md
│   ├── 02_Port_Benchmark_To_Other_Board_Fairly.prompt.md
│   ├── ...
│   └── 10_Build_From_Firmware_Name.prompt.md
├── config/
│   ├── boards.yaml            # 45 boards across 8 vendors
│   ├── mcus.yaml              # 40 MCU families
│   ├── vendors.yaml           # 8 supported vendors
│   ├── vendor_sources.yaml    # SDK download URLs / repos
│   ├── toolchains.yaml        # IAR EWARM versions & paths
│   ├── measurement_profiles.yaml  # DWT, SysTick, UART methods
│   └── reporting.yaml         # Report theme & thresholds
├── schemas/benchmark/         # 11 YAML schemas for dossier artifacts
├── templates/benchmark-dossier/  # 15 pre-filled artifact templates
├── tools/
│   ├── discover_iar.ps1       # Find IAR installations
│   ├── run_iar_build.ps1      # Build automation
│   ├── run_cspy_capture.ps1   # Debug/measurement capture
│   ├── download_vendor_source.ps1  # SDK acquisition
│   ├── normalize_build_log.py # Parse build output
│   ├── parse_map_file.py      # Extract section sizes from .map
│   ├── collect_measurements.py    # Aggregate raw measurements
│   ├── normalize_measurements.py  # Clock normalization
│   ├── compare_measurements.py    # Compute deltas
│   ├── generate_benchmark_report.py  # Self-contained HTML reports
│   └── validate_benchmark_repo.py    # Repository consistency check
├── benchmark/                 # Campaign working directories
│   ├── campaigns/   ├── analysis/   ├── ports/
│   ├── build/       ├── debug/      ├── measurements/
│   ├── comparisons/ ├── enhancements/ ├── validation/
│   ├── reports/     └── sample-comparison/ (live HTML demo)
└── docs/                      # Full documentation suite
    ├── QUICKSTART.md          # First-time usage guide
    ├── PROMPTS_GUIDE.md       # All 10 prompts explained
    ├── WORKFLOW_AND_ARTIFACTS.md  # 14-step workflow + dossier
    ├── REPORTING_GUIDE.md     # Report generation & sections
    ├── PORTING_GUIDE.md       # All porting directions
    ├── VALIDATION_GUIDE.md    # Validation script usage
    ├── NAMING_CONVENTIONS.md  # Naming rules for all artifacts
    ├── ERROR_TAXONOMY.md      # Error categories & remediation
    ├── RELEASE_CHECKLIST.md   # Pre-release verification
    └── examples/              # Copy-paste-friendly examples
```

---

## Documentation

| Document | Contents |
|---|---|
| [docs/QUICKSTART.md](docs/QUICKSTART.md) | First-time setup, prerequisites, common paths |
| [docs/PROMPTS_GUIDE.md](docs/PROMPTS_GUIDE.md) | All 10 prompts — inputs, agents invoked, expected outputs |
| [docs/WORKFLOW_AND_ARTIFACTS.md](docs/WORKFLOW_AND_ARTIFACTS.md) | 14-step deterministic workflow with dossier structure |
| [docs/REPORTING_GUIDE.md](docs/REPORTING_GUIDE.md) | Report generation, 13 sections, STM32 highlighting |
| [docs/PORTING_GUIDE.md](docs/PORTING_GUIDE.md) | All porting directions with semantic preservation rules |
| [docs/VALIDATION_GUIDE.md](docs/VALIDATION_GUIDE.md) | Validation script usage and error remediation |
| [docs/NAMING_CONVENTIONS.md](docs/NAMING_CONVENTIONS.md) | Campaign, comparison, target, artifact naming rules |
| [docs/ERROR_TAXONOMY.md](docs/ERROR_TAXONOMY.md) | Error categories, severity levels, and agent responses |
| [docs/RELEASE_CHECKLIST.md](docs/RELEASE_CHECKLIST.md) | Pre-release verification checklist |
| [MCU_Benchmark_Agent_Presentation.html](MCU_Benchmark_Agent_Presentation.html) | Self-contained user-facing presentation |
| [MCU_Benchmark_Agent_Technical_Overview.html](MCU_Benchmark_Agent_Technical_Overview.html) | Full technical architecture reference |

---

## Validation

Run the repository consistency check:

```powershell
py -3 tools/validate_benchmark_repo.py
```

This verifies board/MCU/vendor cross-references, schema integrity, template coverage, agent frontmatter, and skill naming conventions.

---

## Core Principles

- **Do not invent** vendor APIs, pin mappings, or board details.
- **Do not hide** semantic drift or fairness-impacting differences.
- **Do not claim success** without real evidence (compiler output, logs, measurements).
- **Generate new targets** — never silently modify reference projects.
- **Report unknowns** explicitly rather than masking them.
- **Separate** portable application logic, RTOS logic, and board-specific code.
