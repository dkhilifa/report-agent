#!/usr/bin/env python3
"""
compare_measurements.py - Compare normalized measurements between two platforms.

Takes two normalized measurement files and produces a comparison delta
compatible with the comparison_report.md template.

Usage:
    python compare_measurements.py <platform_a.yaml> <platform_b.yaml> [--output <delta.yaml>]

Output:
    Per-metric comparison with delta, percentage, direction, and classification hints.
"""

import sys
import argparse
from pathlib import Path


def load_normalized(path: Path) -> dict:
    """Load normalized measurements YAML (simple parser)."""
    import re

    metrics = {}
    current = None

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if "metric_name:" in line:
                match = re.search(r'"([^"]*)"', line)
                if match:
                    current = match.group(1)
                    metrics[current] = {}
            elif current and "normalized_mean:" in line:
                match = re.search(r'normalized_mean:\s*([\d.]+)', line)
                if match:
                    metrics[current]["normalized_mean"] = float(match.group(1))
            elif current and "normalized_unit:" in line:
                match = re.search(r'"([^"]*)"', line)
                if match:
                    metrics[current]["normalized_unit"] = match.group(1)
            elif current and "mean:" in line and "normalized" not in line:
                match = re.search(r'mean:\s*([\d.]+)', line)
                if match:
                    metrics[current]["raw_mean"] = float(match.group(1))
            elif current and "original_unit:" in line:
                match = re.search(r'"([^"]*)"', line)
                if match:
                    metrics[current]["original_unit"] = match.group(1)

    return metrics


def compare(metrics_a: dict, metrics_b: dict) -> list:
    """Compare two sets of metrics."""
    all_metrics = set(list(metrics_a.keys()) + list(metrics_b.keys()))
    comparisons = []

    for name in sorted(all_metrics):
        a = metrics_a.get(name, {})
        b = metrics_b.get(name, {})

        val_a = a.get("normalized_mean", None)
        val_b = b.get("normalized_mean", None)
        unit = a.get("normalized_unit") or b.get("normalized_unit", "unknown")

        comp = {
            "metric": name,
            "unit": unit,
            "platform_a": val_a,
            "platform_b": val_b,
            "delta": None,
            "delta_percent": None,
            "direction": "unknown",
            "classification": "uncertain",
        }

        if val_a is not None and val_b is not None:
            comp["delta"] = round(val_b - val_a, 3)
            if val_a != 0:
                comp["delta_percent"] = round(((val_b - val_a) / val_a) * 100, 1)
            else:
                comp["delta_percent"] = None

            # Direction: for latency/cycles, lower is better
            # For throughput, higher is better
            if "throughput" in name.lower() or "ops" in name.lower():
                comp["direction"] = "b_better" if val_b > val_a else "a_better" if val_a > val_b else "equal"
            else:
                comp["direction"] = "b_better" if val_b < val_a else "a_better" if val_a < val_b else "equal"

            # Classification hint
            abs_pct = abs(comp["delta_percent"]) if comp["delta_percent"] else 0
            if abs_pct < 2:
                comp["classification"] = "negligible"
            elif abs_pct < 10:
                comp["classification"] = "minor_gap"
            elif abs_pct < 30:
                comp["classification"] = "significant_gap"
            else:
                comp["classification"] = "major_gap"
        elif val_a is None:
            comp["classification"] = "missing_platform_a"
        elif val_b is None:
            comp["classification"] = "missing_platform_b"

        comparisons.append(comp)

    return comparisons


def format_yaml(comparisons: list, file_a: str, file_b: str) -> str:
    """Format comparison as YAML."""
    lines = [
        "# Measurement Comparison Delta",
        f"platform_a_source: \"{file_a}\"",
        f"platform_b_source: \"{file_b}\"",
        "",
        "comparisons:",
    ]

    for c in comparisons:
        lines.append(f"  - metric: \"{c['metric']}\"")
        lines.append(f"    unit: \"{c['unit']}\"")
        lines.append(f"    platform_a: {c['platform_a']}")
        lines.append(f"    platform_b: {c['platform_b']}")
        lines.append(f"    delta: {c['delta']}")
        lines.append(f"    delta_percent: {c['delta_percent']}")
        lines.append(f"    direction: \"{c['direction']}\"")
        lines.append(f"    classification: \"{c['classification']}\"")

    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="Compare measurements between platforms")
    parser.add_argument("platform_a", type=Path, help="Platform A normalized measurements")
    parser.add_argument("platform_b", type=Path, help="Platform B normalized measurements")
    parser.add_argument("--output", "-o", type=Path, help="Output YAML (default: stdout)")
    args = parser.parse_args()

    for p in [args.platform_a, args.platform_b]:
        if not p.exists():
            print(f"Error: File not found: {p}", file=sys.stderr)
            sys.exit(1)

    metrics_a = load_normalized(args.platform_a)
    metrics_b = load_normalized(args.platform_b)

    comparisons = compare(metrics_a, metrics_b)
    yaml_output = format_yaml(comparisons, str(args.platform_a), str(args.platform_b))

    if args.output:
        args.output.write_text(yaml_output, encoding="utf-8")
        print(f"Compared {len(comparisons)} metrics → {args.output}")
    else:
        print(yaml_output)


if __name__ == "__main__":
    main()
