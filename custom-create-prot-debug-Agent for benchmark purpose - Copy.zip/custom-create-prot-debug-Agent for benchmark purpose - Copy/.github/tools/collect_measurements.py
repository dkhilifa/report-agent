#!/usr/bin/env python3
"""
collect_measurements.py - Collect raw measurements from debug session output.

Parses measurement data from:
- C-SPY terminal/SWO output files
- UART capture logs
- Debugger breakpoint logs
- Manual measurement input

Produces a raw measurements YAML that can be normalized by normalize_measurements.py.

Usage:
    python collect_measurements.py <input_file> --format <format> [--output <output.yaml>]

Formats:
    uart    - UART log with "METRIC: value UNIT" lines
    swo     - SWO trace output (ITM stimulus port)
    cspy    - C-SPY terminal I/O log
    manual  - Manual YAML input (pass-through validation)

NOTE: This is a skeleton. Real measurement collection depends heavily on the
benchmark's reporting format, which varies per project.
"""

import re
import sys
import argparse
from pathlib import Path
from datetime import datetime


# Common measurement line patterns
# Format: "METRIC_NAME: 12345 cycles" or "METRIC_NAME = 12345 us"
MEASUREMENT_PATTERN = re.compile(
    r'(?P<name>[A-Za-z_][A-Za-z0-9_ ]*)\s*[:=]\s*(?P<value>[\d.]+)\s*(?P<unit>[a-zA-Z_/]+)?'
)

# DWT CYCCNT style: "[CYCCNT] start=0x00000000 stop=0x0000ABCD delta=43981"
DWT_PATTERN = re.compile(
    r'\[(?P<source>CYCCNT|TIMER)\]\s*.*delta\s*=\s*(?P<value>\d+)'
)


def parse_uart_log(path: Path) -> list:
    """Parse UART measurement log."""
    measurements = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            match = MEASUREMENT_PATTERN.match(line)
            if match:
                measurements.append({
                    "metric_name": match.group("name").strip(),
                    "raw_value": float(match.group("value")),
                    "unit": match.group("unit") or "unknown",
                    "source_line": line_num,
                    "source_text": line,
                })
                continue

            match = DWT_PATTERN.search(line)
            if match:
                measurements.append({
                    "metric_name": f"{match.group('source')}_delta",
                    "raw_value": int(match.group("value")),
                    "unit": "cycles",
                    "source_line": line_num,
                    "source_text": line,
                })

    return measurements


def parse_cspy_log(path: Path) -> list:
    """Parse C-SPY terminal output. Same heuristics as UART for now."""
    return parse_uart_log(path)


def parse_swo_log(path: Path) -> list:
    """Parse SWO/ITM trace output. Skeleton — format depends on capture tool."""
    # TODO: Implement SWO-specific parsing (ITM port data, timestamps)
    return parse_uart_log(path)  # Fallback to generic pattern matching


def parse_manual(path: Path) -> list:
    """Pass-through for manually formatted measurement YAML."""
    # Expect YAML-like format, just validate structure
    measurements = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    # Simple validation: look for metric entries
    for match in MEASUREMENT_PATTERN.finditer(content):
        measurements.append({
            "metric_name": match.group("name").strip(),
            "raw_value": float(match.group("value")),
            "unit": match.group("unit") or "unknown",
            "source_line": 0,
            "source_text": match.group(0),
        })

    return measurements


PARSERS = {
    "uart": parse_uart_log,
    "swo": parse_swo_log,
    "cspy": parse_cspy_log,
    "manual": parse_manual,
}


def format_yaml(measurements: list, source_file: str, format_type: str) -> str:
    """Format collected measurements as YAML."""
    lines = [
        "# Raw Measurements (collected)",
        f"collected_at: \"{datetime.now().isoformat()}\"",
        f"source_file: \"{source_file}\"",
        f"collection_format: \"{format_type}\"",
        f"measurement_count: {len(measurements)}",
        "",
        "measurements:",
    ]

    for m in measurements:
        lines.append(f"  - metric_name: \"{m['metric_name']}\"")
        lines.append(f"    raw_value: {m['raw_value']}")
        lines.append(f"    unit: \"{m['unit']}\"")
        lines.append(f"    source_line: {m['source_line']}")

    if not measurements:
        lines.append("  []")
        lines.append("# WARNING: No measurements extracted. Check input format.")

    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="Collect raw measurements from debug output")
    parser.add_argument("input_file", type=Path, help="Measurement source file")
    parser.add_argument("--format", "-f", required=True, choices=PARSERS.keys(),
                        help="Input format type")
    parser.add_argument("--output", "-o", type=Path, help="Output YAML (default: stdout)")
    args = parser.parse_args()

    if not args.input_file.exists():
        print(f"Error: File not found: {args.input_file}", file=sys.stderr)
        sys.exit(1)

    parse_func = PARSERS[args.format]
    measurements = parse_func(args.input_file)

    yaml_output = format_yaml(measurements, str(args.input_file), args.format)

    if args.output:
        args.output.write_text(yaml_output, encoding="utf-8")
        print(f"Collected {len(measurements)} measurements → {args.output}")
    else:
        print(yaml_output)


if __name__ == "__main__":
    main()
