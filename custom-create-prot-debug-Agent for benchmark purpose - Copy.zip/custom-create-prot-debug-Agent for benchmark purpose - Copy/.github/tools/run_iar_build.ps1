<#
.SYNOPSIS
    Runs IAR IarBuild.exe on a project file and captures structured output.

.DESCRIPTION
    Wraps IarBuild.exe execution with structured error capture, exit code handling,
    and optional log file output. Returns a build result object.

.PARAMETER ProjectFile
    Path to the .ewp project file.

.PARAMETER Configuration
    Build configuration name (e.g. "Debug", "Release").

.PARAMETER Action
    Build action: make (incremental), build (full), clean.

.PARAMETER IarRoot
    Optional explicit IAR root. If omitted, uses discover_iar.ps1.

.PARAMETER LogFile
    Optional path to write full build log.

.OUTPUTS
    PSCustomObject with: ExitCode, Errors, Warnings, LogPath, Duration, Command

.EXAMPLE
    $result = .\run_iar_build.ps1 -ProjectFile ".\project.ewp" -Configuration "Debug"
    if ($result.ExitCode -ne 0) { Write-Error "Build failed" }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$ProjectFile,

    [Parameter(Mandatory)]
    [string]$Configuration,

    [ValidateSet("make", "build", "clean")]
    [string]$Action = "make",

    [string]$IarRoot = "",
    [string]$LogFile = ""
)

$ErrorActionPreference = "Stop"

# Resolve IAR
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$iar = & "$scriptDir\discover_iar.ps1" -KnownRoot $IarRoot

if (-not $iar) {
    Write-Error "Cannot locate IAR EWARM."
    exit 1
}

# Validate project file
$projectPath = Resolve-Path $ProjectFile -ErrorAction Stop
if (-not (Test-Path $projectPath)) {
    Write-Error "Project file not found: $ProjectFile"
    exit 1
}

# Build command
$iarbuildArgs = @(
    "`"$projectPath`""
    "-$Action"
    "`"$Configuration`""
    "-log"
    "all"
)

$command = "$($iar.IarBuild) $($iarbuildArgs -join ' ')"
Write-Host "Executing: $command"

# Execute
$startTime = Get-Date
$output = & $iar.IarBuild $projectPath "-$Action" $Configuration "-log" "all" 2>&1
$exitCode = $LASTEXITCODE
$duration = (Get-Date) - $startTime

# Parse output
$outputText = $output | Out-String
$errorCount = ([regex]::Matches($outputText, "Error\[")).Count
$warningCount = ([regex]::Matches($outputText, "Warning\[")).Count

# Write log if requested
$logPath = ""
if ($LogFile) {
    $logPath = $LogFile
    $outputText | Out-File -FilePath $logPath -Encoding UTF8
} else {
    # Auto-generate log path next to project
    $logDir = Split-Path $projectPath -Parent
    $logPath = Join-Path $logDir "build_log_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
    $outputText | Out-File -FilePath $logPath -Encoding UTF8
}

$result = [PSCustomObject]@{
    ExitCode  = $exitCode
    Errors    = $errorCount
    Warnings  = $warningCount
    LogPath   = $logPath
    Duration  = $duration.TotalSeconds
    Command   = $command
    Output    = $outputText
}

if ($exitCode -ne 0) {
    Write-Warning "Build FAILED (exit code $exitCode, $errorCount errors, $warningCount warnings)"
} else {
    Write-Host "Build PASSED ($warningCount warnings) in $([math]::Round($duration.TotalSeconds, 1))s"
}

return $result
