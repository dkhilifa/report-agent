<#
.SYNOPSIS
    Downloads vendor firmware/SDK source from official repositories.

.DESCRIPTION
    Clones or downloads vendor source material based on vendor_sources.yaml configuration.
    Supports GitHub repos (clone/sparse-checkout), tagged releases, and branch checkout.
    Records provenance metadata for the campaign dossier.

.PARAMETER Vendor
    Vendor ID (e.g. "ST", "NXP", "GigaDevice", "Renesas").

.PARAMETER Repo
    Full GitHub repo path (e.g. "STMicroelectronics/STM32CubeU5").

.PARAMETER Tag
    Optional git tag or release to checkout.

.PARAMETER Branch
    Optional branch (default: main/master).

.PARAMETER OutputDir
    Directory to clone/download into.

.PARAMETER SparseCheckout
    Optional array of paths for sparse checkout (to avoid downloading entire SDK).

.OUTPUTS
    PSCustomObject with: LocalPath, Commit, Tag, Branch, AcquiredDate, ProvenanceYaml

.EXAMPLE
    .\download_vendor_source.ps1 -Vendor "ST" -Repo "STMicroelectronics/STM32CubeU5" `
        -Tag "v1.5.0" -OutputDir ".\vendor_sdk" -SparseCheckout @("Projects/NUCLEO-U575ZI-Q")
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$Vendor,

    [Parameter(Mandatory)]
    [string]$Repo,

    [string]$Tag = "",
    [string]$Branch = "",

    [Parameter(Mandatory)]
    [string]$OutputDir,

    [string[]]$SparseCheckout = @()
)

$ErrorActionPreference = "Stop"

# Validate git is available
$git = Get-Command git -ErrorAction SilentlyContinue
if (-not $git) {
    Write-Error "git is not available on PATH. Cannot clone vendor source."
    exit 1
}

$repoUrl = "https://github.com/$Repo.git"
$repoName = ($Repo -split "/")[-1]
$targetDir = Join-Path $OutputDir $repoName

Write-Host "Acquiring source: $Repo"
Write-Host "  URL: $repoUrl"
Write-Host "  Tag: $(if ($Tag) { $Tag } else { '(latest)' })"
Write-Host "  Output: $targetDir"

# Create output directory
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

# Clone
if (Test-Path $targetDir) {
    Write-Host "Directory already exists, pulling latest..."
    Push-Location $targetDir
    git fetch --tags 2>&1 | Out-Null
    Pop-Location
} else {
    if ($SparseCheckout.Count -gt 0) {
        # Sparse checkout for large repos
        git clone --filter=blob:none --sparse $repoUrl $targetDir 2>&1
        Push-Location $targetDir
        foreach ($path in $SparseCheckout) {
            git sparse-checkout add $path 2>&1
        }
        Pop-Location
    } else {
        git clone --depth 1 $(if ($Tag) { "--branch"; $Tag } elseif ($Branch) { "--branch"; $Branch }) $repoUrl $targetDir 2>&1
    }
}

# Checkout specific tag/branch if needed
if (Test-Path $targetDir) {
    Push-Location $targetDir
    if ($Tag) {
        git checkout "tags/$Tag" 2>&1 | Out-Null
    } elseif ($Branch) {
        git checkout $Branch 2>&1 | Out-Null
    }

    $commit = (git rev-parse HEAD 2>&1).Trim()
    $currentBranch = (git branch --show-current 2>&1).Trim()
    Pop-Location
} else {
    Write-Error "Clone failed. Directory does not exist: $targetDir"
    exit 1
}

$acquiredDate = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"

# Build provenance record
$provenance = @"
- resource_name: "$repoName"
  resource_type: "sdk_package"
  vendor: "$Vendor"
  url: "$repoUrl"
  repo_or_package: "$Repo"
  branch: "$currentBranch"
  tag: "$Tag"
  commit: "$commit"
  acquisition_method: "vendor_github"
  selection_reason: "Official vendor repository"
  acquired_date: "$acquiredDate"
  local_path: "$targetDir"
  provenance_verified: true
  uncertainty_notes: ""
"@

$result = [PSCustomObject]@{
    LocalPath     = $targetDir
    Commit        = $commit
    Tag           = $Tag
    Branch        = $currentBranch
    AcquiredDate  = $acquiredDate
    ProvenanceYaml = $provenance
}

Write-Host "Source acquired successfully."
Write-Host "  Commit: $commit"
Write-Host "  Date: $acquiredDate"

return $result
