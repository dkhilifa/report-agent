<#
.SYNOPSIS
    Discovers IAR EWARM installation and returns paths to key executables.

.DESCRIPTION
    Searches for IAR EWARM in known locations and validates the installation.
    Returns a hashtable with paths to IarBuild.exe, iccarm.exe, ilinkarm.exe, cspybat.exe.

.PARAMETER KnownRoot
    Optional explicit IAR installation root (e.g. "C:\iar\ewarm-9.60.3").

.OUTPUTS
    PSCustomObject with properties: Root, IarBuild, Iccarm, Ilinkarm, CspyBat, Version

.EXAMPLE
    $iar = .\discover_iar.ps1
    & $iar.IarBuild "project.ewp" -make "Debug"
#>
[CmdletBinding()]
param(
    [string]$KnownRoot = ""
)

$ErrorActionPreference = "Stop"

# Discovery order (matches .github/config/toolchains.yaml)
$searchPaths = @(
    "C:\iar\ewarm-9.60.3"
    "C:\Program Files\IAR Systems\Embedded Workbench*\arm"
    "C:\Program Files (x86)\IAR Systems\Embedded Workbench*\arm"
)

function Find-IarRoot {
    param([string]$Explicit)

    if ($Explicit -and (Test-Path $Explicit)) {
        return $Explicit
    }

    foreach ($pattern in $searchPaths) {
        $resolved = Resolve-Path -Path $pattern -ErrorAction SilentlyContinue
        if ($resolved) {
            # If pattern resolved to .../arm, go up one level
            $candidate = $resolved.Path
            if ((Split-Path $candidate -Leaf) -eq "arm") {
                $candidate = Split-Path $candidate -Parent
            }
            return $candidate
        }
    }

    return $null
}

function Validate-IarInstallation {
    param([string]$Root)

    $executables = @{
        IarBuild = Join-Path $Root "common\bin\IarBuild.exe"
        Iccarm   = Join-Path $Root "arm\bin\iccarm.exe"
        Ilinkarm = Join-Path $Root "arm\bin\ilinkarm.exe"
        CspyBat  = Join-Path $Root "common\bin\cspybat.exe"
    }

    $missing = @()
    foreach ($kvp in $executables.GetEnumerator()) {
        if (-not (Test-Path $kvp.Value)) {
            $missing += "$($kvp.Key): $($kvp.Value)"
        }
    }

    if ($missing.Count -gt 0) {
        Write-Warning "Missing executables:`n$($missing -join "`n")"
        return $null
    }

    # Attempt to read version from iccarm
    $version = "unknown"
    try {
        $output = & $executables.Iccarm --version 2>&1 | Select-Object -First 1
        if ($output -match "(\d+\.\d+\.\d+)") {
            $version = $Matches[1]
        }
    } catch {
        # Non-fatal; version remains unknown
    }

    return [PSCustomObject]@{
        Root     = $Root
        IarBuild = $executables.IarBuild
        Iccarm   = $executables.Iccarm
        Ilinkarm = $executables.Ilinkarm
        CspyBat  = $executables.CspyBat
        Version  = $version
    }
}

# Main
$root = Find-IarRoot -Explicit $KnownRoot

if (-not $root) {
    Write-Error "IAR EWARM installation not found. Searched:`n$($searchPaths -join "`n")"
    exit 1
}

$result = Validate-IarInstallation -Root $root

if (-not $result) {
    Write-Error "IAR EWARM installation at '$root' is incomplete."
    exit 1
}

Write-Host "IAR EWARM $($result.Version) found at: $($result.Root)"
return $result
