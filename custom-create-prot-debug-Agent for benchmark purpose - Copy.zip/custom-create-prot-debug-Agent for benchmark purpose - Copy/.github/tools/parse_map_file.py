#!/usr/bin/env python3
"""
parse_map_file.py - Extract memory usage from IAR linker .map files.

Parses IAR EWARM linker map files to extract:
- Flash usage (.text, .rodata, .intvec, const)
- RAM usage (.data, .bss, stack, heap)
- Per-module breakdown

Usage:
    python parse_map_file.py <map_file> [--output <output.yaml>]

Output:
    YAML with flash_bytes, ram_bytes, per-section breakdown.
"""

import re
import sys
import argparse
from pathlib import Path
from typing import Optional


# IAR map file section patterns
# Module summary table header
MODULE_SUMMARY_START = re.compile(r'^\s*Module\s+ro code\s+ro data\s+rw data', re.IGNORECASE)
# Section placement line: "sectionname  startaddr  endaddr  size  module"
PLACEMENT_LINE = re.compile(
    r'^\s*"(?P<section>[^"]+)"\s+.*\s+(?P<size>0x[0-9a-fA-F]+|[\d,]+)\s*$'
)
# Grand total line
GRAND_TOTAL = re.compile(
    r'^\s*(?P<bytes>[\d\s]+)\s+bytes of (?P<type>readonly|readwrite)\s+(?:code|data)\s+memory',
    re.IGNORECASE
)
# IAR specific summary at end of map
IAR_SUMMARY = re.compile(
    r'^\s*(?P<size>[\d\s]+)\s+bytes of (?P<memory>readonly code memory|readonly data memory|readwrite data memory)'
)


def parse_map_file(map_path: Path) -> dict:
    """Parse IAR linker .map file for memory usage."""
    result = {
        "flash_bytes": 0,
        "ram_bytes": 0,
        "readonly_code": 0,
        "readonly_data": 0,
        "readwrite_data": 0,
        "sections": [],
        "source_file": str(map_path),
    }

    with open(map_path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    # Look for IAR summary section (most reliable)
    for line in content.splitlines():
        match = IAR_SUMMARY.match(line)
        if match:
            size_str = match.group("size").replace(" ", "").strip()
            size = int(size_str) if size_str.isdigit() else 0
            memory_type = match.group("memory").lower()

            if "readonly code" in memory_type:
                result["readonly_code"] = size
            elif "readonly data" in memory_type:
                result["readonly_data"] = size
            elif "readwrite data" in memory_type:
                result["readwrite_data"] = size

    # Compute totals
    result["flash_bytes"] = result["readonly_code"] + result["readonly_data"]
    result["ram_bytes"] = result["readwrite_data"]

    # Extract per-section placement info (best-effort)
    in_placement = False
    for line in content.splitlines():
        if "PLACEMENT SUMMARY" in line.upper() or "Section" in line and "Kind" in line:
            in_placement = True
            continue
        if in_placement and line.strip() == "":
            in_placement = False
            continue
        if in_placement:
            # Try to capture section sizes
            parts = line.split()
            if len(parts) >= 3 and parts[0].startswith("."):
                section_name = parts[0]
                # Look for hex size
                for part in parts[1:]:
                    if part.startswith("0x"):
                        try:
                            size = int(part, 16)
                            result["sections"].append({
                                "name": section_name,
                                "size": size,
                            })
                        except ValueError:
                            pass
                        break

    return result


def format_yaml(result: dict) -> str:
    """Format memory usage as YAML."""
    lines = [
        "# Parsed Map File Summary",
        f"source_file: \"{result['source_file']}\"",
        "",
        "memory_usage:",
        f"  flash_bytes: {result['flash_bytes']}",
        f"  ram_bytes: {result['ram_bytes']}",
        f"  readonly_code_bytes: {result['readonly_code']}",
        f"  readonly_data_bytes: {result['readonly_data']}",
        f"  readwrite_data_bytes: {result['readwrite_data']}",
        "",
    ]

    if result["sections"]:
        lines.append("sections:")
        for sec in result["sections"]:
            lines.append(f"  - name: \"{sec['name']}\"")
            lines.append(f"    size: {sec['size']}")
    else:
        lines.append("sections: []")
        lines.append("# NOTE: Section-level parsing is best-effort for IAR map format")

    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="Parse IAR map file for memory usage")
    parser.add_argument("map_file", type=Path, help="Path to .map file")
    parser.add_argument("--output", "-o", type=Path, help="Output YAML file (default: stdout)")
    args = parser.parse_args()

    if not args.map_file.exists():
        print(f"Error: File not found: {args.map_file}", file=sys.stderr)
        sys.exit(1)

    result = parse_map_file(args.map_file)
    yaml_output = format_yaml(result)

    if args.output:
        args.output.write_text(yaml_output, encoding="utf-8")
        print(f"Written to: {args.output}")
        print(f"Flash: {result['flash_bytes']} bytes, RAM: {result['ram_bytes']} bytes")
    else:
        print(yaml_output)


if __name__ == "__main__":
    main()
