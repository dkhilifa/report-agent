<#
.SYNOPSIS
    Acquires an IAR project template from a vendor source and materializes it locally.

.DESCRIPTION
    Downloads or copies an IAR template project for a specified board from the
    configured source (GitHub repo, SDK bundle, or local SDK path). Updates the
    local template_manifest.yaml and provenance.yaml after successful acquisition.

    This script is used by the benchmark agent to materialize templates that have
    status "needs_download" in config/iar_templates.yaml.

.PARAMETER TemplateId
    The template_id from iar_templates.yaml (e.g., "st-nucleo-u575zi-q")

.PARAMETER SourceRepo
    GitHub repository in "owner/repo" format (e.g., "STMicroelectronics/STM32CubeU5")

.PARAMETER SourcePath
    Path within the repository to the template files (e.g., "Projects/NUCLEO-U575ZI-Q/Templates/EWARM")

.PARAMETER Branch
    Branch or tag to use (default: "main")

.PARAMETER OutputDir
    Local directory to place the template files. Relative to workspace root.

.PARAMETER Method
    Acquisition method: "git_sparse_checkout", "git_clone", "web_download"

.EXAMPLE
    .\acquire_iar_template.ps1 -TemplateId "st-nucleo-u575zi-q" `
        -SourceRepo "STMicroelectronics/STM32CubeU5" `
        -SourcePath "Projects/NUCLEO-U575ZI-Q/Templates/EWARM" `
        -Branch "main" `
        -OutputDir ".github/benchmark/templates/iar/st/nucleo-u575zi-q/project" `
        -Method "git_sparse_checkout"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$TemplateId,

    [Parameter(Mandatory=$true)]
    [string]$SourceRepo,

    [Parameter(Mandatory=$true)]
    [string]$SourcePath,

    [string]$Branch = "main",

    [Parameter(Mandatory=$true)]
    [string]$OutputDir,

    [ValidateSet("git_sparse_checkout", "git_clone", "web_download")]
    [string]$Method = "git_sparse_checkout"
)

$ErrorActionPreference = "Stop"

# Validate git is available
$gitExe = Get-Command git -ErrorAction SilentlyContinue
if (-not $gitExe) {
    Write-Error "git is not available on PATH. Cannot acquire template."
    exit 1
}

$repoUrl = "https://github.com/$SourceRepo.git"
$tempCloneDir = Join-Path $env:TEMP "iar_template_$($TemplateId)_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host " IAR Template Acquisition" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Template ID : $TemplateId"
Write-Host "  Source      : $repoUrl"
Write-Host "  Path        : $SourcePath"
Write-Host "  Branch      : $Branch"
Write-Host "  Output      : $OutputDir"
Write-Host "  Method      : $Method"
Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan

try {
    # Create output directory
    if (-not (Test-Path $OutputDir)) {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
        Write-Host "[+] Created output directory: $OutputDir" -ForegroundColor Green
    }

    switch ($Method) {
        "git_sparse_checkout" {
            Write-Host "[*] Using sparse checkout to fetch only template path..." -ForegroundColor Yellow

            # Initialize sparse checkout
            git clone --filter=blob:none --no-checkout --depth 1 --branch $Branch $repoUrl $tempCloneDir 2>&1
            if ($LASTEXITCODE -ne 0) { throw "git clone failed" }

            Push-Location $tempCloneDir
            try {
                git sparse-checkout init --cone 2>&1
                git sparse-checkout set $SourcePath 2>&1
                git checkout $Branch 2>&1
                if ($LASTEXITCODE -ne 0) { throw "git checkout failed" }

                # Get the commit hash
                $commitHash = git rev-parse HEAD
                Write-Host "[+] Checked out commit: $commitHash" -ForegroundColor Green

                # Copy template files to output
                $sourceFull = Join-Path $tempCloneDir $SourcePath
                if (-not (Test-Path $sourceFull)) {
                    throw "Template path not found in repo: $SourcePath"
                }

                Copy-Item -Path "$sourceFull\*" -Destination $OutputDir -Recurse -Force
                Write-Host "[+] Template files copied to: $OutputDir" -ForegroundColor Green
            }
            finally {
                Pop-Location
            }
        }

        "git_clone" {
            Write-Host "[*] Cloning full repository (shallow)..." -ForegroundColor Yellow

            git clone --depth 1 --branch $Branch $repoUrl $tempCloneDir 2>&1
            if ($LASTEXITCODE -ne 0) { throw "git clone failed" }

            $commitHash = git -C $tempCloneDir rev-parse HEAD

            $sourceFull = Join-Path $tempCloneDir $SourcePath
            if (-not (Test-Path $sourceFull)) {
                throw "Template path not found in repo: $SourcePath"
            }

            Copy-Item -Path "$sourceFull\*" -Destination $OutputDir -Recurse -Force
            Write-Host "[+] Template files copied to: $OutputDir" -ForegroundColor Green
        }

        "web_download" {
            Write-Host "[*] Web download method — downloading archive..." -ForegroundColor Yellow
            $archiveUrl = "https://github.com/$SourceRepo/archive/refs/heads/$Branch.zip"
            $archivePath = Join-Path $env:TEMP "iar_template_$TemplateId.zip"

            Invoke-WebRequest -Uri $archiveUrl -OutFile $archivePath -UseBasicParsing
            Expand-Archive -Path $archivePath -DestinationPath $tempCloneDir -Force

            # Find the extracted root (GitHub archives have a top-level folder)
            $extractedRoot = Get-ChildItem $tempCloneDir -Directory | Select-Object -First 1
            $sourceFull = Join-Path $extractedRoot.FullName $SourcePath

            if (-not (Test-Path $sourceFull)) {
                throw "Template path not found in archive: $SourcePath"
            }

            Copy-Item -Path "$sourceFull\*" -Destination $OutputDir -Recurse -Force
            $commitHash = "archive_$Branch"
            Write-Host "[+] Template files extracted to: $OutputDir" -ForegroundColor Green

            Remove-Item $archivePath -Force -ErrorAction SilentlyContinue
        }
    }

    # List acquired files
    Write-Host "`n[+] Acquired files:" -ForegroundColor Green
    Get-ChildItem -Path $OutputDir -Recurse -File | ForEach-Object {
        $relativePath = $_.FullName.Replace((Resolve-Path $OutputDir).Path + "\", "")
        Write-Host "    $relativePath"
    }

    # Output summary for agent consumption
    Write-Host "`n═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host " Acquisition Complete" -ForegroundColor Green
    Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  Template ID : $TemplateId"
    Write-Host "  Commit      : $commitHash"
    Write-Host "  Date        : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss UTC' -AsUTC)"
    Write-Host "  Files       : $((Get-ChildItem -Path $OutputDir -Recurse -File).Count)"
    Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan

    # Return structured result
    @{
        success = $true
        template_id = $TemplateId
        commit = $commitHash
        date = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssZ' -AsUTC)
        file_count = (Get-ChildItem -Path $OutputDir -Recurse -File).Count
        output_dir = $OutputDir
    } | ConvertTo-Json

}
catch {
    Write-Error "Template acquisition failed: $_"
    @{
        success = $false
        template_id = $TemplateId
        error = $_.ToString()
    } | ConvertTo-Json
    exit 1
}
finally {
    # Cleanup temp directory
    if (Test-Path $tempCloneDir) {
        Remove-Item $tempCloneDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
