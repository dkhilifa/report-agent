#!/usr/bin/env python3
"""
generate_benchmark_report.py — Generate self-contained HTML benchmark report.

Reads a report_data.yaml (or assembles from campaign artifacts) and produces
a single self-contained HTML file with embedded CSS, JS, and inline SVG charts.

Usage:
    py -3 tools/generate_benchmark_report.py <report_data.yaml> [--output <path.html>]
    py -3 tools/generate_benchmark_report.py --from-campaign <campaign_dir> [--output <path.html>]

Output:
    A single .html file suitable for local viewing without internet access.
    No external CSS, JS, fonts, or images — works offline and prints well.
"""

import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
from html import escape

# ---------------------------------------------------------------------------
# YAML parsing (minimal, no external dependency)
# ---------------------------------------------------------------------------

def _yaml_load_simple(path: Path) -> dict:
    """Minimal YAML-subset loader. Handles flat keys, lists, nested dicts."""
    import ast

    data = {}
    stack = [(data, -1)]  # (current_dict, indent_level)
    current_list_key = None
    current_list = None

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.rstrip()
            if not stripped or stripped.lstrip().startswith("#"):
                continue

            indent = len(line) - len(line.lstrip())
            content = stripped.lstrip()

            # Pop stack to matching indent
            while len(stack) > 1 and indent <= stack[-1][1]:
                stack.pop()

            current_dict = stack[-1][0]

            # List item
            if content.startswith("- "):
                item_content = content[2:].strip()
                if ":" in item_content and not item_content.startswith('"'):
                    # Dict inside list
                    key, val = item_content.split(":", 1)
                    key = key.strip().strip('"')
                    val = _parse_yaml_value(val.strip())
                    new_dict = {key: val}
                    if current_list_key and isinstance(current_dict.get(current_list_key), list):
                        current_dict[current_list_key].append(new_dict)
                        stack.append((new_dict, indent + 2))
                    else:
                        if isinstance(current_dict, dict):
                            for k in reversed(list(current_dict.keys())):
                                if isinstance(current_dict[k], list):
                                    current_dict[k].append(new_dict)
                                    stack.append((new_dict, indent + 2))
                                    break
                else:
                    # Simple list item
                    val = _parse_yaml_value(item_content)
                    if current_list_key and isinstance(current_dict.get(current_list_key), list):
                        current_dict[current_list_key].append(val)
                continue

            # Key: value
            if ":" in content:
                key, val = content.split(":", 1)
                key = key.strip().strip('"')
                val = val.strip()

                if val == "" or val == "[]":
                    # Could be dict or list
                    if val == "[]":
                        current_dict[key] = []
                        current_list_key = key
                    else:
                        # Peek ahead — assume list if next line is "- "
                        current_dict[key] = []
                        current_list_key = key
                else:
                    current_dict[key] = _parse_yaml_value(val)
                    current_list_key = key if isinstance(current_dict[key], list) else None

    return data


def _parse_yaml_value(val: str):
    """Parse a YAML scalar value."""
    if val == "true" or val == "True":
        return True
    if val == "false" or val == "False":
        return False
    if val == "null" or val == "~" or val == "":
        return ""
    # Strip quotes
    if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
        return val[1:-1]
    # Try number
    try:
        if "." in val:
            return float(val)
        return int(val)
    except (ValueError, TypeError):
        pass
    return val


def load_report_data(path: Path) -> dict:
    """Load report data YAML. Falls back to empty structure on parse issues."""
    try:
        # Try PyYAML if available
        import yaml
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        pass
    # Fallback: use json if .json
    if path.suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    # Use simple parser
    return _yaml_load_simple(path)


# ---------------------------------------------------------------------------
# Data accessors with safe defaults
# ---------------------------------------------------------------------------

def get(data: dict, *keys, default=None):
    """Safely traverse nested dict."""
    current = data
    for k in keys:
        if isinstance(current, dict):
            current = current.get(k, default)
        else:
            return default
        if current is None:
            return default
    return current


def fmt_bytes(b):
    """Format bytes with KB suffix."""
    if not b or b == 0:
        return "—"
    if abs(b) >= 1024:
        return f"{b:,} B ({b/1024:.1f} KB)"
    return f"{b:,} B"


def fmt_pct(p):
    """Format percentage."""
    if p is None or p == 0:
        return "—"
    return f"{p:+.1f}%"


def fmt_delta(d, units=""):
    """Format delta value."""
    if d is None or d == 0:
        return "—"
    s = f"{d:+,}" if isinstance(d, int) else f"{d:+,.1f}"
    if units:
        s += f" {units}"
    return s


# ---------------------------------------------------------------------------
# SVG Chart Generation
# ---------------------------------------------------------------------------

def svg_grouped_bar(data_pairs, labels, title="", width=560, height=240,
                    color_a="#0078D4", color_b="#FF6D00",
                    label_a="Platform A", label_b="Platform B", units=""):
    """Generate inline SVG grouped bar chart with value labels and legend.
    data_pairs: [(val_a, val_b), ...]
    labels: [str, ...]
    """
    if not data_pairs:
        return '<div class="no-data">No data available for chart</div>'

    max_val = max(max(abs(a) if a else 0, abs(b) if b else 0) for a, b in data_pairs)
    if max_val == 0:
        max_val = 1

    margin_left = 80
    margin_top = 36
    margin_bottom = 56
    margin_right = 20
    chart_w = width - margin_left - margin_right
    chart_h = height - margin_top - margin_bottom

    n = len(data_pairs)
    group_w = chart_w / n
    bar_w = group_w * 0.32

    lines = [f'<svg viewBox="0 0 {width} {height}" class="chart-svg" role="img" aria-label="{escape(title)}">']

    # Arrow marker
    lines.append('<defs><marker id="arrowhead" markerWidth="6" markerHeight="4" refX="5" refY="2" orient="auto"><polygon points="0 0, 6 2, 0 4" fill="#9aa0a6"/></marker></defs>')

    # Title
    if title:
        unit_suffix = f" ({units})" if units else ""
        lines.append(f'<text x="{width/2}" y="18" text-anchor="middle" class="chart-title">{escape(title)}{escape(unit_suffix)}</text>')

    # Y-axis gridlines + labels
    for i in range(5):
        y = margin_top + chart_h - (i / 4) * chart_h
        val = max_val * i / 4
        val_str = f"{int(val):,}" if val == int(val) else f"{val:,.0f}"
        lines.append(f'<line x1="{margin_left}" y1="{y}" x2="{width-margin_right}" y2="{y}" class="grid-line"/>')
        lines.append(f'<text x="{margin_left-8}" y="{y+4}" text-anchor="end" class="axis-label">{val_str}</text>')

    # Bars with value labels
    for i, ((va, vb), label) in enumerate(zip(data_pairs, labels)):
        gx = margin_left + i * group_w
        # Bar A
        if va and va > 0:
            bh = (va / max_val) * chart_h
            by = margin_top + chart_h - bh
            lines.append(f'<rect x="{gx + group_w*0.1}" y="{by}" width="{bar_w}" height="{bh}" fill="{color_a}" rx="3"/>')
            lines.append(f'<text x="{gx + group_w*0.1 + bar_w/2}" y="{by - 4}" text-anchor="middle" class="bar-value">{int(va):,}</text>')
        # Bar B
        if vb and vb > 0:
            bh = (vb / max_val) * chart_h
            by = margin_top + chart_h - bh
            bx = gx + group_w*0.1 + bar_w + 4
            lines.append(f'<rect x="{bx}" y="{by}" width="{bar_w}" height="{bh}" fill="{color_b}" rx="3"/>')
            lines.append(f'<text x="{bx + bar_w/2}" y="{by - 4}" text-anchor="middle" class="bar-value">{int(vb):,}</text>')
        # X-axis label
        lx = gx + group_w / 2
        lines.append(f'<text x="{lx}" y="{height - margin_bottom + 16}" text-anchor="middle" class="axis-label">{escape(str(label))}</text>')

    # Embedded legend
    ly = height - 12
    lx_start = width / 2 - 80
    lines.append(f'<rect x="{lx_start}" y="{ly - 8}" width="10" height="10" fill="{color_a}" rx="2"/>')
    lines.append(f'<text x="{lx_start + 14}" y="{ly}" class="axis-label">{escape(label_a)}</text>')
    lines.append(f'<rect x="{lx_start + 100}" y="{ly - 8}" width="10" height="10" fill="{color_b}" rx="2"/>')
    lines.append(f'<text x="{lx_start + 114}" y="{ly}" class="axis-label">{escape(label_b)}</text>')

    lines.append('</svg>')
    return '\n'.join(lines)


def svg_horizontal_bar(items, title="", width=560, height=None,
                       color_pos="#0078D4", color_neg="#FF6D00", units=""):
    """Horizontal bar chart for deltas with value labels.
    items: [(label, value), ...] sorted by |value|
    """
    if not items:
        return '<div class="no-data">No data available for chart</div>'

    n = len(items)
    bar_h = 26
    gap = 7
    if height is None:
        height = n * (bar_h + gap) + 56
    margin_left = 150
    margin_right = 70
    margin_top = 32
    chart_w = width - margin_left - margin_right

    max_val = max(abs(v) for _, v in items) if items else 1
    if max_val == 0:
        max_val = 1

    lines = [f'<svg viewBox="0 0 {width} {height}" class="chart-svg" role="img" aria-label="{escape(title)}">']
    if title:
        unit_suffix = f" ({units})" if units else ""
        lines.append(f'<text x="{width/2}" y="18" text-anchor="middle" class="chart-title">{escape(title)}{escape(unit_suffix)}</text>')

    for i, (label, val) in enumerate(items):
        y = margin_top + i * (bar_h + gap)
        bw = abs(val) / max_val * chart_w
        color = color_pos if val >= 0 else color_neg
        lines.append(f'<text x="{margin_left-10}" y="{y + bar_h/2 + 4}" text-anchor="end" class="axis-label">{escape(str(label)[:24])}</text>')
        lines.append(f'<rect x="{margin_left}" y="{y}" width="{bw}" height="{bar_h}" fill="{color}" rx="3" opacity="0.9"/>')
        val_str = f"{val:+,}" + (f" {units}" if units else "")
        lines.append(f'<text x="{margin_left + bw + 6}" y="{y + bar_h/2 + 4}" class="bar-value">{val_str}</text>')

    lines.append('</svg>')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Scenario Architecture Diagram — Inline SVG (self-contained HTML preview)
# ---------------------------------------------------------------------------

def svg_scenario_diagram(scenario_type="", pa_name="Platform A", pb_name="Platform B",
                         pa_is_stm32=False):
    """Generate an inline SVG diagram of the benchmark scenario architecture.

    Renders directly in the HTML — no external file needed.
    Shows the 8-step benchmark pipeline with platform cards on each side.
    """
    width = 760
    height = 400

    pipeline = [
        ("Resolve Scenario", "Identify benchmark type"),
        ("Acquire Materials", "SDK, HAL, middleware"),
        ("Create / Port Code", "Semantic equivalence"),
        ("Configure & Build", "IAR EWARM, same opts"),
        ("Debug & Validate", "Flash, breakpoints, UART"),
        ("Measure & Compare", "Footprint + timing"),
        ("Fairness Review", "Normalize differences"),
        ("Generate Report", "HTML dossier output"),
    ]

    scenario_details = {
        "rtos": ["Task creation", "Scheduler start", "Sync primitives", "Context switch"],
        "peripheral": ["Peripheral init", "DMA/IRQ setup", "Transfer cycle", "Throughput"],
        "bare_metal": ["Init sequence", "Main loop", "ISR handlers", "Cycle count"],
        "dsp": ["Filter setup", "Buffer process", "Pipeline flush", "MIPS calc"],
    }
    details = scenario_details.get(
        str(scenario_type).lower().replace("-", "_").replace(" ", "_"), [])

    pa_color = "#0078D4" if pa_is_stm32 else "#FF6D00"
    pb_color = "#FF6D00" if pa_is_stm32 else "#0078D4"

    lines = [f'<svg viewBox="0 0 {width} {height}" class="diagram-svg" role="img" '
             f'aria-label="Benchmark Scenario Architecture Diagram">']

    # Defs
    lines.append('<defs>')
    lines.append('<marker id="diag-arr" markerWidth="7" markerHeight="5" refX="6" refY="2.5" orient="auto">')
    lines.append('<polygon points="0 0, 7 2.5, 0 5" fill="#9aa0a6"/>')
    lines.append('</marker>')
    lines.append(f'<linearGradient id="gA" x1="0" y1="0" x2="0" y2="1">'
                 f'<stop offset="0%" stop-color="{pa_color}" stop-opacity="0.12"/>'
                 f'<stop offset="100%" stop-color="{pa_color}" stop-opacity="0.02"/>'
                 f'</linearGradient>')
    lines.append(f'<linearGradient id="gB" x1="0" y1="0" x2="0" y2="1">'
                 f'<stop offset="0%" stop-color="{pb_color}" stop-opacity="0.12"/>'
                 f'<stop offset="100%" stop-color="{pb_color}" stop-opacity="0.02"/>'
                 f'</linearGradient>')
    lines.append('</defs>')

    # Title
    lines.append(f'<text x="{width/2}" y="20" text-anchor="middle" '
                 f'fill="#e8eaed" font-size="13" font-weight="700" '
                 f'font-family="Segoe UI,system-ui,sans-serif">Benchmark Scenario Architecture</text>')

    # Platform A card (left)
    pa_x, pa_y, pa_w, pa_h = 10, 38, 145, 330
    lines.append(f'<rect x="{pa_x}" y="{pa_y}" width="{pa_w}" height="{pa_h}" '
                 f'rx="7" fill="url(#gA)" stroke="{pa_color}" stroke-width="1.5"/>')
    lines.append(f'<text x="{pa_x + pa_w/2}" y="{pa_y + 20}" text-anchor="middle" '
                 f'fill="{pa_color}" font-size="10" font-weight="700" '
                 f'font-family="Segoe UI,system-ui,sans-serif">{escape(pa_name[:22])}</text>')
    if pa_is_stm32:
        lines.append(f'<text x="{pa_x + pa_w/2}" y="{pa_y + 34}" text-anchor="middle" '
                     f'fill="{pa_color}" font-size="8" font-weight="600" '
                     f'font-family="Segoe UI,system-ui,sans-serif">STM32</text>')

    # Platform A scenario details
    detail_start_y = pa_y + 52
    for j, det in enumerate(details[:4]):
        lines.append(f'<text x="{pa_x + pa_w/2}" y="{detail_start_y + j * 22}" text-anchor="middle" '
                     f'fill="#9aa0a6" font-size="8.5" '
                     f'font-family="Segoe UI,system-ui,sans-serif">{escape(det)}</text>')

    # Platform B card (right)
    pb_x, pb_y, pb_w, pb_h = width - 155, 38, 145, 330
    lines.append(f'<rect x="{pb_x}" y="{pb_y}" width="{pb_w}" height="{pb_h}" '
                 f'rx="7" fill="url(#gB)" stroke="{pb_color}" stroke-width="1.5"/>')
    lines.append(f'<text x="{pb_x + pb_w/2}" y="{pb_y + 20}" text-anchor="middle" '
                 f'fill="{pb_color}" font-size="10" font-weight="700" '
                 f'font-family="Segoe UI,system-ui,sans-serif">{escape(pb_name[:22])}</text>')
    if not pa_is_stm32:
        lines.append(f'<text x="{pb_x + pb_w/2}" y="{pb_y + 34}" text-anchor="middle" '
                     f'fill="{pb_color}" font-size="8" font-weight="600" '
                     f'font-family="Segoe UI,system-ui,sans-serif">STM32</text>')

    # Platform B scenario details
    for j, det in enumerate(details[:4]):
        lines.append(f'<text x="{pb_x + pb_w/2}" y="{detail_start_y + j * 22}" text-anchor="middle" '
                     f'fill="#9aa0a6" font-size="8.5" '
                     f'font-family="Segoe UI,system-ui,sans-serif">{escape(det)}</text>')

    # Pipeline steps (center column)
    step_w = 230
    step_h = 32
    step_x = (width - step_w) / 2
    step_start_y = 42
    step_gap = 42

    for i, (label, sublabel) in enumerate(pipeline):
        sy = step_start_y + i * step_gap
        is_active = i >= 5
        fill = "rgba(0,120,212,0.18)" if is_active else "#2a2f38"
        stroke = "#0078D4" if is_active else "#3c4043"
        sw = 1.8 if is_active else 1

        lines.append(f'<rect x="{step_x}" y="{sy}" width="{step_w}" height="{step_h}" '
                     f'rx="5" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
        lines.append(f'<text x="{step_x + step_w/2}" y="{sy + 13}" text-anchor="middle" '
                     f'fill="#e8eaed" font-size="9.5" font-weight="600" '
                     f'font-family="Segoe UI,system-ui,sans-serif">{escape(label)}</text>')
        lines.append(f'<text x="{step_x + step_w/2}" y="{sy + 25}" text-anchor="middle" '
                     f'fill="#9aa0a6" font-size="7.5" '
                     f'font-family="Segoe UI,system-ui,sans-serif">{escape(sublabel)}</text>')

        # Arrow to next step
        if i < len(pipeline) - 1:
            arr_y1 = sy + step_h
            arr_y2 = sy + step_gap - 2
            lines.append(f'<line x1="{step_x + step_w/2}" y1="{arr_y1}" '
                         f'x2="{step_x + step_w/2}" y2="{arr_y2}" '
                         f'stroke="#9aa0a6" stroke-width="1" marker-end="url(#diag-arr)"/>')

    # Connection: Platform A → pipeline (at "Create/Port Code" step)
    conn_y = step_start_y + 2 * step_gap + step_h / 2
    lines.append(f'<line x1="{pa_x + pa_w}" y1="{conn_y}" x2="{step_x}" y2="{conn_y}" '
                 f'stroke="{pa_color}" stroke-width="1.5" stroke-dasharray="4,3" '
                 f'marker-end="url(#diag-arr)"/>')

    # Connection: Platform B → pipeline
    lines.append(f'<line x1="{pb_x}" y1="{conn_y}" x2="{step_x + step_w}" y2="{conn_y}" '
                 f'stroke="{pb_color}" stroke-width="1.5" stroke-dasharray="4,3"/>')
    # Arrowhead for B (pointing left)
    lines.append(f'<polygon points="{step_x + step_w + 2},{conn_y - 2.5} '
                 f'{step_x + step_w + 2},{conn_y + 2.5} '
                 f'{step_x + step_w - 3},{conn_y}" fill="{pb_color}"/>')

    # Output label
    out_y = step_start_y + len(pipeline) * step_gap - 4
    lines.append(f'<text x="{width/2}" y="{out_y}" text-anchor="middle" '
                 f'fill="#9aa0a6" font-size="8" '
                 f'font-family="Segoe UI,system-ui,sans-serif">'
                 f'▼ Self-contained HTML report</text>')

    lines.append('</svg>')
    return '\n'.join(lines)




def generate_drawio_diagram(scenario_type="", pa_name="Platform A", pb_name="Platform B",
                            pa_is_stm32=False, comparison_id=""):
    """Generate a draw.io XML file for the benchmark scenario architecture.

    Produces a .drawio file showing the benchmark pipeline with platform cards.
    Returns the XML string content.
    """
    # Pipeline stages
    pipeline = [
        ("Resolve Scenario", "Identify benchmark type"),
        ("Acquire Materials", "SDK, HAL, middleware"),
        ("Create / Port Code", "Semantic equivalence"),
        ("Configure &amp; Build", "IAR EWARM, same opts"),
        ("Debug &amp; Validate", "Flash, breakpoints, UART"),
        ("Measure &amp; Compare", "Footprint + timing"),
        ("Fairness Review", "Normalize differences"),
        ("Generate Report", "HTML dossier output"),
    ]

    # Scenario-specific details
    scenario_details = {
        "rtos": ["Task creation", "Scheduler start", "Sync primitives", "Context switch measurement"],
        "peripheral": ["Peripheral init", "DMA/IRQ setup", "Transfer cycle", "Throughput measurement"],
        "bare_metal": ["Init sequence", "Main loop", "ISR handlers", "Cycle count"],
        "dsp": ["Filter setup", "Buffer process", "Pipeline flush", "MIPS calculation"],
    }
    details = scenario_details.get(str(scenario_type).lower().replace("-", "_").replace(" ", "_"),
                                   ["Step 1", "Step 2", "Step 3", "Step 4"])

    pa_color = "#0078D4" if pa_is_stm32 else "#FF6D00"
    pb_color = "#FF6D00" if pa_is_stm32 else "#0078D4"

    # Build cells
    cells = []
    cell_id = 2  # 0 and 1 reserved by draw.io

    # Platform A container
    cell_id += 1
    pa_id = cell_id
    cells.append(f'<mxCell id="{pa_id}" value="{escape(pa_name)}" style="rounded=1;whiteSpace=wrap;html=1;fillColor={pa_color};fontColor=#FFFFFF;strokeColor={pa_color};fontSize=12;fontStyle=1;verticalAlign=top;spacingTop=8;" vertex="1" parent="1"><mxGeometry x="40" y="60" width="160" height="360" as="geometry"/></mxCell>')

    # Platform A details
    for j, det in enumerate(details[:4]):
        cell_id += 1
        cells.append(f'<mxCell id="{cell_id}" value="{escape(det)}" style="text;html=1;align=center;verticalAlign=middle;resizable=0;points=[];autosize=1;strokeColor=none;fillColor=none;fontSize=10;fontColor=#9AA0A6;" vertex="1" parent="1"><mxGeometry x="55" y="{110 + j * 40}" width="130" height="30" as="geometry"/></mxCell>')

    # Platform B container
    cell_id += 1
    pb_id = cell_id
    cells.append(f'<mxCell id="{pb_id}" value="{escape(pb_name)}" style="rounded=1;whiteSpace=wrap;html=1;fillColor={pb_color};fontColor=#FFFFFF;strokeColor={pb_color};fontSize=12;fontStyle=1;verticalAlign=top;spacingTop=8;" vertex="1" parent="1"><mxGeometry x="600" y="60" width="160" height="360" as="geometry"/></mxCell>')

    # Platform B details
    for j, det in enumerate(details[:4]):
        cell_id += 1
        cells.append(f'<mxCell id="{cell_id}" value="{escape(det)}" style="text;html=1;align=center;verticalAlign=middle;resizable=0;points=[];autosize=1;strokeColor=none;fillColor=none;fontSize=10;fontColor=#9AA0A6;" vertex="1" parent="1"><mxGeometry x="615" y="{110 + j * 40}" width="130" height="30" as="geometry"/></mxCell>')

    # Pipeline steps (center)
    step_ids = []
    for i, (label, sublabel) in enumerate(pipeline):
        cell_id += 1
        step_ids.append(cell_id)
        y = 60 + i * 48
        is_active = i >= 5
        fill = "#0078D4" if is_active else "#2A2F38"
        stroke = "#0078D4" if is_active else "#3C4043"
        font_color = "#FFFFFF" if is_active else "#E8EAED"
        cells.append(f'<mxCell id="{cell_id}" value="{label}&#xa;{sublabel}" style="rounded=1;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};fontColor={font_color};fontSize=10;align=center;" vertex="1" parent="1"><mxGeometry x="280" y="{y}" width="240" height="38" as="geometry"/></mxCell>')

    # Arrows between pipeline steps
    for i in range(len(step_ids) - 1):
        cell_id += 1
        cells.append(f'<mxCell id="{cell_id}" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;strokeColor=#9AA0A6;strokeWidth=1.5;" edge="1" source="{step_ids[i]}" target="{step_ids[i+1]}" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>')

    # Connect Platform A to "Create/Port Code" step
    cell_id += 1
    cells.append(f'<mxCell id="{cell_id}" style="edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;strokeColor={pa_color};strokeWidth=2;dashed=1;dashPattern=4 3;" edge="1" source="{pa_id}" target="{step_ids[2]}" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>')

    # Connect Platform B to "Create/Port Code" step
    cell_id += 1
    cells.append(f'<mxCell id="{cell_id}" style="edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;strokeColor={pb_color};strokeWidth=2;dashed=1;dashPattern=4 3;" edge="1" source="{pb_id}" target="{step_ids[2]}" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>')

    # Title
    cell_id += 1
    title_text = f"Benchmark Scenario: {escape(scenario_type or 'Generic')}"
    cells.append(f'<mxCell id="{cell_id}" value="{title_text}" style="text;html=1;align=center;verticalAlign=middle;resizable=0;points=[];autosize=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontColor=#E8EAED;" vertex="1" parent="1"><mxGeometry x="280" y="20" width="240" height="30" as="geometry"/></mxCell>')

    # Output label
    cell_id += 1
    cells.append(f'<mxCell id="{cell_id}" value="▼ Self-contained HTML Report" style="text;html=1;align=center;verticalAlign=middle;resizable=0;points=[];autosize=1;strokeColor=none;fillColor=none;fontSize=9;fontColor=#9AA0A6;" vertex="1" parent="1"><mxGeometry x="300" y="{60 + len(pipeline) * 48 + 10}" width="200" height="20" as="geometry"/></mxCell>')

    cells_xml = '\n            '.join(cells)

    drawio_xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<mxfile host="Copilot" modified="{datetime.now().isoformat()}" type="device" version="1.0">
  <diagram id="benchmark-scenario" name="Benchmark Scenario Architecture">
    <mxGraphModel dx="800" dy="500" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" pageScale="1" background="#1A1D23">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        {cells_xml}
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>'''
    return drawio_xml




BADGE_COLORS = {
    "success": "badge-success",
    "warning": "badge-warning",
    "danger": "badge-danger",
    "info": "badge-info",
    "neutral": "badge-neutral",
}

STATUS_MAP = {
    # Fairness
    "fair": ("Fair", "success"),
    "fair_with_noted_differences": ("Fair ⚠", "warning"),
    "unfair_correctable": ("Unfair (correctable)", "warning"),
    "unfair_structural": ("Unfair", "danger"),
    # Equivalence
    "equivalent": ("Equivalent", "success"),
    "equivalent_with_caveats": ("Equivalent*", "warning"),
    "drift_detected": ("Drift Detected", "danger"),
    "approval_required": ("Approval Required", "warning"),
    # Confidence
    "high": ("High", "success"),
    "medium": ("Medium", "warning"),
    "low": ("Low", "danger"),
    "unresolved": ("Unresolved", "info"),
    # Recommendation
    "strong": ("Strong", "success"),
    "tentative": ("Tentative", "warning"),
    "not_justified": ("Not Justified", "neutral"),
    "actionable": ("Actionable", "success"),
    "insufficient_evidence": ("Insufficient Evidence", "neutral"),
    # Gap classification
    "structural": ("Structural", "info"),
    "configurable": ("Configurable", "warning"),
    "algorithmic": ("Algorithmic", "info"),
    # Fallback
    "unknown": ("Unknown", "neutral"),
    "pass": ("Pass", "success"),
    "caveat": ("Caveat", "warning"),
    "drift": ("Drift", "danger"),
    "matched": ("Matched", "success"),
    "acceptable_difference": ("Acceptable", "warning"),
    "unfair_difference": ("Unfair", "danger"),
    "none": ("None", "neutral"),
}


def badge(status: str) -> str:
    """Render a status badge with CSS class."""
    if not status:
        return '<span class="badge badge-neutral">—</span>'
    label, color_key = STATUS_MAP.get(str(status).lower().strip(), (str(status).replace("_", " ").title(), "info"))
    cls = BADGE_COLORS.get(color_key, "badge-info")
    return f'<span class="badge {cls}">{escape(label)}</span>'


def winner_label(winner: str, pa_name: str, pb_name: str) -> str:
    """Render winner display."""
    if winner == "platform_a":
        return f'<span class="winner-a">{escape(pa_name)}</span>'
    elif winner == "platform_b":
        return f'<span class="winner-b">{escape(pb_name)}</span>'
    return '<span class="winner-tie">Tie</span>'


# ---------------------------------------------------------------------------
# HTML Template
# ---------------------------------------------------------------------------

CSS = """
:root {
  --bg: #1a1d23; --surface: #22262e; --surface-alt: #2a2f38;
  --text: #e8eaed; --text-sec: #9aa0a6; --border: #3c4043;
  --accent-a: #0078D4; --accent-b: #FF6D00;
  --success: #34a853; --warning: #fbbc04; --danger: #ea4335; --info: #4fc3f7;
  --radius: 8px; --shadow: 0 2px 8px rgba(0,0,0,0.3);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); line-height: 1.65; padding: 32px 24px; max-width: 1200px; margin: 0 auto; }
h1 { font-size: 1.9rem; margin-bottom: 4px; letter-spacing: -0.3px; }
h2 { font-size: 1.35rem; margin: 40px 0 16px; padding-bottom: 10px; border-bottom: 2px solid var(--border); color: var(--accent-a); scroll-margin-top: 24px; }
h2 .sec-num { color: var(--text-sec); font-weight: 400; margin-right: 8px; font-size: 0.85em; }
h3 { font-size: 1.05rem; margin: 18px 0 10px; color: var(--text); }
p { margin: 8px 0; color: var(--text-sec); line-height: 1.7; }
a { color: var(--accent-a); text-decoration: none; }
a:hover { text-decoration: underline; }
ul, ol { padding-left: 20px; margin: 8px 0; }
li { margin: 4px 0; color: var(--text-sec); line-height: 1.6; }

/* Header */
.report-header { background: linear-gradient(135deg, #0d1117 0%, #161b22 50%, #1a1d23 100%); border: 1px solid var(--border); border-radius: var(--radius); padding: 28px 32px; margin-bottom: 28px; box-shadow: var(--shadow); }
.report-header h1 { color: #fff; }
.report-header .subtitle { color: var(--text-sec); font-size: 0.95rem; margin-top: 4px; }
.report-header .meta { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 14px; font-size: 0.82rem; color: var(--text-sec); }
.report-header .meta span { background: var(--surface-alt); padding: 4px 12px; border-radius: 4px; border: 1px solid var(--border); }

/* Table of Contents */
.toc { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px 24px; margin-bottom: 28px; }
.toc h3 { margin: 0 0 10px; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-sec); }
.toc-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 4px 24px; }
.toc a { font-size: 0.82rem; color: var(--text-sec); display: block; padding: 3px 0; transition: color 0.15s; }
.toc a:hover { color: var(--accent-a); text-decoration: none; }
.toc .toc-num { color: var(--border); margin-right: 6px; min-width: 20px; display: inline-block; }

/* Cards */
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(175px, 1fr)); gap: 14px; margin: 18px 0; }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 16px; text-align: center; transition: border-color 0.15s; }
.card:hover { border-color: var(--accent-a); }
.card .card-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.6px; color: var(--text-sec); margin-bottom: 8px; }
.card .card-value { font-size: 1.35rem; font-weight: 600; }
.card .card-sub { font-size: 0.78rem; color: var(--text-sec); margin-top: 6px; }

/* Badges — improved contrast */
.badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 0.72rem; font-weight: 700; white-space: nowrap; letter-spacing: 0.2px; }
.badge-success { background: var(--success); color: #fff; }
.badge-warning { background: var(--warning); color: #1a1d23; }
.badge-danger { background: var(--danger); color: #fff; }
.badge-info { background: var(--info); color: #1a1d23; }
.badge-neutral { background: var(--surface-alt); color: var(--text); border: 1px solid var(--border); }

/* Panels */
.panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px 24px; margin: 14px 0; }
.panel.warning-panel { border-left: 5px solid var(--warning); background: linear-gradient(90deg, rgba(251,188,4,0.04) 0%, var(--surface) 30%); }
.panel.danger-panel { border-left: 5px solid var(--danger); background: linear-gradient(90deg, rgba(234,67,53,0.04) 0%, var(--surface) 30%); }
.panel.info-panel { border-left: 5px solid var(--info); }
.panel.success-panel { border-left: 5px solid var(--success); }
.panel h3 { margin-top: 0; }

/* Fairness callout — high visibility */
.fairness-callout { background: linear-gradient(135deg, rgba(251,188,4,0.08) 0%, var(--surface) 100%); border: 2px solid var(--warning); border-radius: var(--radius); padding: 16px 20px; margin: 14px 0; display: flex; align-items: flex-start; gap: 12px; }
.fairness-callout .callout-icon { font-size: 1.5rem; flex-shrink: 0; line-height: 1; }
.fairness-callout .callout-body { flex: 1; }
.fairness-callout .callout-title { font-weight: 600; color: var(--warning); font-size: 0.9rem; margin-bottom: 4px; }
.fairness-callout p { color: var(--text); font-size: 0.85rem; margin: 2px 0; }

/* Platform cards */
.platform-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin: 14px 0; }
.platform-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 22px; position: relative; overflow: hidden; }
.platform-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; }
.platform-card.stm32::before { background: linear-gradient(90deg, var(--accent-a), #40a0ff); }
.platform-card.competitor::before { background: linear-gradient(90deg, var(--accent-b), #ffab40); }
.platform-card h3 { margin-top: 4px; font-size: 1.1rem; }
.platform-card .vendor-tag { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 1px; padding: 2px 10px; border-radius: 3px; display: inline-block; margin-bottom: 8px; font-weight: 600; }
.platform-card.stm32 .vendor-tag { background: var(--accent-a); color: #fff; }
.platform-card.competitor .vendor-tag { background: var(--accent-b); color: #fff; }
.platform-card dl { display: grid; grid-template-columns: auto 1fr; gap: 5px 14px; font-size: 0.83rem; margin-top: 10px; }
.platform-card dt { color: var(--text-sec); }
.platform-card dd { color: var(--text); font-weight: 500; }

/* Tables — zebra stripes, sticky header */
.table-wrap { overflow-x: auto; margin: 14px 0; border-radius: var(--radius); border: 1px solid var(--border); }
table { width: 100%; border-collapse: collapse; font-size: 0.83rem; }
thead { position: sticky; top: 0; z-index: 1; }
th { background: var(--surface-alt); color: var(--text-sec); text-transform: uppercase; font-size: 0.68rem; letter-spacing: 0.5px; padding: 11px 14px; text-align: left; border-bottom: 2px solid var(--border); white-space: nowrap; }
td { padding: 10px 14px; border-bottom: 1px solid var(--border); color: var(--text); vertical-align: middle; }
tbody tr:nth-child(even) td { background: rgba(255,255,255,0.015); }
tbody tr:hover td { background: rgba(0,120,212,0.06); }
.num { text-align: right; font-variant-numeric: tabular-nums; font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace; }
.delta-pos { color: var(--success); font-weight: 600; }
.delta-neg { color: var(--danger); font-weight: 600; }
.delta-zero { color: var(--text-sec); }

/* Charts */
.chart-container { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; margin: 16px 0; overflow-x: auto; }
.chart-svg { width: 100%; max-width: 580px; height: auto; display: block; margin: 0 auto; }
.chart-title { fill: var(--text); font-size: 13px; font-weight: 600; }
.axis-label { fill: var(--text-sec); font-size: 10px; font-family: 'Segoe UI', system-ui, sans-serif; }
.grid-line { stroke: var(--border); stroke-width: 0.5; stroke-dasharray: 3,3; }
.bar-value { fill: var(--text); font-size: 9px; font-weight: 600; font-family: 'Segoe UI', system-ui, sans-serif; }
.chart-legend { display: flex; justify-content: center; gap: 20px; margin-top: 10px; font-size: 0.78rem; color: var(--text-sec); }
.chart-legend-item { display: flex; align-items: center; gap: 6px; }
.chart-legend-dot { width: 12px; height: 12px; border-radius: 2px; }

/* Diagram section */
.diagram-container { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; margin: 16px 0; overflow-x: auto; }
.diagram-svg { width: 100%; max-width: 760px; height: auto; display: block; margin: 0 auto; }
.diagram-note { display: flex; align-items: center; gap: 10px; margin-top: 12px; padding: 10px 14px; background: var(--surface-alt); border-radius: var(--radius); font-size: 0.78rem; color: var(--text-sec); }
.diagram-note .diagram-filename { font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 0.78rem; color: var(--accent-a); background: var(--bg); padding: 2px 8px; border-radius: 3px; }

/* Legend (global) */
.legend { display: flex; gap: 18px; margin: 12px 0; font-size: 0.82rem; align-items: center; }
.legend-item { display: flex; align-items: center; gap: 7px; color: var(--text-sec); }
.legend-dot { width: 12px; height: 12px; border-radius: 3px; }

/* No-data placeholder */
.no-data { color: var(--text-sec); font-style: italic; padding: 24px 20px; text-align: center; background: var(--surface-alt); border-radius: var(--radius); border: 1px dashed var(--border); }
.no-data::before { content: '○ '; }

/* Winner labels */
.winner-a { color: var(--accent-a); font-weight: 700; }
.winner-b { color: var(--accent-b); font-weight: 700; }
.winner-tie { color: var(--text-sec); font-weight: 500; }

/* STM32 findings — enhanced visibility */
.stm32-section { background: linear-gradient(135deg, rgba(0,120,212,0.04) 0%, transparent 100%); border: 1px solid rgba(0,120,212,0.2); border-radius: var(--radius); padding: 20px 24px; margin: 14px 0; }
.stm32-highlight { border-left: 4px solid var(--accent-a); padding: 12px 16px; margin: 10px 0; background: rgba(0,120,212,0.03); border-radius: 0 var(--radius) var(--radius) 0; }
.stm32-highlight.behind { border-left-color: var(--accent-b); background: rgba(255,109,0,0.03); }
.stm32-highlight.inconclusive { border-left-color: var(--text-sec); background: rgba(154,160,166,0.03); }
.finding-list { list-style: none; padding: 0; }
.finding-list li { padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 0.88rem; color: var(--text); display: flex; align-items: baseline; gap: 8px; }
.finding-list li:last-child { border-bottom: none; }
.finding-list .icon { flex-shrink: 0; font-size: 0.75rem; }

/* Recommendation cards */
.rec-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px 20px; margin: 10px 0; transition: border-color 0.15s; }
.rec-card:hover { border-color: var(--accent-a); }
.rec-card h4 { margin: 0 0 8px; font-size: 0.95rem; color: var(--text); }
.rec-card .rec-desc { color: var(--text-sec); font-size: 0.85rem; margin: 4px 0; }
.rec-card .rec-evidence { color: var(--text-sec); font-size: 0.8rem; font-style: italic; margin: 6px 0; }
.rec-card .rec-meta { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }

/* Footer */
footer { margin-top: 48px; padding-top: 18px; border-top: 1px solid var(--border); font-size: 0.73rem; color: var(--text-sec); text-align: center; }
footer .gen-info { margin-top: 4px; }

/* Print styles */
@media print {
  body { background: #fff; color: #222; padding: 12px; }
  .report-header { background: #f5f5f5; border-color: #ddd; }
  .report-header h1 { color: #111; }
  h2 { color: #0078D4; border-color: #ddd; }
  .card, .panel, .platform-card, .chart-container, .diagram-container, .stm32-section, .rec-card { border-color: #ddd; background: #fafafa; }
  td, th { border-color: #ddd; }
  .no-data { background: #f9f9f9; border-color: #ddd; }
}

@media (max-width: 768px) {
  .platform-grid { grid-template-columns: 1fr; }
  .cards { grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); }
  .toc-grid { grid-template-columns: 1fr; }
  body { padding: 16px 12px; }
}
"""


def generate_html(data: dict) -> str:
    """Generate complete HTML report from report data dict."""

    # Accessors
    meta = get(data, "report_metadata", default={})
    platforms = get(data, "platforms", default={})
    pa = get(platforms, "platform_a", default={})
    pb = get(platforms, "platform_b", default={})
    fairness = get(data, "fairness", default={})
    sem_eq = get(data, "semantic_equivalence", default={})
    footprint = get(data, "footprint", default={})
    fp_layer = get(data, "footprint_by_layer", default={})
    mod_eq = get(data, "module_equivalence", default={})
    exec_time = get(data, "execution_time", default={})
    scenario = get(data, "scenario_observations", default={})
    interp = get(data, "interpretation", default={})
    stm32f = get(data, "stm32_findings", default={})
    recs = get(data, "recommendations", default={})
    unknowns = get(data, "unknowns", default={})

    pa_name = get(pa, "display_name", default=get(pa, "id", default="Platform A"))
    pb_name = get(pb, "display_name", default=get(pb, "id", default="Platform B"))
    pa_is_stm32 = get(pa, "is_stm32", default=False)
    pb_is_stm32 = get(pb, "is_stm32", default=False)

    title = get(meta, "report_title", default="Benchmark Comparison Report")
    scenario_name = get(meta, "scenario_name", default="")
    comparison_id = get(meta, "comparison_id", default="")
    generated = get(meta, "generated_at", default=datetime.now().isoformat(timespec="seconds"))

    flash = get(footprint, "flash", default={})
    ram = get(footprint, "ram", default={})

    # Build HTML
    parts = []
    parts.append(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{escape(title)}</title>
<style>{CSS}</style>
</head>
<body>
""")

    # Section definitions for TOC
    sections = [
        ("executive-summary", "Executive Summary"),
        ("scenario-diagram", "Scenario Architecture"),
        ("platform-summary", "Platform Summary"),
        ("fairness-equivalence", "Fairness & Equivalence"),
        ("footprint", "Footprint Comparison"),
        ("footprint-layers", "Footprint by Layer"),
        ("module-equivalence", "Module Equivalence"),
        ("execution-time", "Execution Time"),
        ("scenario-observations", "Scenario Observations"),
        ("interpretation", "Interpretation"),
        ("stm32-findings", "STM32-Focused Findings"),
        ("recommendations", "Recommendations"),
        ("unknowns", "Unknowns & Evidence"),
    ]

    def sec_heading(idx):
        """Return h2 with section number and anchor."""
        sid, stitle = sections[idx]
        return f'<h2 id="{sid}"><span class="sec-num">{idx+1}.</span>{escape(stitle)}</h2>'

    # ── Section 0: Header ──
    parts.append(f"""<div class="report-header">
<h1>{escape(title)}</h1>
<div class="meta">
<span>Scenario: <strong>{escape(scenario_name) or '—'}</strong></span>
<span>Comparison: <strong>{escape(comparison_id) or '—'}</strong></span>
<span>Generated: <strong>{escape(generated)}</strong></span>
</div>
</div>
""")

    # ── Table of Contents ──
    parts.append('<nav class="toc"><h3>Contents</h3><div class="toc-grid">')
    for i, (sid, stitle) in enumerate(sections):
        parts.append(f'<a href="#{sid}"><span class="toc-num">{i+1}.</span>{escape(stitle)}</a>')
    parts.append('</div></nav>')

    # ── Section 1: Executive Summary ──
    parts.append(sec_heading(0))
    parts.append('<div class="cards">')

    # Fairness card
    parts.append(f"""<div class="card"><div class="card-label">Fairness</div>
<div class="card-value">{badge(get(fairness, "overall_status", default="unknown"))}</div>
<div class="card-sub">Confidence: {badge(get(fairness, "confidence", default="unknown"))}</div></div>""")

    # Equivalence card
    parts.append(f"""<div class="card"><div class="card-label">Semantic Equivalence</div>
<div class="card-value">{badge(get(sem_eq, "overall_assessment", default="unknown"))}</div>
<div class="card-sub">Confidence: {badge(get(sem_eq, "confidence", default="unknown"))}</div></div>""")

    # Flash delta card
    flash_delta = get(flash, "delta_bytes", default=0)
    flash_pct = get(flash, "delta_pct", default=0)
    parts.append(f"""<div class="card"><div class="card-label">Flash Delta</div>
<div class="card-value">{fmt_delta(flash_delta, 'B')}</div>
<div class="card-sub">{fmt_pct(flash_pct)} · Winner: {winner_label(get(flash, "winner", default=""), pa_name, pb_name)}</div></div>""")

    # RAM delta card
    ram_delta = get(ram, "delta_bytes", default=0)
    ram_pct = get(ram, "delta_pct", default=0)
    parts.append(f"""<div class="card"><div class="card-label">RAM Delta</div>
<div class="card-value">{fmt_delta(ram_delta, 'B')}</div>
<div class="card-sub">{fmt_pct(ram_pct)} · Winner: {winner_label(get(ram, "winner", default=""), pa_name, pb_name)}</div></div>""")

    # Timing card
    timing_winner = get(exec_time, "overall_timing_winner", default="")
    parts.append(f"""<div class="card"><div class="card-label">Timing</div>
<div class="card-value">{winner_label(timing_winner, pa_name, pb_name) if timing_winner else '—'}</div>
<div class="card-sub">Confidence: {badge(get(exec_time, "confidence", default="unknown"))}</div></div>""")

    # Recommendation card
    rec_status = get(recs, "overall_recommendation_status", default="unknown")
    parts.append(f"""<div class="card"><div class="card-label">Recommendations</div>
<div class="card-value">{badge(rec_status)}</div></div>""")

    parts.append('</div>')  # end cards

    # ── Section 2: Scenario Architecture Diagram ──
    parts.append(sec_heading(1))
    scenario_type = get(scenario, "scenario_type", default="")
    drawio_filename = f"{comparison_id or 'benchmark'}_scenario.drawio"

    # Embedded inline SVG diagram (self-contained)
    parts.append('<div class="diagram-container">')
    parts.append(svg_scenario_diagram(
        scenario_type=scenario_type,
        pa_name=pa_name,
        pb_name=pb_name,
        pa_is_stm32=pa_is_stm32,
    ))
    parts.append(f'<div class="diagram-note">'
                 f'<span>📐</span>'
                 f'<span>Editable draw.io source also generated: '
                 f'<span class="diagram-filename">{escape(drawio_filename)}</span></span>'
                 f'</div>')
    parts.append('</div>')

    # ── Section 3: Platform Summary ──
    parts.append(sec_heading(2))
    parts.append('<div class="platform-grid">')

    for plat, pname, is_stm in [(pa, pa_name, pa_is_stm32), (pb, pb_name, pb_is_stm32)]:
        cls = "stm32" if is_stm else "competitor"
        vendor = get(plat, "vendor", default="")
        parts.append(f"""<div class="platform-card {cls}">
<span class="vendor-tag">{escape(vendor) or 'Unknown Vendor'}</span>
<h3>{escape(pname)}</h3>
<dl>
<dt>Board</dt><dd>{escape(get(plat, "board", default="—"))}</dd>
<dt>MCU</dt><dd>{escape(get(plat, "mcu", default="—"))}</dd>
<dt>Family</dt><dd>{escape(get(plat, "family", default="—"))}</dd>
<dt>Core</dt><dd>{escape(get(plat, "core", default="—"))}</dd>
<dt>Toolchain</dt><dd>{escape(get(plat, "toolchain", default="—"))}</dd>
<dt>Build Mode</dt><dd>{escape(get(plat, "build_mode", default="—"))}</dd>
<dt>Optimization</dt><dd>{escape(get(plat, "optimization", default="—"))}</dd>
<dt>Clock</dt><dd>{get(plat, "clock_mhz", default=0)} MHz</dd>
</dl>
</div>""")

    parts.append('</div>')

    # Legend
    parts.append(f"""<div class="legend">
<div class="legend-item"><div class="legend-dot" style="background:var(--accent-a)"></div>{escape(pa_name)}</div>
<div class="legend-item"><div class="legend-dot" style="background:var(--accent-b)"></div>{escape(pb_name)}</div>
</div>""")

    # ── Section 4: Fairness & Equivalence ──
    parts.append(sec_heading(3))

    # Fairness panel
    f_status = get(fairness, "overall_status", default="unknown")
    panel_cls = "warning-panel" if "unfair" in str(f_status) or "noted" in str(f_status) else "success-panel" if f_status == "fair" else "info-panel"

    # High-visibility callout for non-fair results
    if "unfair" in str(f_status) or "noted" in str(f_status):
        caveats_preview = get(fairness, "caveats", default=[])
        caveat_text = escape(str(caveats_preview[0])) if caveats_preview and isinstance(caveats_preview, list) else "Differences noted — see details below."
        parts.append(f'''<div class="fairness-callout">
<div class="callout-icon">⚠️</div>
<div class="callout-body">
<div class="callout-title">Fairness Advisory</div>
<p>{caveat_text}</p>
</div>
</div>''')

    parts.append(f'<div class="panel {panel_cls}">')
    parts.append(f'<h3>Fairness Assessment: {badge(f_status)}</h3>')

    f_checks = get(fairness, "checks", default=[])
    if f_checks and isinstance(f_checks, list) and len(f_checks) > 0:
        parts.append(f'<div class="table-wrap"><table><tr><th>Category</th><th>Status</th><th>{escape(pa_name)}</th><th>{escape(pb_name)}</th><th>Notes</th></tr>')
        for check in f_checks:
            if isinstance(check, dict):
                parts.append(f"""<tr><td>{escape(str(get(check,"category",default="")))}</td>
<td>{badge(get(check,"status",default="unknown"))}</td>
<td>{escape(str(get(check,"platform_a_value",default="—")))}</td>
<td>{escape(str(get(check,"platform_b_value",default="—")))}</td>
<td>{escape(str(get(check,"notes",default="")))}</td></tr>""")
        parts.append('</table></div>')

    caveats = get(fairness, "caveats", default=[])
    if caveats and isinstance(caveats, list):
        parts.append('<h3>Caveats</h3><ul>')
        for c in caveats:
            parts.append(f'<li>{escape(str(c))}</li>')
        parts.append('</ul>')
    parts.append('</div>')

    # Semantic equivalence panel
    eq_status = get(sem_eq, "overall_assessment", default="unknown")
    eq_cls = "success-panel" if eq_status == "equivalent" else "warning-panel" if "caveat" in str(eq_status) else "danger-panel" if "drift" in str(eq_status) else "info-panel"
    parts.append(f'<div class="panel {eq_cls}">')
    parts.append(f'<h3>Semantic Equivalence: {badge(eq_status)}</h3>')

    b_checks = get(sem_eq, "behavior_checks", default=[])
    if b_checks and isinstance(b_checks, list) and len(b_checks) > 0:
        parts.append('<div class="table-wrap"><table><tr><th>Behavior</th><th>Status</th><th>Notes</th></tr>')
        for check in b_checks:
            if isinstance(check, dict):
                parts.append(f"""<tr><td>{escape(str(get(check,"behavior",default="")))}</td>
<td>{badge(get(check,"status",default="unknown"))}</td>
<td>{escape(str(get(check,"notes",default="")))}</td></tr>""")
        parts.append('</table></div>')
    parts.append('</div>')

    # ── Section 5: Overall Footprint ──
    parts.append(sec_heading(4))

    flash_a = get(flash, "platform_a_bytes", default=0)
    flash_b = get(flash, "platform_b_bytes", default=0)
    ram_a = get(ram, "platform_a_bytes", default=0)
    ram_b = get(ram, "platform_b_bytes", default=0)

    if flash_a or flash_b or ram_a or ram_b:
        parts.append('<div class="table-wrap"><table><tr><th>Metric</th><th class="num">'+escape(pa_name)+'</th><th class="num">'+escape(pb_name)+'</th><th class="num">Delta</th><th class="num">Delta %</th><th>Winner</th><th>Confidence</th></tr>')
        parts.append(f"""<tr><td>Flash</td><td class="num">{fmt_bytes(flash_a)}</td><td class="num">{fmt_bytes(flash_b)}</td>
<td class="num {'delta-neg' if flash_delta and flash_delta > 0 else 'delta-pos' if flash_delta and flash_delta < 0 else 'delta-zero'}">{fmt_delta(flash_delta, 'B')}</td>
<td class="num">{fmt_pct(flash_pct)}</td><td>{winner_label(get(flash,"winner",""), pa_name, pb_name)}</td><td>{badge(get(flash,"confidence","unknown"))}</td></tr>""")
        parts.append(f"""<tr><td>RAM</td><td class="num">{fmt_bytes(ram_a)}</td><td class="num">{fmt_bytes(ram_b)}</td>
<td class="num {'delta-neg' if ram_delta and ram_delta > 0 else 'delta-pos' if ram_delta and ram_delta < 0 else 'delta-zero'}">{fmt_delta(ram_delta, 'B')}</td>
<td class="num">{fmt_pct(ram_pct)}</td><td>{winner_label(get(ram,"winner",""), pa_name, pb_name)}</td><td>{badge(get(ram,"confidence","unknown"))}</td></tr>""")
        parts.append('</table></div>')

        # Chart
        parts.append('<div class="chart-container">')
        parts.append(svg_grouped_bar(
            [(flash_a, flash_b), (ram_a, ram_b)],
            ["Flash", "RAM"],
            title="Footprint Comparison",
            label_a=pa_name, label_b=pb_name, units="bytes"
        ))
        parts.append('</div>')
    else:
        parts.append('<div class="no-data">Footprint data not available</div>')

    # ── Section 6: Footprint by Layer ──
    parts.append(sec_heading(5))
    layers = get(fp_layer, "layers", default=[])
    if layers and isinstance(layers, list) and len(layers) > 0:
        parts.append('<div class="table-wrap"><table><tr><th>Layer</th><th class="num">'+escape(pa_name)+' Flash</th><th class="num">'+escape(pb_name)+' Flash</th><th class="num">Flash Δ</th><th class="num">'+escape(pa_name)+' RAM</th><th class="num">'+escape(pb_name)+' RAM</th><th class="num">RAM Δ</th></tr>')
        layer_chart_data = []
        layer_labels = []
        for layer in layers:
            if isinstance(layer, dict):
                name = get(layer, "display_name", default=get(layer, "name", default="?"))
                af = get(layer, "platform_a_flash", default=0)
                bf = get(layer, "platform_b_flash", default=0)
                fd = get(layer, "flash_delta", default=(bf - af) if af and bf else 0)
                ar = get(layer, "platform_a_ram", default=0)
                br = get(layer, "platform_b_ram", default=0)
                rd = get(layer, "ram_delta", default=(br - ar) if ar and br else 0)
                parts.append(f'<tr><td>{escape(name)}</td><td class="num">{fmt_bytes(af)}</td><td class="num">{fmt_bytes(bf)}</td><td class="num">{fmt_delta(fd,"B")}</td><td class="num">{fmt_bytes(ar)}</td><td class="num">{fmt_bytes(br)}</td><td class="num">{fmt_delta(rd,"B")}</td></tr>')
                layer_chart_data.append((af, bf))
                layer_labels.append(name)
        parts.append('</table></div>')

        if layer_chart_data:
            parts.append('<div class="chart-container">')
            parts.append(svg_grouped_bar(layer_chart_data, layer_labels,
                         title="Flash by Layer", label_a=pa_name, label_b=pb_name, units="bytes"))
            parts.append('</div>')
    else:
        parts.append('<div class="no-data">Layer footprint data not available</div>')

    # ── Section 7: Module Equivalence ──
    parts.append(sec_heading(6))
    modules = get(mod_eq, "modules", default=[])
    if modules and isinstance(modules, list) and len(modules) > 0:
        parts.append(f'<p>Confidence: {badge(get(mod_eq, "confidence", default="unknown"))}</p>')
        parts.append(f'<div class="table-wrap"><table><tr><th>{escape(pa_name)} Module</th><th>{escape(pb_name)} Module</th><th>Layer</th><th class="num">Flash Δ</th><th class="num">RAM Δ</th><th>Match</th><th>Note</th></tr>')
        module_deltas = []
        for mod in modules:
            if isinstance(mod, dict):
                ma = get(mod, "module_a", default="")
                mb = get(mod, "module_b", default="")
                layer = get(mod, "layer", default="")
                fd = get(mod, "flash_delta", default=0)
                rd = get(mod, "ram_delta", default=0)
                conf = get(mod, "match_confidence", default="unknown")
                note = get(mod, "gap_note", default="")
                parts.append(f'<tr><td>{escape(str(ma))}</td><td>{escape(str(mb))}</td><td>{escape(str(layer))}</td><td class="num">{fmt_delta(fd,"B")}</td><td class="num">{fmt_delta(rd,"B")}</td><td>{badge(conf)}</td><td>{escape(str(note))}</td></tr>')
                if fd:
                    module_deltas.append((str(ma) or str(mb), fd))
        parts.append('</table></div>')

        # Top contributors chart
        if module_deltas:
            sorted_mods = sorted(module_deltas, key=lambda x: abs(x[1]), reverse=True)[:10]
            parts.append('<div class="chart-container">')
            parts.append(svg_horizontal_bar(sorted_mods, title="Top Module Flash Gaps", units="B"))
            parts.append('</div>')

        # Unmatched
        unmatched_a = get(mod_eq, "unmatched_a", default=[])
        unmatched_b = get(mod_eq, "unmatched_b", default=[])
        if unmatched_a or unmatched_b:
            parts.append('<h3>Unmatched Modules</h3>')
            if unmatched_a and isinstance(unmatched_a, list):
                parts.append(f'<p><strong>{escape(pa_name)}:</strong> {", ".join(escape(str(m)) for m in unmatched_a)}</p>')
            if unmatched_b and isinstance(unmatched_b, list):
                parts.append(f'<p><strong>{escape(pb_name)}:</strong> {", ".join(escape(str(m)) for m in unmatched_b)}</p>')
    else:
        parts.append('<div class="no-data">Module equivalence data not available</div>')

    # ── Section 8: Execution Time ──
    parts.append(sec_heading(7))
    metrics = get(exec_time, "metrics", default=[])
    if metrics and isinstance(metrics, list) and len(metrics) > 0:
        parts.append('<div class="table-wrap"><table><tr><th>Metric</th><th class="num">'+escape(pa_name)+'</th><th class="num">'+escape(pb_name)+'</th><th>Units</th><th class="num">Delta</th><th class="num">Δ%</th><th>Direction</th><th>Confidence</th></tr>')
        timing_chart_data = []
        timing_labels = []
        for m in metrics:
            if isinstance(m, dict):
                mname = get(m, "display_name", default=get(m, "metric_name", default="?"))
                va = get(m, "platform_a_value", default=0)
                vb = get(m, "platform_b_value", default=0)
                units = get(m, "units", default="")
                delta = get(m, "delta", default=0)
                dpct = get(m, "delta_pct", default=0)
                direction = get(m, "direction", default="")
                conf = get(m, "confidence", default="unknown")
                dir_display = f"← {escape(pa_name[:10])}" if direction == "a_faster" else f"→ {escape(pb_name[:10])}" if direction == "b_faster" else "="
                parts.append(f'<tr><td>{escape(str(mname))}</td><td class="num">{va:,}</td><td class="num">{vb:,}</td><td>{escape(str(units))}</td><td class="num">{fmt_delta(delta)}</td><td class="num">{fmt_pct(dpct)}</td><td>{dir_display}</td><td>{badge(conf)}</td></tr>')
                timing_chart_data.append((va if va else 0, vb if vb else 0))
                timing_labels.append(str(mname)[:16])
        parts.append('</table></div>')

        if timing_chart_data:
            parts.append('<div class="chart-container">')
            parts.append(svg_grouped_bar(timing_chart_data, timing_labels,
                         title="Execution Time", label_a=pa_name, label_b=pb_name))
            parts.append('</div>')
    else:
        parts.append('<div class="no-data">Execution time data not available</div>')

    # ── Section 9: Scenario Observations ──
    parts.append(sec_heading(8))
    obs = get(scenario, "observations", default=[])
    stype = get(scenario, "scenario_type", default="")
    if stype:
        parts.append(f'<p>Scenario type: <strong>{escape(str(stype))}</strong></p>')
    if obs and isinstance(obs, list) and len(obs) > 0:
        parts.append('<div class="table-wrap"><table><tr><th>Category</th><th>Finding</th><th>Fairness Impact</th><th>Confidence</th></tr>')
        for o in obs:
            if isinstance(o, dict):
                parts.append(f'<tr><td>{escape(str(get(o,"category",default="")))}</td><td>{escape(str(get(o,"finding",default="")))}</td><td>{escape(str(get(o,"fairness_impact",default="")))}</td><td>{badge(get(o,"confidence",default="unknown"))}</td></tr>')
        parts.append('</table></div>')
    else:
        parts.append('<div class="no-data">No scenario-specific observations recorded</div>')

    # ── Section 10: Interpretation ──
    parts.append(sec_heading(9))
    footprint_interp = get(interp, "footprint_interpretation", default="")
    timing_interp = get(interp, "timing_interpretation", default="")
    fairness_interp = get(interp, "fairness_assessment", default="")
    evidence = get(interp, "evidence_strength", default="")
    insights = get(interp, "key_insights", default=[])

    if footprint_interp or timing_interp or fairness_interp:
        if evidence:
            parts.append(f'<p>Evidence strength: {badge(evidence)}</p>')
        if footprint_interp:
            parts.append(f'<div class="panel info-panel"><h3>Footprint Interpretation</h3><p>{escape(str(footprint_interp))}</p></div>')
        if timing_interp:
            parts.append(f'<div class="panel info-panel"><h3>Timing Interpretation</h3><p>{escape(str(timing_interp))}</p></div>')
        if fairness_interp:
            parts.append(f'<div class="panel warning-panel"><h3>Fairness Assessment</h3><p>{escape(str(fairness_interp))}</p></div>')
        if insights and isinstance(insights, list):
            parts.append('<h3>Key Insights</h3><ul>')
            for ins in insights:
                parts.append(f'<li>{escape(str(ins))}</li>')
            parts.append('</ul>')
    else:
        parts.append('<div class="no-data">Interpretation not available — insufficient data or not yet generated</div>')

    # ── Section 11: STM32-Focused Findings ──
    parts.append(sec_heading(10))
    stm32_plat = get(stm32f, "stm32_platform", default="")
    ahead = get(stm32f, "ahead_areas", default=[])
    behind = get(stm32f, "behind_areas", default=[])
    inconclusive = get(stm32f, "inconclusive_areas", default=[])
    gap_driver = get(stm32f, "primary_gap_driver", default="")
    gap_class = get(stm32f, "gap_classification", default="")

    if ahead or behind or inconclusive or gap_driver:
        parts.append('<div class="stm32-section">')
        if gap_class:
            parts.append(f'<p>Gap classification: {badge(gap_class)}</p>')
        if gap_driver:
            parts.append(f'<p>Primary gap driver: <strong>{escape(str(gap_driver))}</strong></p>')

        if ahead and isinstance(ahead, list):
            parts.append('<div class="stm32-highlight"><h3>✓ STM32 Ahead</h3><ul class="finding-list">')
            for a in ahead:
                parts.append(f'<li><span class="icon">▲</span>{escape(str(a))}</li>')
            parts.append('</ul></div>')

        if behind and isinstance(behind, list):
            parts.append('<div class="stm32-highlight behind"><h3>✗ STM32 Behind</h3><ul class="finding-list">')
            for b in behind:
                parts.append(f'<li><span class="icon">▼</span>{escape(str(b))}</li>')
            parts.append('</ul></div>')

        if inconclusive and isinstance(inconclusive, list):
            parts.append('<div class="stm32-highlight inconclusive"><h3>? Inconclusive</h3><ul class="finding-list">')
            for ic in inconclusive:
                parts.append(f'<li><span class="icon">●</span>{escape(str(ic))}</li>')
            parts.append('</ul></div>')
        parts.append('</div>')  # end stm32-section
    else:
        if pa_is_stm32 or pb_is_stm32:
            parts.append('<div class="no-data">STM32 findings not yet generated — requires completed comparison with interpretation</div>')
        else:
            parts.append('<div class="no-data">No STM32 platform in this comparison</div>')

    # ── Section 12: Recommendations ──
    parts.append(sec_heading(11))
    rec_list = []
    if isinstance(recs, dict):
        # Try to find list items — they may be at top level of recs dict
        for k, v in recs.items():
            if isinstance(v, list):
                rec_list = v
                break
    elif isinstance(recs, list):
        rec_list = recs

    if rec_list and len(rec_list) > 0:
        for rec in rec_list:
            if isinstance(rec, dict):
                rtitle = get(rec, "title", default="Recommendation")
                conf = get(rec, "confidence", default="unknown")
                effort = get(rec, "effort", default="")
                risk = get(rec, "risk", default="")
                gap = get(rec, "addresses_gap", default="")
                basis = get(rec, "evidence_basis", default="")
                parts.append(f"""<div class="rec-card">
<h4>{escape(str(rtitle))}</h4>
<p>{escape(str(gap))}</p>
{f'<p><em>Evidence: {escape(str(basis))}</em></p>' if basis else ''}
<div class="rec-meta">{badge(conf)} {f'<span class="badge" style="background:var(--surface-alt);color:var(--text)">Effort: {escape(str(effort))}</span>' if effort else ''} {f'<span class="badge" style="background:var(--surface-alt);color:var(--text)">Risk: {escape(str(risk))}</span>' if risk else ''}</div>
</div>""")
    else:
        rec_overall = get(recs, "overall_recommendation_status", default="") if isinstance(recs, dict) else ""
        if rec_overall == "not_justified":
            parts.append('<div class="panel info-panel"><p>Recommendations are <strong>not justified</strong> based on current evidence. The comparison does not show gaps strong enough or with sufficient confidence to recommend changes.</p></div>')
        elif rec_overall == "insufficient_evidence":
            parts.append('<div class="panel info-panel"><p>Insufficient evidence to generate recommendations. Complete the comparison with full measurement and fairness data.</p></div>')
        else:
            parts.append('<div class="no-data">No recommendations available</div>')

    # ── Section 13: Unknowns & Evidence ──
    parts.append(sec_heading(12))
    unresolved = get(unknowns, "unresolved_items", default=[])
    missing = get(unknowns, "missing_measurements", default=[])
    low_conf = get(unknowns, "low_confidence_matches", default=[])
    f_concerns = get(unknowns, "fairness_concerns", default=[])
    prov_notes = get(unknowns, "provenance_notes", default=[])

    has_unknowns = any([unresolved, missing, low_conf, f_concerns, prov_notes])
    if has_unknowns:
        if unresolved and isinstance(unresolved, list):
            parts.append('<h3>Unresolved Items</h3><ul>')
            for u in unresolved:
                parts.append(f'<li>{escape(str(u))}</li>')
            parts.append('</ul>')
        if missing and isinstance(missing, list):
            parts.append('<h3>Missing Measurements</h3><ul>')
            for m in missing:
                parts.append(f'<li>{escape(str(m))}</li>')
            parts.append('</ul>')
        if low_conf and isinstance(low_conf, list):
            parts.append('<h3>Low-Confidence Matches</h3><ul>')
            for lc in low_conf:
                parts.append(f'<li>{escape(str(lc))}</li>')
            parts.append('</ul>')
        if f_concerns and isinstance(f_concerns, list):
            parts.append('<h3>Fairness Concerns</h3><ul>')
            for fc in f_concerns:
                parts.append(f'<li>{escape(str(fc))}</li>')
            parts.append('</ul>')
        if prov_notes and isinstance(prov_notes, list):
            parts.append('<h3>Provenance Notes</h3><ul>')
            for pn in prov_notes:
                parts.append(f'<li>{escape(str(pn))}</li>')
            parts.append('</ul>')
    else:
        parts.append('<div class="no-data">No unresolved items recorded</div>')

    # ── Footer ──
    parts.append(f"""<footer>
Generated by MCU Benchmark Agent · {escape(generated)} · Self-contained report — no external dependencies
</footer>
</body></html>""")

    return '\n'.join(parts)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate self-contained HTML benchmark report from report_data.yaml"
    )
    parser.add_argument("input", type=Path, nargs="?",
                        help="Path to report_data.yaml or report_data.json")
    parser.add_argument("--output", "-o", type=Path, default=None,
                        help="Output HTML path (default: <input_dir>/benchmark_report.html)")
    parser.add_argument("--from-campaign", type=Path, default=None,
                        help="Campaign directory to auto-assemble report data from")
    args = parser.parse_args()

    if args.from_campaign:
        # TODO: Implement campaign-to-report-data assembly
        print(f"Campaign assembly from '{args.from_campaign}' not yet implemented.")
        print("Please provide a report_data.yaml directly.")
        sys.exit(1)

    if not args.input:
        parser.print_help()
        sys.exit(1)

    if not args.input.exists():
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    print(f"Loading report data: {args.input}")
    data = load_report_data(args.input)

    if not data:
        print("Error: Failed to parse report data or file is empty.", file=sys.stderr)
        sys.exit(1)

    # Set generated timestamp if not already set
    meta = data.get("report_metadata", {})
    if not meta.get("generated_at"):
        if isinstance(meta, dict):
            meta["generated_at"] = datetime.now().isoformat(timespec="seconds")
            data["report_metadata"] = meta

    print("Generating HTML report...")
    html = generate_html(data)

    # Output path
    if args.output:
        output_path = args.output
    else:
        output_path = args.input.parent / "benchmark_report.html"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"Report generated: {output_path}")
    print(f"  Size: {len(html):,} bytes")

    # Generate draw.io scenario diagram alongside
    platforms = data.get("platforms", {})
    pa = platforms.get("platform_a", {})
    pb = platforms.get("platform_b", {})
    scenario = data.get("scenario_observations", {})
    comparison_id = meta.get("comparison_id", "benchmark")
    drawio_xml = generate_drawio_diagram(
        scenario_type=scenario.get("scenario_type", ""),
        pa_name=pa.get("display_name", pa.get("id", "Platform A")),
        pb_name=pb.get("display_name", pb.get("id", "Platform B")),
        pa_is_stm32=pa.get("is_stm32", False),
        comparison_id=comparison_id,
    )
    drawio_filename = f"{comparison_id or 'benchmark'}_scenario.drawio"
    drawio_path = output_path.parent / drawio_filename
    drawio_path.write_text(drawio_xml, encoding="utf-8")
    print(f"Diagram generated: {drawio_path}")


if __name__ == "__main__":
    main()
