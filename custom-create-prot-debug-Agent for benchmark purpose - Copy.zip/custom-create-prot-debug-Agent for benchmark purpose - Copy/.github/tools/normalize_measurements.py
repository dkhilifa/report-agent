#!/usr/bin/env python3
"""
normalize_measurements.py - Normalize raw measurements for fair comparison.

Takes raw measurement data and applies normalization rules:
- Unit conversion (cycles → µs using clock frequency)
- Overhead subtraction (if instrumentation overhead is known)
- Statistical aggregation (mean, median, min, max for repeated measurements)

Usage:
    python normalize_measurements.py <raw_measurements.yaml> --clock-mhz <freq> [--output <normalized.yaml>]

NOTE: This is a skeleton. Full normalization requires:
- Clock frequency for the platform
- Known instrumentation overhead
- Measurement profile from config/measurement_profiles.yaml
"""

import sys
import argparse
from pathlib import Path
from statistics import mean, median


def load_yaml_simple(path: Path) -> dict:
    """Minimal YAML-like parser for measurement files.
    For production use, import yaml (PyYAML).
    This skeleton uses basic line parsing."""
    import re

    data = {"measurements": []}
    current = None

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line.startswith("  - metric_name:"):
                if current:
                    data["measurements"].append(current)
                current = {"metric_name": "", "raw_value": 0, "unit": ""}
                match = re.search(r'"([^"]*)"', line)
                if match:
                    current["metric_name"] = match.group(1)
            elif current and "raw_value:" in line:
                match = re.search(r'raw_value:\s*([\d.]+)', line)
                if match:
                    current["raw_value"] = float(match.group(1))
            elif current and "unit:" in line:
                match = re.search(r'"([^"]*)"', line)
                if match:
                    current["unit"] = match.group(1)

    if current:
        data["measurements"].append(current)

    return data


def normalize(measurements: list, clock_mhz: float, overhead_cycles: float = 0) -> list:
    """Apply normalization to measurement list."""
    normalized = []

    # Group by metric name for aggregation
    groups = {}
    for m in measurements:
        name = m["metric_name"]
        if name not in groups:
            groups[name] = []
        groups[name].append(m)

    for name, items in groups.items():
        values = [item["raw_value"] for item in items]
        unit = items[0]["unit"]

        # Apply overhead subtraction for cycle measurements
        if unit == "cycles" and overhead_cycles > 0:
            values = [max(0, v - overhead_cycles) for v in values]

        # Compute statistics
        stats = {
            "metric_name": name,
            "original_unit": unit,
            "sample_count": len(values),
            "raw_values": values,
            "mean": round(mean(values), 2) if values else 0,
            "median": round(median(values), 2) if values else 0,
            "min": min(values) if values else 0,
            "max": max(values) if values else 0,
        }

        # Convert cycles to microseconds if clock is known
        if unit == "cycles" and clock_mhz > 0:
            stats["normalized_unit"] = "microseconds"
            stats["normalized_mean"] = round(stats["mean"] / clock_mhz, 3)
            stats["normalized_median"] = round(stats["median"] / clock_mhz, 3)
        else:
            stats["normalized_unit"] = unit
            stats["normalized_mean"] = stats["mean"]
            stats["normalized_median"] = stats["median"]

        if overhead_cycles > 0:
            stats["overhead_subtracted_cycles"] = overhead_cycles

        normalized.append(stats)

    return normalized


def format_yaml(normalized: list, clock_mhz: float, source: str) -> str:
    """Format normalized measurements as YAML."""
    lines = [
        "# Normalized Measurements",
        f"source: \"{source}\"",
        f"clock_mhz: {clock_mhz}",
        "",
        "normalized_metrics:",
    ]

    for n in normalized:
        lines.append(f"  - metric_name: \"{n['metric_name']}\"")
        lines.append(f"    sample_count: {n['sample_count']}")
        lines.append(f"    original_unit: \"{n['original_unit']}\"")
        lines.append(f"    mean: {n['mean']}")
        lines.append(f"    median: {n['median']}")
        lines.append(f"    min: {n['min']}")
        lines.append(f"    max: {n['max']}")
        lines.append(f"    normalized_unit: \"{n['normalized_unit']}\"")
        lines.append(f"    normalized_mean: {n['normalized_mean']}")
        lines.append(f"    normalized_median: {n['normalized_median']}")
        if "overhead_subtracted_cycles" in n:
            lines.append(f"    overhead_subtracted_cycles: {n['overhead_subtracted_cycles']}")

    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="Normalize raw measurements")
    parser.add_argument("input_file", type=Path, help="Raw measurements YAML")
    parser.add_argument("--clock-mhz", type=float, required=True,
                        help="Core clock frequency in MHz")
    parser.add_argument("--overhead-cycles", type=float, default=0,
                        help="Known measurement overhead in cycles to subtract")
    parser.add_argument("--output", "-o", type=Path, help="Output YAML (default: stdout)")
    args = parser.parse_args()

    if not args.input_file.exists():
        print(f"Error: File not found: {args.input_file}", file=sys.stderr)
        sys.exit(1)

    data = load_yaml_simple(args.input_file)
    normalized = normalize(data["measurements"], args.clock_mhz, args.overhead_cycles)
    yaml_output = format_yaml(normalized, args.clock_mhz, str(args.input_file))

    if args.output:
        args.output.write_text(yaml_output, encoding="utf-8")
        print(f"Normalized {len(normalized)} metrics → {args.output}")
    else:
        print(yaml_output)


if __name__ == "__main__":
    main()
