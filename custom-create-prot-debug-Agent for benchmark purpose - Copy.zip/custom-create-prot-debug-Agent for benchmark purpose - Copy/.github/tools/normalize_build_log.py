#!/usr/bin/env python3
"""
normalize_build_log.py - Parse IAR build log into structured diagnostics.

Reads raw IarBuild output and extracts errors, warnings, and remarks into
a structured format compatible with build_diagnostics.yaml template.

Usage:
    python normalize_build_log.py <build_log_file> [--output <output.yaml>]

Output:
    YAML-formatted diagnostics list with severity, code, file, line, message.
"""

import re
import sys
import argparse
from pathlib import Path

# IAR diagnostic pattern: "file.c(line) : severity[code]: message"
IAR_DIAG_PATTERN = re.compile(
    r'^"?(?P<file>[^"(]+)"?\((?P<line>\d+)\)\s*:\s*'
    r'(?P<severity>Error|Warning|Remark)\[(?P<code>[^\]]+)\]\s*:\s*'
    r'(?P<message>.+)$'
)

# Linker error pattern: "Error[code]: message"
IAR_LINK_PATTERN = re.compile(
    r'^(?P<severity>Error|Warning)\[(?P<code>[^\]]+)\]\s*:\s*(?P<message>.+)$'
)

# Build summary pattern
BUILD_SUMMARY_PATTERN = re.compile(
    r'Total number of (?P<type>errors|warnings): (?P<count>\d+)'
)


def classify_diagnostic(code: str) -> str:
    """Classify diagnostic by IAR error code prefix."""
    if code.startswith("Pe") or code.startswith("Pm"):
        return "compile"
    elif code.startswith("Li") or code.startswith("Lp"):
        return "link"
    elif code.startswith("De"):
        return "config"
    else:
        return "other"


def parse_build_log(log_path: Path) -> dict:
    """Parse IAR build log file into structured diagnostics."""
    diagnostics = []
    summary = {"errors": 0, "warnings": 0, "remarks": 0}

    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.rstrip()

            # Try file-level diagnostic
            match = IAR_DIAG_PATTERN.match(line)
            if match:
                diag = {
                    "severity": match.group("severity").lower(),
                    "code": match.group("code"),
                    "file": match.group("file"),
                    "line": int(match.group("line")),
                    "message": match.group("message"),
                    "classification": classify_diagnostic(match.group("code")),
                }
                diagnostics.append(diag)
                continue

            # Try linker-level diagnostic
            match = IAR_LINK_PATTERN.match(line)
            if match:
                diag = {
                    "severity": match.group("severity").lower(),
                    "code": match.group("code"),
                    "file": "",
                    "line": 0,
                    "message": match.group("message"),
                    "classification": "link",
                }
                diagnostics.append(diag)
                continue

            # Try summary line
            match = BUILD_SUMMARY_PATTERN.search(line)
            if match:
                summary[match.group("type")] = int(match.group("count"))

    # Count remarks from diagnostics if not in summary
    summary["remarks"] = sum(1 for d in diagnostics if d["severity"] == "remark")

    return {
        "summary": summary,
        "diagnostics": diagnostics,
    }


def format_yaml(result: dict) -> str:
    """Format parsed result as YAML."""
    lines = ["# Normalized Build Diagnostics", ""]
    lines.append("summary:")
    lines.append(f"  errors: {result['summary']['errors']}")
    lines.append(f"  warnings: {result['summary']['warnings']}")
    lines.append(f"  remarks: {result['summary']['remarks']}")
    lines.append("")
    lines.append("diagnostics:")

    for diag in result["diagnostics"]:
        lines.append(f"  - severity: {diag['severity']}")
        lines.append(f"    code: \"{diag['code']}\"")
        lines.append(f"    file: \"{diag['file']}\"")
        lines.append(f"    line: {diag['line']}")
        lines.append(f"    message: \"{diag['message']}\"")
        lines.append(f"    classification: {diag['classification']}")

    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="Normalize IAR build log to structured YAML")
    parser.add_argument("log_file", type=Path, help="Path to IAR build log file")
    parser.add_argument("--output", "-o", type=Path, help="Output YAML file (default: stdout)")
    args = parser.parse_args()

    if not args.log_file.exists():
        print(f"Error: File not found: {args.log_file}", file=sys.stderr)
        sys.exit(1)

    result = parse_build_log(args.log_file)
    yaml_output = format_yaml(result)

    if args.output:
        args.output.write_text(yaml_output, encoding="utf-8")
        print(f"Written to: {args.output}")
    else:
        print(yaml_output)

    # Exit with error if build had errors
    if result["summary"]["errors"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
