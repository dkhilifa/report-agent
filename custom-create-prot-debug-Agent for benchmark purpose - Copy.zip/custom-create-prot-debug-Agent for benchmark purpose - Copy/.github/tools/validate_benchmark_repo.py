#!/usr/bin/env python3
"""
validate_benchmark_repo.py - Validate benchmark repository structure and artifacts.

Checks:
1. Required folder structure exists
2. YAML files are well-formed
3. Schema enum values are valid
4. Template completeness
5. Config file references are consistent
6. Campaign dossier completeness (if campaigns exist)

Usage:
    python validate_benchmark_repo.py [--root <.github_dir>] [--strict] [--fix-structure]

Exit codes:
    0 = all checks pass
    1 = validation errors found
    2 = fatal error (cannot run)
"""

import sys
import argparse
from pathlib import Path
from typing import List, Tuple


# --- Expected Structure ---

REQUIRED_DIRS = [
    "config",
    "schemas/benchmark",
    "templates/benchmark-dossier",
    "tools",
    "agents",
    "skills",
    "prompts",
]

OPTIONAL_DIRS = [
    "benchmark/campaigns",
    "benchmark/analysis",
    "benchmark/ports",
    "benchmark/build",
    "benchmark/debug",
    "benchmark/measurements",
    "benchmark/validation",
    "benchmark/comparisons",
    "benchmark/enhancements",
]

REQUIRED_CONFIG_FILES = [
    "config/boards.yaml",
    "config/mcus.yaml",
    "config/toolchains.yaml",
    "config/vendors.yaml",
    "config/vendor_sources.yaml",
    "config/measurement_profiles.yaml",
    "config/board_registry_notes.md",
]

REQUIRED_SCHEMA_FILES = [
    "schemas/benchmark/campaign_manifest.schema.yaml",
    "schemas/benchmark/scenario_resolution.schema.yaml",
    "schemas/benchmark/source_provenance.schema.yaml",
    "schemas/benchmark/fairness_baseline.schema.yaml",
    "schemas/benchmark/execution_status.schema.yaml",
    "schemas/benchmark/hardware_approval.schema.yaml",
    "schemas/benchmark/semantic_summary.schema.yaml",
    "schemas/benchmark/measurement_metadata.schema.yaml",
    "schemas/benchmark/semantic_equivalence.schema.yaml",
    "schemas/benchmark/fairness_review.schema.yaml",
    "schemas/benchmark/comparison_delta.schema.yaml",
]

VALID_STATUSES = {"not_started", "in_progress", "pass", "pass_with_documented_gaps", "blocked", "fail"}
VALID_DIRECTIONS = {"stm32_to_competitor", "competitor_to_stm32", "vendor_to_vendor",
                    "board_to_board", "from_scratch", "from_name_only"}
VALID_STAGES = {"resolve_scenario", "identify_source", "identify_target", "acquire_materials",
                "analyze_semantics", "create_or_port", "configure_build", "build",
                "debug_preparation", "hardware_approval", "runtime_validation",
                "semantic_equivalence", "fairness_review", "generate_output"}


class ValidationResult:
    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.info: List[str] = []

    def error(self, msg: str):
        self.errors.append(f"ERROR: {msg}")

    def warn(self, msg: str):
        self.warnings.append(f"WARN: {msg}")

    def ok(self, msg: str):
        self.info.append(f"OK: {msg}")

    @property
    def passed(self) -> bool:
        return len(self.errors) == 0


def check_structure(root: Path, result: ValidationResult):
    """Check required directory structure."""
    for d in REQUIRED_DIRS:
        path = root / d
        if path.is_dir():
            result.ok(f"Directory exists: {d}")
        else:
            result.error(f"Missing required directory: {d}")

    for d in OPTIONAL_DIRS:
        path = root / d
        if path.is_dir():
            result.ok(f"Optional directory exists: {d}")
        else:
            result.warn(f"Optional directory missing: {d}")


def check_required_files(root: Path, result: ValidationResult):
    """Check required files exist."""
    for f in REQUIRED_CONFIG_FILES:
        path = root / f
        if path.is_file():
            result.ok(f"Config file exists: {f}")
        else:
            result.error(f"Missing config file: {f}")

    for f in REQUIRED_SCHEMA_FILES:
        path = root / f
        if path.is_file():
            result.ok(f"Schema file exists: {f}")
        else:
            result.error(f"Missing schema file: {f}")


def check_yaml_syntax(root: Path, result: ValidationResult):
    """Basic YAML syntax check (without PyYAML dependency)."""
    yaml_files = list(root.rglob("*.yaml")) + list(root.rglob("*.yml"))

    for yf in yaml_files:
        try:
            content = yf.read_text(encoding="utf-8")
            # Basic checks: no tabs for indentation, balanced quotes
            lines = content.splitlines()
            for i, line in enumerate(lines, 1):
                if line.startswith("\t"):
                    result.warn(f"{yf.relative_to(root)}:{i} - Tab indentation (use spaces)")
                    break
            result.ok(f"YAML readable: {yf.relative_to(root)}")
        except Exception as e:
            result.error(f"Cannot read YAML: {yf.relative_to(root)} - {e}")


def check_enum_values(root: Path, result: ValidationResult):
    """Spot-check known enum values in YAML files."""
    import re

    campaign_dir = root / "benchmark" / "campaigns"
    if not campaign_dir.is_dir():
        result.info.append("INFO: No campaigns to validate enum values")
        return

    for yf in campaign_dir.rglob("*.yaml"):
        content = yf.read_text(encoding="utf-8")
        rel = yf.relative_to(root)

        # Check status values
        for match in re.finditer(r'status:\s*"?(\w+)"?', content):
            val = match.group(1)
            if val not in VALID_STATUSES and val != "unknown":
                result.error(f"{rel}: Invalid status '{val}'")

        # Check workflow_direction
        for match in re.finditer(r'workflow_direction:\s*"?(\w+)"?', content):
            val = match.group(1)
            if val and val not in VALID_DIRECTIONS:
                result.error(f"{rel}: Invalid workflow_direction '{val}'")

        # Check stage_name
        for match in re.finditer(r'stage_name:\s*"?(\w+)"?', content):
            val = match.group(1)
            if val not in VALID_STAGES:
                result.error(f"{rel}: Invalid stage_name '{val}'")


VALID_BOARD_STATUSES = {"confirmed", "needs_official_confirmation"}
REQUIRED_BOARD_FIELDS = {"id", "vendor", "mcu", "family", "core"}
REQUIRED_MCU_FIELDS = {"id", "vendor", "family", "core"}


def check_board_registry(root: Path, result: ValidationResult):
    """Validate board and MCU registry entries for required fields and consistency."""
    import re

    boards_file = root / "config" / "boards.yaml"
    mcus_file = root / "config" / "mcus.yaml"

    # Check boards.yaml
    if boards_file.is_file():
        content = boards_file.read_text(encoding="utf-8")
        board_count = content.count("- id:")
        result.ok(f"Board registry: {board_count} entries")

        # Check for required fields in each board entry
        entries = re.split(r'\n  - id:', content)
        for i, entry in enumerate(entries[1:], 1):  # skip preamble
            entry_text = "- id:" + entry
            # Check id exists
            id_match = re.search(r'id:\s*"([^"]*)"', entry_text)
            board_id = id_match.group(1) if id_match else f"entry_{i}"

            for field in ["vendor", "mcu", "family", "core"]:
                if f"{field}:" not in entry_text:
                    result.warn(f"Board '{board_id}' missing field: {field}")

            # Check status is valid
            status_match = re.search(r'status:\s*"([^"]*)"', entry_text)
            if status_match:
                if status_match.group(1) not in VALID_BOARD_STATUSES:
                    result.error(f"Board '{board_id}': invalid status '{status_match.group(1)}'")
            else:
                result.warn(f"Board '{board_id}' missing status field")

            # Check aliases is present (for matching usability)
            if "aliases:" not in entry_text:
                result.warn(f"Board '{board_id}' missing aliases field")
    else:
        result.error("Board registry file not found")

    # Check mcus.yaml
    if mcus_file.is_file():
        content = mcus_file.read_text(encoding="utf-8")
        mcu_count = content.count("- id:")
        result.ok(f"MCU registry: {mcu_count} entries")

        entries = re.split(r'\n  - id:', content)
        for i, entry in enumerate(entries[1:], 1):
            entry_text = "- id:" + entry
            id_match = re.search(r'id:\s*"([^"]*)"', entry_text)
            mcu_id = id_match.group(1) if id_match else f"entry_{i}"

            for field in ["vendor", "family", "core"]:
                if f"{field}:" not in entry_text:
                    result.warn(f"MCU '{mcu_id}' missing field: {field}")

            # Check fairness_notes present
            if "fairness_notes:" not in entry_text:
                result.warn(f"MCU '{mcu_id}' missing fairness_notes")
    else:
        result.error("MCU registry file not found")


def create_missing_structure(root: Path):
    """Create missing optional directories with .gitkeep."""
    for d in OPTIONAL_DIRS:
        path = root / d
        if not path.is_dir():
            path.mkdir(parents=True, exist_ok=True)
            gitkeep = path / ".gitkeep"
            gitkeep.write_text("")
            print(f"Created: {d}/.gitkeep")


def main():
    parser = argparse.ArgumentParser(description="Validate benchmark repository structure")
    parser.add_argument("--root", type=Path, default=Path("."),
                        help="Root .github directory (default: current dir)")
    parser.add_argument("--strict", action="store_true",
                        help="Treat warnings as errors")
    parser.add_argument("--fix-structure", action="store_true",
                        help="Create missing optional directories")
    args = parser.parse_args()

    root = args.root.resolve()
    if not root.is_dir():
        print(f"Error: Root directory not found: {root}", file=sys.stderr)
        sys.exit(2)

    print(f"Validating benchmark repository: {root}")
    print("=" * 60)

    result = ValidationResult()

    check_structure(root, result)
    check_required_files(root, result)
    check_yaml_syntax(root, result)
    check_enum_values(root, result)
    check_board_registry(root, result)

    # Print results
    print()
    for msg in result.info:
        print(f"  {msg}")
    for msg in result.warnings:
        print(f"  {msg}")
    for msg in result.errors:
        print(f"  {msg}")

    print()
    print(f"Results: {len(result.info)} OK, {len(result.warnings)} warnings, {len(result.errors)} errors")

    if args.fix_structure:
        print()
        print("Fixing missing structure...")
        create_missing_structure(root)

    if args.strict and result.warnings:
        print("STRICT MODE: Warnings treated as errors.")
        sys.exit(1)

    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
