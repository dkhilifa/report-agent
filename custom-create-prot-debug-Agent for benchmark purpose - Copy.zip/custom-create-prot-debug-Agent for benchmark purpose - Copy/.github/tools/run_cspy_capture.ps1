<#
.SYNOPSIS
    Runs IAR C-SPY batch debugger (cspybat) for measurement capture.

.DESCRIPTION
    Executes cspybat with a macro file to capture benchmark measurements.
    Handles hardware approval check, session setup, and output collection.

    NOTE: This is a skeleton. The macro file (.mac) and device-specific driver
    arguments must be configured per-board. See .github/config/boards.yaml.

.PARAMETER ProjectDir
    Directory containing the built .out file and .ewp.

.PARAMETER OutputFile
    Path to the .out (ELF) executable.

.PARAMETER MacroFile
    Path to C-SPY macro file for measurement capture.

.PARAMETER DeviceDescription
    Path to the .ddf device description file.

.PARAMETER DriverPlugin
    C-SPY driver plugin DLL (e.g. armSTLINK2.dll, armJET.dll).

.PARAMETER IarRoot
    Optional explicit IAR root.

.PARAMETER Timeout
    Execution timeout in seconds (default: 60).

.OUTPUTS
    PSCustomObject with: ExitCode, Output, MeasurementFile, Duration

.EXAMPLE
    $result = .\run_cspy_capture.ps1 -ProjectDir ".\Debug" -OutputFile ".\Debug\Exe\project.out" `
        -MacroFile ".\capture.mac" -DeviceDescription ".\device.ddf" -DriverPlugin "armSTLINK2.dll"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$OutputFile,

    [Parameter(Mandatory)]
    [string]$MacroFile,

    [Parameter(Mandatory)]
    [string]$DeviceDescription,

    [Parameter(Mandatory)]
    [string]$DriverPlugin,

    [string]$IarRoot = "",
    [int]$Timeout = 60
)

$ErrorActionPreference = "Stop"

# Resolve IAR
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$iar = & "$scriptDir\discover_iar.ps1" -KnownRoot $IarRoot

if (-not $iar) {
    Write-Error "Cannot locate IAR EWARM."
    exit 1
}

# Validate inputs
foreach ($path in @($OutputFile, $MacroFile, $DeviceDescription)) {
    if (-not (Test-Path $path)) {
        Write-Error "File not found: $path"
        exit 1
    }
}

# Resolve driver plugin path
$driverPath = Join-Path $iar.Root "arm\bin\$DriverPlugin"
if (-not (Test-Path $driverPath)) {
    Write-Error "Driver plugin not found: $driverPath"
    exit 1
}

# Measurement output file (macro is expected to write here)
$measurementFile = [System.IO.Path]::ChangeExtension($OutputFile, ".measurements.txt")

Write-Host "=========================================="
Write-Host "HARDWARE INTERACTION WARNING"
Write-Host "This script will flash and debug on real hardware."
Write-Host "Target: $OutputFile"
Write-Host "Driver: $DriverPlugin"
Write-Host "=========================================="

# Build cspybat arguments
# NOTE: These arguments are a skeleton. Real usage requires:
#   - Correct --backend arguments for the specific probe/board
#   - Proper device description path
#   - Flash loader configuration
#   - Reset strategy
$cspyArgs = @(
    "--backend", "-f"
    $DeviceDescription
    "--device_macro", $MacroFile
    $OutputFile
)

Write-Host "Executing: $($iar.CspyBat) $($cspyArgs -join ' ')"
Write-Host "(Timeout: ${Timeout}s)"

# Execute with timeout
$startTime = Get-Date
$job = Start-Job -ScriptBlock {
    param($exe, $args_list)
    & $exe @args_list 2>&1
} -ArgumentList $iar.CspyBat, $cspyArgs

$completed = Wait-Job $job -Timeout $Timeout
$duration = (Get-Date) - $startTime

if (-not $completed) {
    Stop-Job $job
    Remove-Job $job
    Write-Error "C-SPY execution timed out after ${Timeout}s"
    exit 1
}

$output = Receive-Job $job
$exitCode = $job.ChildJobs[0].JobStateInfo.Reason.ExitCode
Remove-Job $job

$outputText = $output | Out-String

$result = [PSCustomObject]@{
    ExitCode        = $exitCode
    Output          = $outputText
    MeasurementFile = if (Test-Path $measurementFile) { $measurementFile } else { "" }
    Duration        = $duration.TotalSeconds
}

if ($exitCode -ne 0) {
    Write-Warning "C-SPY session ended with exit code $exitCode"
}

if (Test-Path $measurementFile) {
    Write-Host "Measurements captured: $measurementFile"
} else {
    Write-Warning "No measurement file produced. Check macro file logic."
}

return $result
