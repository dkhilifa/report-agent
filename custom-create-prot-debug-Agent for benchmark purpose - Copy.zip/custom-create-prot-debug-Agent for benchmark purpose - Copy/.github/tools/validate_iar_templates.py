"""
IAR Template Registry Validator

Validates the IAR template registry (config/iar_templates.yaml) against
boards.yaml, mcus.yaml, and the materialized template storage directory.

Reports:
- Templates with board_ids not found in boards.yaml
- Templates with families not found in mcus.yaml
- Missing family_fallback entries for families that have boards
- Templates marked 'available' but with no materialized project/ directory
- Templates with incomplete required fields

Usage:
    python validate_iar_templates.py [--workspace-root <path>]
"""

import argparse
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml", file=sys.stderr)
    sys.exit(1)


def load_yaml(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def validate(workspace_root: Path) -> list[dict]:
    issues = []
    config_dir = workspace_root / ".github" / "config"
    template_dir = workspace_root / ".github" / "benchmark" / "templates" / "iar"

    # Load registries
    iar_templates = load_yaml(config_dir / "iar_templates.yaml")
    boards_data = load_yaml(config_dir / "boards.yaml")
    mcus_data = load_yaml(config_dir / "mcus.yaml")

    # Build lookup sets
    board_ids = {b["id"] for b in boards_data.get("boards", [])}
    board_families = {b.get("family") for b in boards_data.get("boards", [])}
    mcu_families = {m.get("family") for m in mcus_data.get("mcus", [])}

    templates = iar_templates.get("templates", [])
    fallbacks = iar_templates.get("family_fallbacks", [])
    fallback_families = {f["family"] for f in fallbacks}
    template_ids = {t["template_id"] for t in templates}

    # Required fields for each template entry
    required_fields = [
        "template_id", "vendor", "board_id", "board_type", "family",
        "toolchain", "source_type", "mutability_policy", "confidence", "status"
    ]

    for tmpl in templates:
        tid = tmpl.get("template_id", "<unknown>")

        # Check required fields
        for field in required_fields:
            if not tmpl.get(field):
                issues.append({
                    "level": "error",
                    "template_id": tid,
                    "message": f"Missing required field: {field}"
                })

        # Check board_id exists in boards.yaml
        board_id = tmpl.get("board_id", "")
        if board_id and board_id not in board_ids:
            issues.append({
                "level": "warning",
                "template_id": tid,
                "message": f"board_id '{board_id}' not found in boards.yaml"
            })

        # Check family exists in mcus.yaml
        family = tmpl.get("family", "")
        if family and family not in mcu_families and family not in board_families:
            issues.append({
                "level": "warning",
                "template_id": tid,
                "message": f"family '{family}' not found in mcus.yaml or boards.yaml"
            })

        # Check materialization for 'available' templates
        if tmpl.get("status") == "available":
            tmpl_root = tmpl.get("template_root", "")
            if tmpl_root:
                project_dir = workspace_root / ".github" / tmpl_root / "project"
                if not project_dir.exists():
                    issues.append({
                        "level": "error",
                        "template_id": tid,
                        "message": f"Status is 'available' but project/ directory missing: {project_dir}"
                    })

        # Check source completeness for 'needs_download'
        if tmpl.get("status") == "needs_download":
            if not tmpl.get("source_url") and not tmpl.get("repo"):
                issues.append({
                    "level": "error",
                    "template_id": tid,
                    "message": "Status is 'needs_download' but no source_url or repo specified"
                })
            if not tmpl.get("template_path_in_source"):
                issues.append({
                    "level": "warning",
                    "template_id": tid,
                    "message": "Status is 'needs_download' but template_path_in_source is empty"
                })

    # Check fallbacks reference valid template_ids
    for fb in fallbacks:
        fid = fb.get("fallback_template_id", "")
        if fid and fid not in template_ids:
            issues.append({
                "level": "error",
                "template_id": f"fallback:{fb.get('family', '?')}",
                "message": f"fallback_template_id '{fid}' not found in templates[]"
            })

    # Check for families with boards but no fallback
    for family in board_families:
        if family and family not in fallback_families:
            # Check if at least one template covers this family
            family_templates = [t for t in templates if t.get("family") == family]
            if not family_templates:
                issues.append({
                    "level": "info",
                    "template_id": f"family:{family}",
                    "message": f"Family '{family}' has boards but no template or fallback entry"
                })

    return issues


def main():
    parser = argparse.ArgumentParser(description="Validate IAR template registry")
    parser.add_argument("--workspace-root", type=Path, default=Path("."),
                        help="Workspace root directory (default: current directory)")
    args = parser.parse_args()

    # Resolve workspace root
    root = args.workspace_root.resolve()
    if not (root / ".github" / "config" / "iar_templates.yaml").exists():
        # Try .github as root
        if (root / "config" / "iar_templates.yaml").exists():
            root = root.parent
        else:
            print(f"ERROR: Cannot find iar_templates.yaml from root: {root}", file=sys.stderr)
            sys.exit(1)

    print(f"Validating IAR templates from: {root}")
    print("=" * 60)

    issues = validate(root)

    if not issues:
        print("✓ All validations passed. No issues found.")
        return 0

    # Group by level
    errors = [i for i in issues if i["level"] == "error"]
    warnings = [i for i in issues if i["level"] == "warning"]
    infos = [i for i in issues if i["level"] == "info"]

    if errors:
        print(f"\n✗ ERRORS ({len(errors)}):")
        for i in errors:
            print(f"  [{i['template_id']}] {i['message']}")

    if warnings:
        print(f"\n⚠ WARNINGS ({len(warnings)}):")
        for i in warnings:
            print(f"  [{i['template_id']}] {i['message']}")

    if infos:
        print(f"\n○ INFO ({len(infos)}):")
        for i in infos:
            print(f"  [{i['template_id']}] {i['message']}")

    print(f"\nTotal: {len(errors)} errors, {len(warnings)} warnings, {len(infos)} info")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
