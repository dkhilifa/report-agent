---
name: diagram-generation
description: "Use when: creating Mermaid diagrams, draw.io diagrams, workflow diagrams, scenario diagrams, benchmark architecture diagrams, porting flow diagrams, or presentation-friendly visuals for any vendor/direction."
---

# Diagram Generation Skill

Use this skill to turn embedded benchmark source code, agent architecture, porting workflows, or runtime evidence into technical and presentation-friendly diagrams. Works with any vendor direction.

## Supported Outputs
- Mermaid technical workflow diagrams.
- Mermaid slide-friendly diagrams.
- draw.io `.drawio` architecture or workflow files.
- Presentation guide text and talk tracks.
- Porting flow diagrams (source → target with layer separation).

## Diagram Workflow
1. Inspect source files, customization files, README files, result files, or logs before drawing.
2. Identify the scenario entry point, initialization sequence, main loop, tasks, interrupts, callbacks, peripherals, counters, reporting path, and success/error behavior.
3. Separate technical details from presentation-level story.
4. Mark vendor-specific, uncertain, or invalid/incomplete behavior when it matters.
5. Keep diagrams readable enough for reviews and slides.
6. When diagramming ports, show source and target side-by-side with clear layer boundaries.

## Technical Diagram Guidance
- Include entry points, hardware setup, RTOS/middleware setup, event loops, interrupts, DMA/peripheral interactions, state transitions, counters, reports, and error paths.
- Preserve exact behavior in technical diagrams.

## Slide-Friendly Diagram Guidance
- Use plain labels such as initialize hardware, wait for event, transfer data, check result, report behavior, or diagnose issue.
- Avoid low-level API names unless the API is the point of the slide.
- Prefer fewer nodes and a clear narrative.

## Output Structure
1. Objective
2. Assumptions
3. Source evidence inspected
4. Technical diagram
5. Slide-friendly diagram
6. Plain-language summary
7. Manual validation points
8. Benchmark fairness risks, if applicable

## File Naming
- General diagrams: `embedded_workflow_diagrams.md` or `embedded_presentation_workflow_diagrams.md`.
- Benchmark diagrams: `benchmark_workflow_diagrams.md` or `<scenario>_workflow_diagrams.md`.
- draw.io architecture diagrams: `<topic>_architecture.drawio`.