---
name: benchmark-analysis
description: "Use when: analyzing embedded benchmark projects, classifying files, extracting exact benchmark semantics, identifying portability boundaries, preparing a project before code generation, or analyzing acquired source material from any vendor."
---

# Benchmark Analysis Skill

Use this skill before porting, creating from scratch, refactoring, or generating code from an existing benchmark project. Works with projects from any vendor (STM32, GD32, NXP, TI, Renesas, or other).

## Inputs
- Project tree, README, source files, build files, or result files.
- Optional target platform/toolchain if the analysis is preparing a port.
- Acquired source material (from web or SDK) with provenance metadata.
- Scenario description if creating from scratch.

## Workflow
1. Identify the benchmark entry point and observable output.
2. Classify files as portable, partially portable, RTOS-specific, board/vendor-specific, generated, build-only, or result-only.
3. Extract exact runtime semantics:
   - task/thread count, creation order, priorities, delays, and periodicity
   - interrupts, callbacks, DMA, timers, queues, semaphores, mutexes, events, and polling loops
   - counters, state transitions, measurement start/end scopes, and reset behavior
   - reporting/log/output format and success/error paths
4. Identify portability boundaries:
   - portable benchmark logic (vendor-independent)
   - RTOS/middleware integration (API-specific but semantically portable)
   - board/vendor drivers and pin/peripheral mapping
   - toolchain/startup/linker/build files
5. Identify vendor-specific constructs that need mapping (not preservation) when porting.
6. Identify missing inputs, unverified provenance, and risks before generation.
7. Identify fairness-sensitive aspects visible in the source (optimization pragmas, clock setup, timer selection, measurement boundaries).

## Output Structure
1. Objective
2. Source platform and provenance
3. Assumptions
4. File classification table
5. Semantic summary (observable behaviors)
6. Portability split (portable / RTOS / board / build)
7. **Mutability classification** (writable / protected / configure-only per file)
8. Vendor-specific constructs requiring mapping
9. Fairness-sensitive aspects found
10. Missing inputs
11. Unresolved unknowns
12. Manual validation points

## Mutability Classification
For every classified file, assign a mutability policy:
- **writable** — application-layer files the agent may create or modify freely.
- **protected** — vendor baseline files (HAL, BSP, startup, linker, middleware, drivers) that must not be modified without explicit user approval.
- **configure-only** — build surface files where references and settings may be changed, but vendor file content must not be edited.

When a benchmark appears to require changes to protected-surface files, flag those scenarios explicitly as potential approval-required deviations.

## Rules
- Source code is the truth when documentation conflicts with implementation.
- Do not generate target code during analysis unless explicitly requested.
- Do not modify reference projects unless explicitly requested.
- Works with reference projects from any vendor, not just STM32.
- Apply the always-on benchmark rules from `.github/copilot-instructions.md`.