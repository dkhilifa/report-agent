---
name: result-interpretation
description: "Use when: interpreting and comparing benchmark results between any two platforms (STM32, GD32, NXP, TI, Renesas, or other) from logs, UART output, debugger captures, timing, footprint data, or runtime observations, or generating comparative result-file content."
---

# Result Interpretation Skill

Use this skill when turning benchmark evidence from two platforms into a comparative report, result file, or conclusion. Works with any vendor combination.

## Evidence Types
- Compiler and linker output (per platform).
- C-SPY, pyOCD, debugger, UART, or host-side logs (per platform).
- Timing counters, DWT values, cycle counts, throughput, latency, or footprint measurements.
- Runtime observations such as USB enumeration, cursor movement, task behavior, or error states.
- Acquired/provenance metadata for source material.

## Interpretation Rules
- Identify the two platforms from the given project; do not assume a fixed pairing or direction.
- Compare like-for-like: same scenario, build mode, optimization, clock source, and measurement scope on both sides.
- Separate raw facts from interpretation, and keep each platform's measurements clearly attributed.
- Report the gap (delta and direction) per metric, not just absolute values.
- Do not over-claim from incomplete data; if one side lacks evidence, mark it as an unresolved unknown.
- Preserve raw measurements and metadata where possible.
- Call out anomalies, missing evidence, and any fairness difference that could explain the gap rather than a true capability difference.
- Classify each gap as: confirmed real gap, fairness artifact, or uncertain.

## Output Structure
1. Metadata summary (both platforms, with provenance if acquired)
2. Expected behavior
3. Observed behavior per platform
4. Side-by-side comparison (per-metric delta and direction)
5. Gap classification (real gap / fairness artifact / uncertain)
6. Measurements summary
7. Issues/anomalies
8. Fairness notes
9. Unresolved unknowns
10. Result file content

## Rules
- Do not assume STM32 is always the reference — either platform may be.
- Report unknowns explicitly; never fill gaps with assumptions.
- Apply the fairness checklist from copilot-instructions.md before drawing conclusions.