---
name: semantic-equivalence
description: "Use when: comparing reference and target benchmark behavior in any porting direction (STM32→competitor, competitor→STM32, vendor→vendor, board→board), checking semantic equivalence, finding behavioral drift, or assessing fairness impact."
---

# Semantic Equivalence Skill

Use this skill whenever a target implementation is compared with a reference benchmark. Works in all porting directions — the reference may be STM32, a competitor, or any vendor.

## Core Principle
Preserve **observable behaviors and semantics**, not vendor API names. Two implementations are equivalent when they produce the same benchmark-observable behavior, regardless of which vendor APIs they use internally.

## Equivalence Checklist
Compare the reference and target for:
- task/thread count and creation order
- priorities and scheduling behavior
- delays, periodicity, timeout behavior, and tick/timer sources
- synchronization behavior, queues, semaphores, mutexes, events, and timers
- suspend/resume, yield, interrupt, callback, and DMA behavior
- counters, state transitions, measurement start/end scopes, and reset behavior
- reporting/log/output format and observable host/device behavior
- success, warning, timeout, and error behavior

## Assessment Categories
- **Equivalent**: behavior matches within the benchmark definition.
- **Equivalent with caveats**: behavior matches, but environment or implementation details affect fairness.
- **Drift**: behavior differs and may affect results.
- **Approval required**: an intentional deviation must be accepted by the user.
- **Protected-surface modification**: the target implementation modifies vendor baseline files — flag as approval-required deviation with fairness/portability risk.
- **Unknown**: evidence is insufficient.

## Fairness Cross-Check
When assessing equivalence, also check and report:
- Optimization level differences
- Clock/timer source differences
- RTOS wrapper/scheduling implementation differences
- Memory placement/cache/DMA configuration differences
- Measurement scope and instrumentation differences
- Startup/init sequence differences

## Output Structure
1. Reference platform and semantics
2. Target platform and semantics
3. Porting direction (e.g., STM32→GD32, NXP→STM32)
4. Equivalence assessment per behavior category
5. Differences found (semantic vs implementation-only)
6. Fairness impact
7. Approval-required deviations
8. Unresolved unknowns
9. Validation checklist

## Rules
- Preserve semantics, not vendor APIs.
- Do not silently accept behavioral drift.
- If exact equivalence is impossible, state it explicitly.
- Do not claim equivalence without enough source, build, runtime, or measurement evidence.
- Works bidirectionally — STM32 can be either reference or target.
- Mark unverifiable claims as unresolved unknowns.
- **Flag any target changes that modify protected-surface files** (HAL, BSP, startup, linker, middleware) as approval-required deviations with fairness and portability risk assessment.