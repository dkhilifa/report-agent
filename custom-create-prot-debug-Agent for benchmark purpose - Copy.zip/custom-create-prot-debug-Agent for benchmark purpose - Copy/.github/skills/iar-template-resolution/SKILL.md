---
name: iar-template-resolution
description: "Resolve, acquire, and integrate IAR project templates per board. Use when: creating a new benchmark project, porting to a new board, or needing an IAR project baseline for any supported board type."
references:
  - ../config/iar_templates.yaml
  - ../config/boards.yaml
  - ../config/mcus.yaml
  - ../config/vendor_sources.yaml
  - ../config/toolchains.yaml
  - ../benchmark/templates/iar/README.md
---

# IAR Template Resolution Skill

## Purpose
Deterministically resolve the correct IAR project template for a given board, then acquire and integrate it as a read-only baseline for benchmark project creation.

## When to Use
- Creating a new benchmark project from scratch
- Porting a benchmark to a new board/vendor
- Setting up an IAR project foundation for any supported board
- Verifying template availability before starting a campaign

## Resolution Algorithm

### Step 1: Identify Target
From the user request or campaign context, determine:
- `board_id` (exact board from `boards.yaml`)
- `family` (MCU family from `mcus.yaml`)
- `board_type` (nucleo, launchpad, frdm, ek, eval, etc.)
- `vendor` (ST, TI, NXP, Renesas, GigaDevice, etc.)

### Step 2: Template Lookup
Search `config/iar_templates.yaml` in this order:

1. **Exact board_id match**
   - Search `templates[]` for entry where `board_id` matches exactly
   - If found and `status != "unresolved"` → use this template

2. **Family fallback**
   - Search `family_fallbacks[]` for `family` match
   - If found → use the referenced `fallback_template_id`
   - Note: device, startup, and linker must be adjusted for the actual target MCU

3. **Board type fallback** (same vendor)
   - Search `templates[]` for entries matching `board_type` + `vendor`
   - Select closest match by MCU family proximity
   - Explicitly downgrade confidence

4. **Unresolved**
   - No suitable template found
   - Document the gap in campaign artifacts
   - Do NOT invent or fabricate a template

### Step 3: Acquisition (if status == "needs_download")
When a template is identified but not yet materialized:

1. Check workspace first: `benchmark/templates/iar/<vendor>/<board-id>/project/`
2. Check local SDK: IAR installation at `C:\iar\ewarm-9.60.3\arm\config\`
3. Fetch from source:
   - For `official_github`: sparse checkout or full clone from `repo` at `branch`/`tag`
   - For `official_sdk_bundle`: download from `source_url`
   - For `local_sdk`: copy from installed SDK path
4. Extract template path: copy files from `template_path_in_source` into local `template_root/project/`
5. Update `template_manifest.yaml`:
   - Set `materialization_status: "materialized"`
   - Set `materialized_date`
   - Populate `file_inventory`
6. Update `provenance.yaml`:
   - Set `acquisition.method`, `acquisition.date`
   - Set `source.commit` or `source.tag` if known
7. Update `config/iar_templates.yaml`:
   - Change entry `status` from `"needs_download"` to `"available"`

### Step 4: Integration
Once the template is materialized, integrate it as the project foundation:

1. **Copy** template project files to the benchmark port directory
2. **Preserve** all baseline infrastructure unchanged:
   - Startup file
   - Linker configuration
   - System initialization
   - HAL/BSP source files
   - Device/debugger settings in .ewp
3. **Add** benchmark application code through designated integration points:
   - Replace or extend the application entry point file
   - Add benchmark source files to the user source group
   - Add include paths for benchmark headers
   - Add preprocessor defines for benchmark configuration
4. **Do NOT modify** protected surfaces without deviation approval

### Step 5: Provenance Recording
Record in `source_provenance.yaml` (campaign dossier):
```yaml
- resource_name: "IAR board template"
  resource_type: "example_project"
  vendor: "<vendor>"
  url: "<source_url>"
  repo_or_package: "<repo>"
  branch: "<branch>"
  tag: "<tag>"
  commit: "<commit>"
  acquisition_method: "<method>"
  selection_reason: "Board-specific IAR template baseline from iar_templates.yaml registry"
  local_path: "benchmark/templates/iar/<vendor>/<board-id>/project/"
  provenance_verified: true/false
```

## Fallback Adjustments
When using a family-level fallback template for a different board in the same family:

1. **Startup file**: Replace with correct MCU-specific startup (from `mcus.yaml` → `startup_note`)
2. **Linker file**: Replace with correct MCU-specific linker (from `mcus.yaml` → `linker_note`)
3. **Device selection**: Update `.ewp` device configuration for target MCU
4. **Flash/RAM sizes**: Verify linker file matches target MCU memory map
5. **Document**: Note in provenance that a family fallback was used with adjustments

## Unresolved Template Handling
If resolution returns `status: "unresolved"`:

1. Document the gap clearly in campaign notes
2. Check if a `derived_local` template can be created:
   - Use CMSIS-Pack device support files from IAR installation
   - Use vendor-provided startup/linker from SDK without a full project
   - Create minimal .ewp scaffold referencing correct device files
3. If creating a derived template:
   - Mark `source_type: "derived_local"` and `status: "derived"`
   - Set `confidence: "low"` or `"medium"`
   - Add explicit notes that this is NOT an official vendor template
4. If no derivation is possible:
   - Report to user that no IAR template is available for this board
   - Suggest alternative boards in the same family that have templates

## Protected Surface Deviation
If benchmark requirements CANNOT be met through application-layer-only integration:

1. Identify the specific baseline file that needs modification
2. Document WHY the modification is needed
3. Request approval via the hardware approval / protected-surface deviation gate
4. If approved: make minimal, documented change with revert instructions
5. Record deviation in campaign `fairness_baseline.yaml`

## Template File Roles
| File pattern | Role | Protected? |
|---|---|---|
| `*.ewp` | IAR project file | Device/debugger settings: YES. Source groups: additions OK |
| `*.eww` | IAR workspace | NO (informational) |
| `startup_*.s` / `startup_*.c` | MCU startup code | YES |
| `*.icf` | Linker configuration | YES |
| `system_*.c` | System clock init | YES |
| `main.c` / `app.c` / `empty.c` | App entry point | NO — this is where benchmark code goes |
| HAL/BSP drivers | Vendor peripheral drivers | YES |
| Board init (clock_config, pin_mux) | Board-specific initialization | YES |
