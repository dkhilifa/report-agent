---
name: stm32-enhancement
description: "Use when: recommending STM32 benchmark enhancements or portability improvements derived from the measured gap between STM32 and any competitor MCU, or when reviewing STM32 reference project quality for porting readiness."
---

# STM32 Enhancement Skill

Use this skill to recommend improvements to STM32 reference projects that are justified by observed gaps, porting needs, or portability review — without changing benchmark meaning.

## Gap-Driven Approach
- Identify the competitor and platform from the given project (GD32, NXP, TI, Renesas, or other); do not assume a fixed competitor.
- Start from real comparison evidence (footprint deltas, speed/execution counts, scheduling behavior, result files) in the given project, not assumptions.
- For each enhancement, name the specific STM32-vs-competitor gap it addresses and the evidence source.
- Distinguish a true capability/performance gap from a measurement or fairness artifact before recommending a change.
- Do not invent competitor advantages or vendor APIs; if the gap is unverified, mark it as an unresolved unknown.

## Gap Categories To Assess
- Footprint gap: flash/RAM size, layer/function-level deltas, linker placement, library overhead.
- Speed/execution gap: execution counts, timing, clock source, optimization level, debug vs release.
- Scheduling gap: task count/order, priorities, delays, periodicity, synchronization, yield/suspend behavior.
- Portability gap: STM32-specific HAL/BSP coupling, board/clock/pin/peripheral/DMA/cache/memory assumptions.
- Fairness gap: RTOS wrapper differences, logging/instrumentation overhead, environmental and configuration differences.
- Reporting gap: result format, observable output, and log semantics relative to the competitor.

## Portability Review Mode
When used for porting readiness (not gap-driven):
- Assess how easily the STM32 reference can be ported to any target.
- Identify tightly-coupled HAL/BSP dependencies.
- Recommend layer separation improvements.
- Identify measurement-scope or instrumentation that may not port cleanly.

## Recommendation Rules
- Do not change benchmark semantics unless the user explicitly approves it.
- Prefer structural improvements that close the gap or make it measurable, while keeping comparisons fair.
- **Prefer application-layer changes.** Recommendations that require modifying protected surfaces (HAL, BSP, startup, linker, middleware) must be flagged as approval-required deviations with fairness and maintenance impact.
- Separate recommendations by risk and effort, and mark any that could affect benchmark results.
- Code is the truth source if it conflicts with docs.
- This skill may be used whether STM32 is the reference or the target of comparison.

## Output Structure
1. Objective
2. Observed gap (with evidence source) or portability assessment
3. Gap classification (capability vs fairness/measurement artifact)
4. Recommended enhancements (ranked by impact/effort/risk)
5. Portability impact
6. Fairness impact
7. Unresolved unknowns
8. Suggested implementation order