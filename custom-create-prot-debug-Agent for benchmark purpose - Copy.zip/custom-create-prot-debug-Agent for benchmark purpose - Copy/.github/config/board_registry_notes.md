# Board & MCU Registry Notes

## Purpose

The files in `.github/config/` provide the benchmark agent with a knowledge base
of boards, MCUs, vendors, and sources. This enables:

- Automatic board/MCU identification from user prompts
- Alias-based fuzzy matching (e.g., "nucleo c5" → NUCLEO-C5A3ZG)
- Fairness-aware platform comparison
- Deterministic source acquisition
- Portability reasoning across families

## Naming Conventions

### Board IDs
- Use the **exact official vendor identifier** as printed on PCB silk-screen or vendor product page.
- Case-sensitive (e.g., `NUCLEO-C5A3ZG`, not `Nucleo-C5A3ZG`).
- Hyphens preserved as in official docs.

### MCU IDs
- Use a representative full part number for the family entry.
- Family-level entries are preferred over per-part-number entries.
- Add subfamily entries only when characteristics differ significantly within a family.

### Aliases
- Include: official name, shortened form, family shorthand, common chat phrasing.
- Example: `["NUCLEO-C5A3ZG", "nucleo c5a3", "nucleo c5", "stm32c5 nucleo"]`
- Aliases are case-insensitive for matching purposes.

## Status Values

| Status | Meaning |
|--------|---------|
| `confirmed` | Board/MCU verified on official vendor product pages or datasheets |
| `needs_official_confirmation` | Requested by user or expected from naming conventions, but not yet verified on an official product page |

## Handling Unresolved Items

When a requested board or family cannot be fully confirmed:

1. **Do not invent** part numbers, board names, or specifications.
2. **Do add an entry** with `status: needs_official_confirmation`.
3. **Add a `notes:` field** explaining what is known and what is uncertain.
4. **Preserve the user's requested name** so it remains searchable.
5. **Mark specific fields as "(expected)"** when inferred from naming conventions.

Example:
```yaml
- id: "LP-MSPM3304"
  status: "needs_official_confirmation"
  notes: "LaunchPad board ID follows TI convention but exact availability unverified."
```

## Extending the Registry

### Adding a new board
1. Verify board exists on official vendor product page.
2. Add entry with all required fields (id, vendor, mcu, family, core, board_type, probe).
3. Add `aliases` for discoverability.
4. Add `official_url` pointing to vendor product page.
5. Set `status: confirmed`.
6. Add relevant `measurement_capabilities`.

### Adding a new MCU family
1. Verify family exists in vendor's official product portfolio.
2. Add representative MCU entry with key specs.
3. Add `fairness_notes` for benchmark-relevant hardware characteristics.
4. Add `aliases` for user matching.

### Adding a new vendor
1. Update `vendors.yaml` with families, aliases, SDK framework.
2. Update `vendor_sources.yaml` with acquisition sources.
3. Add board and MCU entries as needed.

## Official Source Preference

All entries should be traceable to official vendor evidence:
- Product pages (st.com, ti.com, nxp.com, etc.)
- Official GitHub repositories
- Datasheets and user manuals
- Press releases / product announcements

Third-party blogs, forums, or speculation are not sufficient for `confirmed` status.

## Families Requiring Special Attention

### STM32C5
- **Status**: Confirmed official (st.com product page active, Nucleo boards available)
- **Core**: Cortex-M33 @ 144 MHz
- **Key differentiator**: Entry-level cost with M33 performance (3x over typical M0+)
- **STM32Cube repo**: Expected as `STMicroelectronics/STM32CubeC5`

### MSPM0
- **Status**: Confirmed official (ti.com, LaunchPads shipping)
- **Core**: Cortex-M0+ @ 24/32/80 MHz
- **Sub-families**: MSPM0G (80 MHz), MSPM0L (32 MHz), MSPM0C (24 MHz)
- **SDK**: MSPM0-SDK (actively maintained)

### MSPM33
- **Status**: Confirmed official in TI portfolio overview
- **Core**: Cortex-M33 @ 160 MHz with TrustZone, FPU
- **Product status**: PREVIEW (not yet general availability as of mid-2026)
- **LaunchPad**: Expected as LP-MSPM3304 (naming convention) — needs board-level confirmation
- **SDK**: Expected as MSPM33-SDK — availability needs verification
- **Note**: Direct competitor to STM32C5 (144 MHz M33) and NXP MCX N (150 MHz M33)
