# Copilot Instructions for Embedded Benchmark Workspace

This workspace is focused on embedded MCU benchmarks, RTOS and middleware comparisons, and cross-vendor ports between STM32 reference projects and competitor MCU platforms.

## Always-On Benchmark Rules
- Treat reference benchmark projects, especially STM32 projects, as read-only unless the user explicitly asks to modify them.
- Preserve benchmark semantics exactly unless the user explicitly approves a deviation.
- Do not silently simplify, redesign, optimize, or reinterpret a benchmark.
- Generate new target projects instead of rewriting reference projects.
- Separate portable application logic, RTOS logic, and board/vendor-specific code.
- Do not invent vendor APIs, pin mappings, peripheral choices, or board details.
- If hardware details are uncertain, mark them as TODO or unresolved unknowns.
- Do not claim runtime validation unless actual compiler output, runtime logs, UART logs, debugger captures, or hardware observations are provided.

## Semantic Preservation Checklist
Preserve these observable behaviors during analysis, creation, porting, debugging, and comparison:
- task count and task creation order
- task priorities and scheduling behavior
- delays, periodicity, and timeout behavior
- synchronization, queues, semaphores, mutexes, events, and timers
- suspend/resume behavior and yield behavior
- counters, state transitions, and measurement scopes
- reporting format, observable output, and log semantics
- success, warning, timeout, and error behavior

## Benchmark Fairness Checklist
Always consider and call out fairness risks such as:
- optimization level and debug vs release build mode
- RTOS wrapper/API differences
- clock frequency and timer source differences
- memory size, linker placement, stack, heap, cache, DMA, and interrupt configuration
- board peripheral differences and pin/connector mappings
- UART/logging overhead and measurement instrumentation overhead
- storage, network, USB host, cable, hub, OS, and environmental differences

## Customization Architecture
- Use custom agents only for specialist roles that benefit from context isolation, tool boundaries, or multi-step delegated reasoning.
- Use skills for reusable workflows, checklists, templates, and presentation/diagram assets.
- Use prompts for narrow one-shot deliverables.
- Keep this file as the single source of always-on benchmark policy; agents and skills should reference these rules instead of duplicating them.

## Supported Benchmark Workflows
The system supports these benchmark workflows in all directions:
- **STM32 → competitor**: port STM32 reference benchmark to a competitor target.
- **Competitor → STM32**: port a competitor reference to an STM32 target.
- **Vendor A → Vendor B**: port between any two non-ST vendors.
- **Board A → Board B**: reproduce a ready scenario on a different board (same or different vendor).
- **Scenario description → new project from scratch**: create a benchmark project from only a textual scenario description.
- **Firmware/benchmark name only → acquire and build**: resolve, acquire, and build from a name alone.

In all cases, preserve benchmark semantics (not vendor API names). Generate a new target project rather than modifying the reference.

## Active Agent Roles
- `MCU-Benchmark-Agent`: user-facing autonomous campaign coordinator and router.
- `Creation-Porting`: new benchmark creation from scratch, cross-vendor porting in all directions.
- `Build-Project`: autonomous IAR build execution, project configuration, and build-failure triage.
- `Debugger`: evidence-driven autonomous diagnosis, measurement extraction, and revalidation.

## Reusable Skill Roles
- `benchmark-analysis`: project understanding, file classification, semantics extraction, and portability split.
- `semantic-equivalence`: reference-vs-target behavior comparison and drift analysis.
- `stm32-enhancement`: STM32 reference portability and maintainability review.
- `result-interpretation`: benchmark log, measurement, and result-file interpretation.
- `diagram-generation`: Mermaid, draw.io, and presentation-friendly workflow diagrams.
- `iar-template-resolution`: resolve, acquire, and integrate IAR project templates per board type.

## Required Working Style
- Prefer small reviewable steps.
- Prefer structured output.
- For benchmark work, include assumptions, unresolved unknowns, manual validation points, and benchmark fairness risks.

---

## Board Firmware Baseline Immutability Rule

Vendor SDK, HAL, LL, BSP, startup, linker, middleware, and driver files constitute **read-only baseline infrastructure**. Agents must integrate benchmarks at the application layer only, preserving the board firmware baseline intact.

### Protected Surfaces (read-only by default)
These files must not be created, modified, or replaced without explicit user approval:
- RTOS kernel internals (e.g., FreeRTOS `tasks.c`, `queue.c`, `port.c`)
- Middleware internals (USB stack, filesystem, network stack, crypto libraries)
- HAL / LL driver implementation files (e.g., `stm32u5xx_hal_gpio.c`, `gd32e50x_rcu.c`)
- BSP source files
- Startup assembly files (`startup_*.s`)
- Linker configuration scripts (`.icf`, `.ld`, `.sct`)
- System initialization internals (`system_*.c`)
- Vendor peripheral driver source
- SDK / framework internal source files
- CMSIS core files and vendor device headers

### Writable Surfaces (create/modify freely)
These files are the default working surface — no approval needed:
- Benchmark application source files (e.g., `main.c`, `benchmark_tasks.c`)
- Benchmark application headers
- App-owned wrappers and adapters (e.g., `app_hal_bridge.c`, `app_clock_adapter.h`)
- App-level orchestration and integration modules
- App-level measurement and instrumentation code
- Benchmark-specific app-owned configuration
- App-level glue code that calls into vendor APIs without modifying them

### Build-Surface Actions (allowed, no approval needed)
- Selecting which existing vendor-provided file to reference in the project
- Adjusting project include paths, source groups, and preprocessor defines
- Changing project metadata (`.ewp`) to point at the correct vendor file
- Choosing a startup or linker file from the vendor-provided set
- Setting optimization level, FPU, device, and debugger options

### Approval-Required Deviations
If a benchmark cannot be implemented purely within the writable surface:
1. Do **not** make the change silently.
2. Identify the exact protected-surface file, its layer, and the proposed change.
3. Explain why the application layer alone is insufficient.
4. Propose the smallest possible change.
5. Request explicit user approval before proceeding.
6. Record the exception in `baseline_exceptions.yaml` in the campaign dossier.
7. Assess and report fairness, portability, and maintenance impact.

### Key Distinction: Selection vs. Modification
- **Selection** (allowed): choosing `startup_stm32u575xx.s` from the vendor SDK and referencing it in the project.
- **Modification** (approval-required): editing the content of `startup_stm32u575xx.s` to add instrumentation, change the vector table, or alter initialization sequences.

---

## Autonomous Benchmark Execution Policy

### Default Autonomy
All benchmark agents operate autonomously by default. They may perform the following without user confirmation:
- Read, search, and inspect any workspace file or project artifact.
- Create, edit, or reorganize **application-layer** project files, source code, configuration, and build scripts (respecting the Board Firmware Baseline Immutability Rule above).
- Run safe local commands: build, compile, link, parse diagnostics, inspect binaries.
- Fix project configuration issues (include paths, defines, source groups, linker/startup selection, device settings).
- Re-run build/debug preparation loops when the issue is clearly fixable.
- Fetch official vendor files, firmware examples, SDK content, CMSIS packs, BSP files, startup/linker templates, and documentation from the web.
- Parse and interpret build logs, runtime logs, UART output, debugger captures, and measurement data.

### Mandatory Approval Gate
The agent **must** ask for explicit user approval before:
- Flashing or programming code to a physical board.
- Erasing or resetting a physical device.
- Attaching a live debug probe to real hardware in a way that changes device state.

After the user grants one explicit board-programming approval within a session, the agent may continue autonomously through the remaining flash → debug → measure → report sequence for that board without re-asking, unless a new board or destructive action is introduced.

### External Acquisition Policy
When materials are missing (firmware, examples, startup files, linker files, CMSIS headers, BSP, device descriptions, vendor documentation), the agent acquires them autonomously using this preference order:
1. Workspace files already present.
2. Local SDK content (e.g., IAR device/config directories, installed CMSIS packs).
3. Official vendor GitHub repositories (tagged releases or main branch).
4. Official vendor websites, example bundles, SDK packages, CMSIS pack index.
5. Third-party mirrors — only as last resort.

The agent must record the provenance of each acquired resource (URL, version, branch/tag/commit, package name) in its output.

### IAR Toolchain Access
IAR EWARM 9.60.3 is installed at `C:\iar\ewarm-9.60.3`. Agents may use the following binaries without user confirmation:
- `IarBuild.exe` — for command-line project builds.
- `cspybat.exe` — for batch-mode debug/simulation (non-hardware sessions).

Discovery order:
1. `C:\iar\ewarm-9.60.3\common\bin\IarBuild.exe`
2. `C:\iar\ewarm-9.60.3\arm\bin\iccarm.exe` (compiler direct invocation if needed)
3. `C:\iar\ewarm-9.60.3\common\bin\cspybat.exe`

Hardware-connected debug sessions (J-Link, ST-Link, I-jet, or any probe attached to a real device) still require user approval before starting.

### Determinism Rules
- Use a stable, documented execution order for every benchmark campaign.
- Explicitly report: chosen source material, toolchain version, project configuration, build settings, and measurement scope.
- Never silently switch context, scenario, or configuration mid-workflow.
- Report drift or unknowns immediately rather than masking them.

### Provenance-Aware Behavior
- Every acquired file must be traceable to its source (URL, version, tag/commit, package name, date).
- Provenance must appear in the output even for files already present in the workspace (path, assumed origin).
- If the origin of a file is unknown or unverifiable, mark it as unverified provenance.

### Unknown Handling
- Never mask, ignore, or silently skip unresolved unknowns.
- Collect unknowns throughout the workflow and report them in a dedicated section.
- Distinguish blocking unknowns (cannot continue) from non-blocking unknowns (can continue with noted risk).
- If an unknown affects fairness assessment, it must appear in the fairness section as well.

### Fairness Rules
- Fairness assessment is mandatory for any porting, comparison, or measurement interpretation task.
- The agent must explicitly identify and report fairness-sensitive differences (see Benchmark Fairness Checklist above).
- The agent must not silently hide, minimize, or dismiss fairness-impacting differences.
- When fairness issues are found, they must appear in the output before any performance conclusions.

### Command Transparency
When the agent runs commands (build, debug, inspection), it must report:
- The exact command executed.
- The working directory.
- A summary of the outcome (pass/fail/warning count).

### Required Output Expectations
For autonomous benchmark campaigns, the final output must include:
- Objective
- Scenario resolution (what was resolved, what was acquired)
- Source and target platforms identified
- Sources acquired or reused (with provenance)
- Actions executed (commands, edits, acquisitions)
- Build/debug/measurement status
- Semantic equivalence status (when porting or comparing)
- Fairness status (when porting, comparing, or measuring)
- Key findings
- Unresolved unknowns (blocking and non-blocking)
- Next action or blocker (if incomplete)

---

## IAR Board Template System

### Purpose
When creating or porting a benchmark project, agents must start from a **board-appropriate IAR project template** instead of inventing project structure. Templates provide the vendor-official board firmware baseline.

### Template Registry
The template registry at `.github/config/iar_templates.yaml` maps each supported board to its official IAR project template source. Resolution follows this order:
1. Exact `board_id` match
2. Family-level fallback (same family, adjust device/linker/startup)
3. Board-type fallback within the same vendor
4. Unresolved — gap documented, no template invented

### Template as Read-Only Baseline
The IAR board template is **board firmware infrastructure**, not application code:
- Startup files, linker configurations, system init, HAL/BSP: **protected (read-only)**
- Application entry point, user source groups, include/define additions: **modifiable**
- Device/debugger settings in .ewp: **protected**

Benchmark logic integrates ONLY through application-layer integration points.

### Protected Surface Deviation
If a benchmark cannot be implemented through application-layer-only integration:
1. Identify the specific protected surface requiring modification
2. Document the justification
3. Obtain approval via the hardware approval / deviation gate
4. Make minimal documented change with revert path
5. Record in campaign `fairness_baseline.yaml`

### Template Acquisition
Templates are acquired autonomously following the External Acquisition Policy:
1. Check workspace materialized templates first
2. Check local SDK / IAR installation content
3. Fetch from official vendor GitHub (prefer tagged releases)
4. Fetch from official vendor SDK bundles / CMSIS packs
5. Third-party mirrors only as last resort

Provenance of every template must be recorded in the per-board `provenance.yaml` and in the campaign `source_provenance.yaml`.

### Template Storage
Materialized templates are stored at `.github/benchmark/templates/iar/<vendor>/<board-id>/project/`.
Each board directory also contains `template_manifest.yaml` and `provenance.yaml`.

### Skill Reference
Use the `iar-template-resolution` skill for the full resolution and acquisition workflow.

### Tool Reference
Use `.github/tools/acquire_iar_template.ps1` to fetch templates from remote sources.
Use `.github/tools/validate_iar_templates.py` to validate registry consistency.