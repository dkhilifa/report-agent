# STM32 Enhancement Report Template

## Campaign
- **Campaign ID**: 
- **STM32 Platform**: 
- **Competitor Platform**: 
- **Scenario**: 

## Observed Gap Summary
<!-- From comparison evidence -->

## Gap Classification

### Fairness Artifacts (fix first for fair baseline)

| Issue | STM32 Value | Competitor Value | Correction |
|-------|-------------|-----------------|------------|
|       |             |                 |            |

### Real Capability Gaps (after fairness normalization)

| Metric | STM32 | Competitor | Delta | Evidence |
|--------|-------|-----------|-------|----------|
|        |       |           |       |          |

## Recommendations

| # | Enhancement | Expected Impact | Effort | Semantic Drift Risk | Notes |
|---|-------------|----------------|--------|--------------------:|-------|
|   |             |                |        |                     |       |

## Constraints
- Do NOT change benchmark meaning
- Use legitimate STM32 HW features only
- Must be achievable with current part/board

## Implementation Order
1. 

## Unresolved Unknowns

## Provenance
