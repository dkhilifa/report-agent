# Comparison Report Template

## Campaign
- **Campaign ID**: 
- **Platform A**: 
- **Platform B**: 
- **Scenario**: 

## Prerequisites
- Semantic equivalence confirmed: ☐ Yes / ☐ No / ☐ Partial
- Fairness review status: 

## Per-Metric Comparison

| Metric | Units | Platform A | Platform B | Delta | Delta % | Direction | Classification |
|--------|-------|-----------|-----------|-------|---------|-----------|----------------|
|        |       |           |           |       |         |           |                |

## Gap Classifications

### Confirmed Real Gaps

### Fairness Artifacts

### Uncertain / Needs More Evidence

## Fairness Notes

## Recommendations

## Unresolved Unknowns

## Provenance
- Platform A source: 
- Platform B source: 
