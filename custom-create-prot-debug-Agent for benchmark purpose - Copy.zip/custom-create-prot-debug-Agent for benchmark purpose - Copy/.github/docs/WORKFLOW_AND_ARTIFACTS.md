# Workflow & Artifacts

The deterministic 14-step workflow and the benchmark dossier artifact model.

---

## Deterministic Workflow

Every benchmark campaign follows this fixed sequence. Steps are never skipped — they may produce "not applicable" artifacts, but the stage always executes.

| Step | Stage | Autonomous? | Artifacts Produced |
|---:|---|---|---|
| 1 | **Resolve scenario** | Yes | `scenario_resolution.yaml` |
| 2 | **Acquire materials** | Yes | `source_provenance.yaml` (per source) |
| 3 | **Analyze reference** | Yes | `semantic_summary.yaml` |
| 4 | **Identify portability boundaries** | Yes | Layer classification in semantic summary |
| 5 | **Create or port project** | Yes | Ported source tree, `semantic_equivalence.yaml` |
| 6 | **Configure IAR project** | Yes | `.ewp`, `.eww`, `.icf`, startup files |
| 7 | **Build** | Yes | `.out`, `.map`, build diagnostics |
| 8 | **Triage build failures** | Yes | Fix applied or `execution_status.yaml` blocked |
| 9 | **Prepare debug session** | Yes | Debug configuration, breakpoint definitions |
| 10 | **Hardware approval gate** | **Ask user** | `hardware_approval.yaml` |
| 11 | **Execute & measure** | Yes (after 10) | `measurement_metadata.yaml`, raw captures |
| 12 | **Compare & interpret** | Yes | `comparison_delta`, `fairness_review.yaml` |
| 13 | **Review fairness** | Yes | `fairness_baseline.yaml`, caveats |
| 14 | **Generate report** | Yes | `benchmark_report.html`, `.drawio` |

---

## Stage Details

### Step 1: Resolve Scenario

The agent interprets the user's request and resolves:
- Benchmark type (RTOS, peripheral, crypto, DSP, mixed)
- Target platforms (boards, MCUs, vendors)
- Measurement strategy (DWT, SysTick, UART, GPIO)
- Success criteria (what constitutes a valid measurement)

### Step 2: Acquire Materials

Downloads SDKs, HAL files, CMSIS packs, startup/linker files from vendor sources. Records provenance for every acquired resource.

### Steps 3–4: Analyze & Classify

Extracts observable behaviors from the reference project:
- Task counts, priorities, stack sizes
- Peripheral initialization sequence
- Timing constants and measurement scope
- Platform-specific vs portable code boundaries

### Steps 5–6: Create/Port & Configure

Creates the target project preserving all semantics. The agent works within the **application layer** by default — vendor baseline files (startup, linker, HAL, BSP, middleware) are selected and referenced but not modified. Configures:
- Device selection in `.ewp`
- Include paths for vendor HAL/BSP
- Preprocessor defines
- Linker configuration (`.icf`) — selected from vendor-provided set
- Startup file selection — from vendor-provided set

If a benchmark cannot be implemented purely at the application layer, the agent surfaces an approval-required deviation before modifying any protected-surface file.

### Steps 7–8: Build & Triage

Runs `IarBuild.exe`, classifies failures:
- **config_error** — project configuration issue (fixable)
- **source_error** — missing/incorrect source files
- **linker_error** — unresolved symbols, section overflow
- **internal_error** — toolchain bug (blocked)

### Step 9: Prepare Debug

Configures C-SPY session:
- Probe type (ST-Link, J-Link, I-jet)
- Flash loader for target device
- Breakpoints at measurement start/stop points
- UART redirect if applicable

### Step 10: Hardware Gate

**Only step requiring user approval.** The agent presents:
- What will be flashed
- Which board/probe
- Expected behavior after flash
- Measurement plan

### Steps 11–12: Measure & Compare

Extracts:
- Flash/RAM from `.map` file (always available)
- Cycle counts from DWT CYCCNT (requires hardware)
- Wall-clock from SysTick (requires hardware)
- UART output (requires hardware)

Comparison computes deltas, classifies by layer, applies clock normalization.

### Steps 13–14: Fairness & Report

Reviews all fairness conditions:
- Same optimization level?
- Same clock base for timing?
- Equivalent measurement scope?
- Any wrapper overhead asymmetry?

Generates self-contained HTML report with all findings.

---

## Benchmark Dossier Structure

A campaign's complete artifact set:

```
benchmark/
├── campaigns/
│   └── <campaign_id>/
│       ├── campaign_manifest.yaml    # Identity, goals, platforms, status
│       └── execution_status.yaml     # Per-stage pass/fail tracking
├── analysis/
│   └── <campaign_id>/
│       ├── semantic_summary.yaml     # Extracted behaviors & boundaries
│       └── scenario_resolution.yaml  # How scenario was resolved
├── ports/
│   └── <campaign_id>/
│       ├── <target>/                 # Ported project tree
│       └── source_provenance.yaml    # SDK versions, URLs, timestamps
├── build/
│   └── <campaign_id>/
│       ├── <target>/                 # .ewp, .out, .map files
│       └── build_diagnostics.yaml    # Parsed build results
├── debug/
│   └── <campaign_id>/
│       └── <target>/                 # Debug configs, session logs
├── measurements/
│   └── <campaign_id>/
│       ├── <target>/                 # Raw measurement files
│       └── measurement_metadata.yaml # What, how, when, confidence
├── comparisons/
│   └── <comparison_id>/
│       ├── comparison_delta.yaml     # Computed deltas
│       ├── fairness_baseline.yaml    # Build conditions record
│       ├── fairness_review.yaml      # Post-comparison assessment
│       └── semantic_equivalence.yaml # Behavior comparison
├── enhancements/
│   └── <campaign_id>/
│       └── stm32_enhancement_report.md  # Improvement proposals
├── validation/
│   └── <campaign_id>/
│       └── semantic_equivalence.yaml # Evidence + drift flags
└── reports/
    └── <campaign_id>/
        ├── report_data.yaml          # Input data for report generator
        ├── benchmark_report.html     # Self-contained HTML report
        └── scenario.drawio           # Editable diagram
```

---

## Artifact Lifecycle

```
Created → Validated → Consumed → Archived
```

1. **Created** — agent emits YAML artifact using template
2. **Validated** — schema check ensures all required fields present
3. **Consumed** — downstream stage reads and uses artifact
4. **Archived** — artifact remains in dossier for traceability

---

## Campaign States

| State | Meaning |
|---|---|
| `initiated` | Campaign created, scenario being resolved |
| `acquiring` | Fetching source materials |
| `building` | IAR build in progress |
| `blocked` | Cannot proceed without user action |
| `measuring` | Hardware measurements in progress |
| `comparing` | Analysis and comparison phase |
| `complete` | All stages done, report generated |
| `failed` | Unrecoverable error in a stage |
