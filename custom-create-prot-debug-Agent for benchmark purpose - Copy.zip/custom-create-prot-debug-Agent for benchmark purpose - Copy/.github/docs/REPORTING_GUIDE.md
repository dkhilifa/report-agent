# Reporting Guide

How the benchmark report system works, what each section contains, and how to customize output.

---

## Report Generation

### Command

```powershell
py -3 tools/generate_benchmark_report.py benchmark/reports/<campaign>/report_data.yaml
```

### Outputs

| File | Description |
|---|---|
| `benchmark_report.html` | Self-contained HTML report (no external dependencies) |
| `scenario.drawio` | Editable draw.io diagram of the benchmark scenario |

### Self-Containment Guarantees

- All CSS is embedded inline — no external stylesheets
- All charts are inline SVG — no JavaScript charting libraries
- All badges use CSS classes — no external image assets
- Scenario diagram is rendered as inline SVG in the HTML
- Works offline, prints cleanly, exports to PDF via browser

---

## Report Sections (13)

### 1. Executive Summary

KPI badge cards at the top:
- **Fairness** — pass/marginal/fail with detail
- **Equivalence** — confirmed/partial/unverified
- **Flash delta** — percentage and absolute difference
- **RAM delta** — percentage and absolute difference
- **Timing winner** — which platform and by how much
- **Recommendation status** — actionable/inconclusive/blocked

### 2. Scenario Architecture

Inline SVG diagram showing the benchmark pipeline:
- Reference and target platform cards
- Data flow through analysis → port → build → measure → compare stages
- Color-coded by vendor (STM32 blue, competitor orange)

A companion `.drawio` file is generated for editing in draw.io or VS Code.

### 3. Platform Summary

Side-by-side cards with:
- Vendor, board name, MCU
- Core type and clock frequency
- Toolchain and optimization level
- Debug probe and measurement method

### 4. Fairness & Equivalence

- Fairness checks table (optimization, clock, wrapper, scope, instrumentation)
- Semantic equivalence assessment (behavior match, drift flags)
- Caveats that must be considered before drawing conclusions

### 5. Footprint Comparison

- Table: module name, platform A flash/RAM, platform B flash/RAM, delta, percentage
- Grouped bar chart with value labels
- Sorted by absolute delta (largest first)

### 6. Footprint by Layer

Breakdown by layer classification:
- **Application** — benchmark logic
- **Middleware** — RTOS, stacks
- **Low-level** — HAL, BSP, startup

Each layer shows total and per-module contributions.

### 7. Module Equivalence

Per-module semantic matching:
- Module name on each platform
- Match confidence (high/medium/low)
- Flash and RAM deltas
- Notes on structural differences

### 8. Execution Time

- Timing metrics table (cycles, microseconds, operations/second)
- Horizontal bar chart with direction indicators
- Clock normalization applied if frequencies differ

### 9. Scenario Observations

Findings that don't fit other categories:
- Category (behavior, performance, configuration, fairness)
- Finding description
- Impact assessment (high/medium/low)

### 10. Interpretation

Natural-language analysis covering:
- Why footprint differs (per layer)
- Why timing differs (algorithmic vs hardware vs configuration)
- Confidence in the comparison
- What would change the conclusion

### 11. STM32-Focused Findings

Highlighted section with blue gradient background:
- **STM32 Ahead** — areas where STM32 wins
- **STM32 Behind** — areas where STM32 loses (with root cause)
- **Inconclusive** — areas needing more evidence

### 12. Recommendations

Actionable cards with:
- Recommendation text
- Confidence level (high/medium/low)
- Effort estimate (trivial/moderate/significant)
- Risk assessment (none/low/medium/high)
- Evidence backing the recommendation

### 13. Unknowns & Evidence

- Unresolved questions
- Missing measurements
- Provenance notes
- Suggested follow-up actions

---

## Report Data Format

The report generator reads `report_data.yaml` with this structure:

```yaml
title: "FreeRTOS Task-Switch Benchmark"
campaign_id: "freertos-taskswitch-stm32u5-vs-gd32e5"
generated: "2024-01-15T10:30:00Z"

platforms:
  - id: platform_a
    name: "STM32U575ZI"
    vendor: "STMicroelectronics"
    board: "NUCLEO-U575ZI-Q"
    mcu: "STM32U575ZIT6"
    core: "Cortex-M33"
    clock_mhz: 160
    toolchain: "IAR EWARM 9.60.3"
    optimization: "-Oh (High, balanced)"
  - id: platform_b
    name: "GD32E507VE"
    vendor: "GigaDevice"
    board: "GD32E507V-EVAL"
    mcu: "GD32E507VET6"
    core: "Cortex-M33"
    clock_mhz: 200
    toolchain: "IAR EWARM 9.60.3"
    optimization: "-Oh (High, balanced)"

fairness:
  optimization_match: true
  clock_normalization: "cycle-based comparison used"
  wrapper_equivalence: true
  measurement_scope_match: true
  overall: "pass"

equivalence:
  status: "confirmed"
  drift_flags: []

footprint:
  - module: "main.o"
    layer: "application"
    platform_a: { flash: 1024, ram: 256 }
    platform_b: { flash: 1180, ram: 264 }
  # ... more modules

timing:
  - metric: "task_switch_cycles"
    platform_a: 847
    platform_b: 923
    unit: "cycles"
    direction: "lower is better"

observations:
  - category: "performance"
    finding: "GD32 uses 2 extra cycles in PendSV handler"
    impact: "low"

interpretation:
  footprint: "STM32 HAL is 12% smaller due to..."
  timing: "STM32 wins by 8% in raw cycles..."
  confidence: "high"

stm32_findings:
  ahead: ["Flash footprint: 12% smaller"]
  behind: ["Clock configuration code: 5% larger"]
  inconclusive: []

recommendations:
  - text: "Optimize GD32 port PendSV handler"
    confidence: "medium"
    effort: "moderate"
    risk: "low"
```

---

## STM32 Highlighting

Throughout the report, STM32 platforms receive special visual treatment:

- **Color:** `#0078D4` (Microsoft/ST blue) for STM32, `#FF6D00` (orange) for competitors
- **Badges:** Blue background for STM32 metrics, orange for competitor
- **STM32 Section:** Dedicated wrapper with gradient background and accent border
- **Charts:** STM32 bars always use the primary accent color

---

## Customizing Reports

### Changing the Theme

Edit `config/reporting.yaml`:
- `theme.primary_color` — STM32 accent color
- `theme.secondary_color` — competitor accent color
- `theme.background` — page background
- `badge_thresholds` — when to show green/yellow/red badges

### Adding a Section

1. Add section definition to `generate_benchmark_report.py` in the `sections` list
2. Implement rendering function
3. Add corresponding CSS styles
4. Update `report_data.yaml` schema if new data fields needed

### Generating Without Full Data

The report generator handles missing sections gracefully — if a field is absent from `report_data.yaml`, that section is omitted from output with no error.
