# Quickstart Guide

Get your first benchmark comparison running in under 5 minutes.

---

## Prerequisites

| Requirement | Details |
|---|---|
| **VS Code** | Latest stable with GitHub Copilot extension |
| **GitHub Copilot** | Active subscription with agent/chat access |
| **IAR EWARM 9.60.3** | Installed at `C:\iar\ewarm-9.60.3` |
| **Python 3.8+** | Available as `py -3` (used by analysis/reporting tools) |
| **Physical board** | Only needed if you want actual runtime measurements |

---

## Step 1: Open the Workspace

Open the `.github` folder (or its parent) as a VS Code workspace. The custom agent system loads automatically from the `.github/` directory.

Verify by typing `@` in the Copilot chat — you should see `MCU-Benchmark-Agent` in the agent list.

---

## Step 2: Choose Your Path

### Path A: "I have a benchmark name"

```
@MCU-Benchmark-Agent Benchmark the CoreMark firmware on NUCLEO-U575ZI
```

The agent resolves the scenario, acquires source from EEMBC, creates the IAR project, builds, and prepares for measurement.

### Path B: "I want to port a benchmark"

```
@MCU-Benchmark-Agent Port the STM32 USB HID benchmark to GD32E507
```

The agent acquires both SDKs, analyzes the reference, creates a semantically equivalent port, and builds both.

### Path C: "I want to compare two platforms"

```
@MCU-Benchmark-Agent Compare STM32U5 vs NXP RT1060 on FreeRTOS task-switch fairly
```

The agent runs the full pipeline for both platforms and produces a comparison report.

### Path D: "I want a report from existing data"

```
@MCU-Benchmark-Agent Generate a benchmark report from benchmark/reports/report_data.yaml
```

Produces a self-contained HTML report immediately.

---

## Step 3: Let the Agent Work

The agent operates autonomously through all file, build, and analysis stages. It will only ask you for approval before:

- Flashing firmware to a physical board
- Resetting a live device
- Attaching a debug probe to running hardware

---

## Step 4: Find Your Results

All outputs go to `benchmark/`:

| Output | Location |
|---|---|
| Campaign manifest | `benchmark/campaigns/<campaign_id>/` |
| Build artifacts | `benchmark/build/<target>/` |
| Measurements | `benchmark/measurements/<target>/` |
| Comparison | `benchmark/comparisons/<comparison_id>/` |
| HTML Report | `benchmark/reports/<report_name>.html` |

---

## Common First-Time Issues

| Symptom | Fix |
|---|---|
| Agent not visible in chat | Ensure `.github/agents/` is in workspace root |
| IAR build fails immediately | Verify `C:\iar\ewarm-9.60.3\common\bin\IarBuild.exe` exists |
| Python scripts fail | Use `py -3` (not `python`) — system may default to 2.7 |
| Report generation errors | Ensure `report_data.yaml` matches schema structure |

---

## Using Prompts

Instead of typing requests directly, use the pre-built prompts in `.github/prompts/`:

1. Click the prompt picker icon in Copilot chat
2. Select a numbered prompt (e.g., `01_Autonomous_Benchmark_From_Name`)
3. Fill in the placeholders
4. Send

See [PROMPTS_GUIDE.md](PROMPTS_GUIDE.md) for detailed explanation of all 10 prompts.

---

## Next Steps

- [PROMPTS_GUIDE.md](PROMPTS_GUIDE.md) — Explore all 10 available prompts
- [WORKFLOW_AND_ARTIFACTS.md](WORKFLOW_AND_ARTIFACTS.md) — Understand the full 14-step pipeline
- [PORTING_GUIDE.md](PORTING_GUIDE.md) — Learn all supported porting directions
- [REPORTING_GUIDE.md](REPORTING_GUIDE.md) — Customize and interpret benchmark reports
