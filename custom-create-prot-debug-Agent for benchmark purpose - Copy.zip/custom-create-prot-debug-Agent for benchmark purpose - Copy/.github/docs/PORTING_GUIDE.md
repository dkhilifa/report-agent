# Porting Guide

All supported porting directions, semantic preservation rules, and the porting workflow.

---

## Supported Directions

| Direction | Source | Target | Entry Prompt |
|---|---|---|---|
| STM32 → Competitor | STM32 reference project | Any competitor board | Prompt 07 |
| Competitor → STM32 | Competitor project/firmware | Any STM32 board | Prompt 08 |
| Vendor → Vendor | Non-ST vendor project | Different non-ST vendor | Prompt 09 |
| Board → Board (same vendor) | Project on board A | Different board, same vendor | Prompt 02 |
| Board → Board (cross-vendor) | Project on board A | Board from different vendor | Prompt 02 |
| Scenario → Multi-platform | Scenario description | Two or more platforms | Prompt 06 |

---

## Semantic Preservation Rules

A port is **semantically equivalent** when all observable behaviors match the reference. The agent enforces:

### Mandatory Equivalence

| Aspect | Rule |
|---|---|
| **Task structure** | Same number of tasks, same priorities, same stack sizes |
| **Timing constants** | Same delays, timeouts, periods (in real-time units) |
| **Buffer sizes** | Same data buffer dimensions |
| **Algorithm** | Same computational logic, same iteration counts |
| **Peripheral behavior** | Same functional init (baud rate, mode, pin function) |
| **Measurement scope** | Same start/stop points for timing instrumentation |
| **Output format** | Same UART output structure, same field order |
| **Interrupt model** | Same interrupt usage pattern (priority, nesting) |

### Permitted Adaptations

| Aspect | What changes | Example |
|---|---|---|
| Register names | Vendor-specific register API | `HAL_GPIO_WritePin` → `gpio_bit_set` |
| Clock init | PLL configuration for target frequency | Different PLL multipliers |
| Pin mapping | Physical pin assignments | LED on PA5 → PB3 |
| Startup file | Vendor-provided startup assembly | `startup_stm32u575xx.s` → `startup_gd32e507.s` |
| Linker script | Memory regions for target device | Flash/RAM base addresses |
| Include paths | Vendor HAL/BSP locations | Different directory structure |
| Preprocessor | Device-specific defines | `STM32U575xx` → `GD32E507` |

---

## Porting Workflow

### Phase 1: Analysis

1. **Identify reference project** — locate main source, HAL, BSP, middleware
2. **Extract semantic summary** — observable behaviors, timing, IO patterns
3. **Classify layers** — application / middleware / low-level
4. **Map portability boundaries** — what's portable, what must be rewritten

### Phase 2: Acquisition

5. **Identify target SDK** — find vendor HAL, BSP, startup, linker for target
6. **Download if missing** — use vendor_sources.yaml configuration
7. **Record provenance** — version, URL, commit hash, timestamp

### Phase 3: Port

8. **Copy application layer** — unchanged (this is the benchmark logic)
9. **Adapt middleware layer** — RTOS config through app-level headers; select existing middleware files (do not modify internals)
10. **Select low-level layer** — choose correct vendor-provided startup, linker, HAL, BSP files and reference them in the project (do not rewrite or modify their content)
11. **Create app-level adapters** — if the benchmark needs board-specific interaction, create an app-owned adapter file that calls into vendor APIs
12. **Verify API equivalence** — same functional behavior through different API

### Phase 4: Verification

12. **Build target** — IAR EWARM with same optimization settings
13. **Check semantic equivalence** — automated comparison of behaviors
14. **Document adaptations** — every change recorded with justification

---

## Layer Classification

```
┌─────────────────────────────────┐
│  Application Layer              │  ← WRITABLE (create/modify freely)
│  (benchmark logic, algorithms)  │
├─────────────────────────────────┤
│  Middleware Layer               │  ← PROTECTED (select, do not modify)
│  (RTOS, USB stack, filesystem)  │
├─────────────────────────────────┤
│  Low-Level Layer                │  ← PROTECTED (select, do not modify)
│  (HAL, BSP, startup, linker)   │
└─────────────────────────────────┘
```

### Application Layer (Writable)

- `main.c` benchmark logic
- Algorithm implementations
- Data structures and buffers
- Test harnesses
- App-owned wrappers and adapters

**Port rule:** Copy unchanged or create new. This is the default working surface — modify freely.

### Middleware Layer (Protected)

- FreeRTOS kernel (portable across Cortex-M)
- CMSIS-RTOS2 wrappers
- USB middleware, filesystem, network stacks

**Port rule:** Select existing vendor-provided middleware files and reference them in the project. Do not modify their content. Configuration (heap size, stack size, port layer selection) is done through app-level config headers or project defines.

### Low-Level Layer (Protected)

- `system_*.c` — clock initialization
- `startup_*.s` — vector table, reset handler
- `*.icf` — linker configuration (memory map)
- HAL drivers — GPIO, UART, SPI, timer init
- BSP — board-specific pin mapping

**Port rule:** Select the correct existing vendor-provided files for the target and reference them in the project. Do not rewrite, generate, or modify vendor file contents. If the application layer needs board-specific behavior, use an app-level adapter that calls vendor APIs.

### Approval-Required Deviations

If a benchmark truly cannot be implemented within the application layer alone:
1. Identify the exact protected file and layer.
2. Explain why the application layer is insufficient.
3. Propose the smallest possible change.
4. Request explicit user approval.
5. Record in `baseline_exceptions.yaml`.
6. Assess fairness, portability, and maintenance impact.

---

## Vendor-Specific Notes

### STMicroelectronics (STM32)

- HAL: `stm32xx_hal_*.c/h`
- Startup: `startup_stm32*.s`
- Linker: `stm32*.icf`
- Clock: `SystemClock_Config()` in `main.c`
- CMSIS device: `stm32*.h` with register definitions

### GigaDevice (GD32)

- HAL: `gd32*_*.c/h` (similar structure to STM32, different names)
- Startup: `startup_gd32*.s`
- Linker: `gd32*.icf`
- Clock: `rcu_*` functions
- Note: GPIO and RCU APIs differ significantly from STM32 HAL

### NXP (i.MX RT, LPC, Kinetis)

- SDK: MCUXpresso SDK with drivers/
- Startup: `startup_*.s` from SDK
- Linker: `*.icf` from SDK
- Clock: `BOARD_InitBootClocks()` from clock_config.c
- Middleware: Often bundled in SDK

### Renesas (RA, RX)

- FSP: Flexible Software Package
- Startup: Generated by e2 studio / Smart Configurator
- HAL: `r_*.c/h`
- Clock: FSP clock configuration

### Infineon (PSoC, XMC)

- MTB: ModusToolbox libraries
- HAL: `cy_*.c/h` or `XMC_*.c/h`
- Startup: `startup_*.s`
- Clock: `Cy_SysClk_*` functions

### Texas Instruments (MSP, C2000)

- DriverLib: `ti/devices/*/driverlib/`
- Startup: `startup_*.c`
- Linker: `*.icf`
- Clock: `SysCtl_*` functions

---

## Fairness During Porting

The agent applies these checks during every port:

1. **Same optimization level** — both platforms built with identical `-O` setting
2. **Same stack/heap sizes** — linker configuration must match
3. **No extra features** — target port cannot add functionality not in reference
4. **No missing features** — target port cannot omit functionality from reference
5. **Equivalent measurement scope** — instrumentation covers same code path
6. **Documented clock differences** — if frequencies differ, noted for comparison

---

## Common Porting Issues

| Issue | Cause | Resolution |
|---|---|---|
| Missing peripheral API | Target vendor uses different naming | Map to equivalent function |
| Clock frequency mismatch | Different PLL capabilities | Document and use cycle-based comparison |
| Startup differences | Vector table layout varies | Use vendor-provided startup file |
| Linker section names | Different conventions | Map to equivalent sections in .icf |
| Interrupt priority scheme | NVIC config differences | Same logical priority, different numeric value |
| DMA channel numbering | Hardware-specific | Use equivalent channel with same transfer config |
