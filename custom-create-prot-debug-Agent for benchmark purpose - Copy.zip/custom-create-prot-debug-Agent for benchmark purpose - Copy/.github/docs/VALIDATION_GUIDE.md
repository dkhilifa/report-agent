# Validation Guide

How to validate repository consistency using the built-in validation script.

---

## Running Validation

```powershell
py -3 tools/validate_benchmark_repo.py
```

**Expected output (clean):**
```
[PASS] Board registry: 45 boards validated
[PASS] MCU registry: 40 families validated
[PASS] Vendor registry: 8 vendors validated
[PASS] Schema files: 11 schemas present and valid
[PASS] Template files: 15 templates present
[PASS] Config cross-references: all resolved
[PASS] Agent files: 4 agents with valid frontmatter
[PASS] Skill folders: 5 skills with matching SKILL.md names

Validation complete: 8/8 checks passed
```

---

## Checks Performed

### 1. Board Registry (`config/boards.yaml`)

| Check | Validates |
|---|---|
| Required fields | Every board has: name, vendor, mcu, status |
| Vendor reference | `vendor` field matches an entry in `vendors.yaml` |
| MCU reference | `mcu` field matches an entry in `mcus.yaml` |
| Status values | Must be: `active`, `planned`, `deprecated` |
| Name uniqueness | No duplicate board names |

### 2. MCU Registry (`config/mcus.yaml`)

| Check | Validates |
|---|---|
| Required fields | Every MCU has: family, vendor, core, status |
| Vendor reference | `vendor` field matches an entry in `vendors.yaml` |
| Core validity | Must be a recognized Cortex-M core (M0, M0+, M3, M4, M7, M23, M33, M55, M85) |
| Status values | Must be: `active`, `planned`, `deprecated` |
| Family uniqueness | No duplicate family names |

### 3. Vendor Registry (`config/vendors.yaml`)

| Check | Validates |
|---|---|
| Required fields | Every vendor has: name, aliases |
| Alias uniqueness | No alias appears in multiple vendors |
| Name uniqueness | No duplicate vendor names |

### 4. Schema Files (`schemas/benchmark/`)

| Check | Validates |
|---|---|
| Presence | All 11 expected schema files exist |
| YAML validity | Each file parses without errors |
| Required keys | Schemas define `type`, `properties`, `required` |

**Expected schemas:**
- campaign_manifest.schema.yaml
- comparison_delta.schema.yaml
- execution_status.schema.yaml
- fairness_baseline.schema.yaml
- fairness_review.schema.yaml
- hardware_approval.schema.yaml
- measurement_metadata.schema.yaml
- scenario_resolution.schema.yaml
- semantic_equivalence.schema.yaml
- semantic_summary.schema.yaml
- source_provenance.schema.yaml

### 5. Template Files (`templates/benchmark-dossier/`)

| Check | Validates |
|---|---|
| Presence | All 15 expected template files exist |
| YAML validity | Each file parses without errors |
| Placeholder markers | Templates contain `<placeholder>` or example values |

### 6. Config Cross-References

| Check | Validates |
|---|---|
| boards → vendors | All board vendor fields resolve |
| boards → mcus | All board MCU fields resolve |
| vendor_sources → vendors | All source entries reference valid vendors |
| toolchains | At least one toolchain defined with valid path |

### 7. Agent Files (`agents/*.agent.md`)

| Check | Validates |
|---|---|
| Frontmatter | Valid YAML frontmatter with `---` delimiters |
| Required keys | `name`, `description`, `tools` present |
| Name format | Name matches filename slug convention |
| Tools list | Only valid tool identifiers used |

### 8. Skill Folders (`skills/*/SKILL.md`)

| Check | Validates |
|---|---|
| SKILL.md present | Every skill folder contains SKILL.md |
| Name field | `name` in frontmatter matches folder name exactly |
| Description | Non-empty description present |

---

## Fixing Common Validation Failures

### "Board references unknown vendor"

```yaml
# boards.yaml - fix vendor name to match vendors.yaml
- name: "NUCLEO-U575ZI-Q"
  vendor: "STMicroelectronics"  # Must match exactly
  mcu: "STM32U575ZI"
```

### "MCU references unknown vendor"

```yaml
# mcus.yaml - fix vendor reference
- family: "STM32U5"
  vendor: "STMicroelectronics"  # Must match vendors.yaml
  core: "Cortex-M33"
```

### "Schema file missing"

Create the missing schema in `schemas/benchmark/`:
```yaml
# <name>.schema.yaml
type: object
properties:
  field_name:
    type: string
    description: "Field description"
required:
  - field_name
```

### "Agent name doesn't match filename"

The `name` in frontmatter must match the filename slug:
- File: `MCU-Benchmark-Agent.agent.md` → name: `MCU-Benchmark-Agent`
- File: `Build-Project.agent.md` → name: `Build-Project`

### "Skill name doesn't match folder"

The `name` in `SKILL.md` frontmatter must match the parent folder exactly:
- Folder: `skills/benchmark-analysis/` → name: `benchmark-analysis`
- Folder: `skills/stm32-enhancement/` → name: `stm32-enhancement`

---

## Running Validation in CI

For automated checks, the script returns exit code 0 on success, non-zero on failure:

```powershell
py -3 tools/validate_benchmark_repo.py
if ($LASTEXITCODE -ne 0) { throw "Validation failed" }
```

---

## Extending Validation

To add new checks, edit `tools/validate_benchmark_repo.py`:

1. Add a new check function following the pattern:
   ```python
   def check_something(config_dir):
       errors = []
       # ... validation logic ...
       return errors
   ```

2. Register it in the `main()` function's check list

3. Return a list of error strings (empty = pass)
