# Example: STM32 Enhancement Report

# File: benchmark/enhancements/<campaign_id>/stm32_enhancement_report.md

# STM32 Enhancement Recommendations

**Campaign:** usb-throughput-stm32h5-vs-nxp-rt1170
**Date:** 2024-01-20
**Gap identified:** STM32H563 USB bulk throughput 18% lower than NXP RT1170

---

## Gap Analysis Summary

| Metric | STM32H563 | NXP RT1170 | Delta | Significance |
|---|---|---|---|---|
| USB Bulk IN (MB/s) | 38.2 | 46.5 | -17.8% | High |
| USB Bulk OUT (MB/s) | 35.1 | 41.8 | -16.0% | High |
| Flash footprint (KB) | 24.3 | 28.7 | -15.3% | STM32 ahead |
| RAM footprint (KB) | 8.2 | 9.1 | -9.9% | STM32 ahead |

**Fairness status:** PASS — same USB mode (HS), same packet size (512B), same test duration.

---

## Root Cause Breakdown

### 1. DMA Transfer Configuration (60% of gap)

**Finding:** STM32 USB driver uses single-buffer DMA while NXP uses double-buffering.

**Evidence:**
- STM32 HAL `HAL_PCD_EP_Transmit()` sets up one DMA transfer, waits for completion
- NXP USB stack pre-loads next buffer during current transfer
- This creates idle bus time on STM32 between consecutive packets

### 2. USB Peripheral Clock Configuration (25% of gap)

**Finding:** STM32H5 USB peripheral runs at 48 MHz (fixed divider) while RT1170 USB runs at 60 MHz.

**Evidence:**
- STM32H5 reference manual: USB requires 48 MHz from PLL1Q or HSI48
- RT1170: USB PHY clock at 60 MHz from USB PLL
- Higher PHY clock reduces inter-packet gap

### 3. Software Overhead (15% of gap)

**Finding:** STM32 HAL USB driver has more error-checking overhead per transfer.

**Evidence:**
- HAL_PCD_EP_Transmit: 12 register accesses + 4 state checks before DMA start
- NXP driver: 6 register accesses + 1 state check

---

## Recommendations

### Recommendation 1: Enable Double-Buffering DMA

**Confidence:** High
**Effort:** Moderate (HAL modification or direct register programming)
**Risk:** Low (standard USB double-buffering technique)
**Expected improvement:** 10–12% throughput increase

**Implementation approach:**
1. Configure USB endpoint for double-buffer mode in endpoint descriptor
2. Ping-pong between two DMA buffers
3. Start next DMA transfer in endpoint ISR before processing current buffer
4. Requires modification of `stm32h5xx_hal_pcd.c` or bypass of HAL for USB transfers

### Recommendation 2: Optimize USB HAL Transfer Path

**Confidence:** Medium
**Effort:** Moderate
**Risk:** Low
**Expected improvement:** 3–5% throughput increase

**Implementation approach:**
1. Remove redundant state checks in hot path (`HAL_PCD_EP_Transmit`)
2. Combine register accesses where possible
3. Use `__STATIC_FORCEINLINE` for single-call helpers
4. Consider LL (Low-Level) driver instead of HAL for USB

### Recommendation 3: Explore HSI48 Calibration

**Confidence:** Low (hardware limitation)
**Effort:** Trivial
**Risk:** None
**Expected improvement:** <1% (clock is not the primary bottleneck)

**Implementation approach:**
1. Verify HSI48 is trimmed to exactly 48 MHz (not slightly low)
2. Use CRS (Clock Recovery System) with SOF for USB clock accuracy
3. This cannot close the 48 vs 60 MHz gap but ensures no further loss

---

## Summary

| # | Recommendation | Confidence | Effort | Expected Gain |
|---|---|---|---|---|
| 1 | Double-buffer DMA | High | Moderate | 10–12% |
| 2 | Optimize HAL path | Medium | Moderate | 3–5% |
| 3 | HSI48 calibration | Low | Trivial | <1% |

**Combined expected improvement:** 13–17% (would close most of the 18% gap)

---

## Fairness Note

The 48 MHz vs 60 MHz USB clock difference is a legitimate hardware characteristic, not a configuration error. Recommendations 1–2 address the software-controllable portion of the gap. The remaining ~3% from clock difference is an inherent platform characteristic.
