# Example: User Chat Requests

# Copy-paste these into VS Code Copilot Chat to invoke the MCU Benchmark Agent.
# Each example shows the user message and which prompt/path it follows.

# ─────────────────────────────────────────────────────────────────────────────
# PATH A: Full autonomous from name (Prompt 01)
# ─────────────────────────────────────────────────────────────────────────────

# Basic — just a firmware name:
@MCU-Benchmark-Agent Benchmark CoreMark on NUCLEO-U575ZI

# With comparison target:
@MCU-Benchmark-Agent Benchmark FreeRTOS task-switch on STM32U575 vs GD32E507

# Minimal input — agent resolves everything:
@MCU-Benchmark-Agent Benchmark Dhrystone

# ─────────────────────────────────────────────────────────────────────────────
# PATH B: Porting (Prompts 02, 07, 08, 09)
# ─────────────────────────────────────────────────────────────────────────────

# Board to board (Prompt 02):
@MCU-Benchmark-Agent Port the USB HID benchmark from NUCLEO-U575ZI to GD32E507V-EVAL fairly

# STM32 to competitor (Prompt 07):
@MCU-Benchmark-Agent Port my STM32H5 CoreMark project to NXP MIMXRT1060-EVK

# Competitor to STM32 (Prompt 08):
@MCU-Benchmark-Agent Port the GD32E507 FreeRTOS demo to STM32U575

# Vendor to vendor (Prompt 09):
@MCU-Benchmark-Agent Port NXP i.MX RT1060 USB benchmark to Renesas RA6M4

# ─────────────────────────────────────────────────────────────────────────────
# PATH C: Build and measure (Prompt 03)
# ─────────────────────────────────────────────────────────────────────────────

# Existing project:
@MCU-Benchmark-Agent Build and measure benchmark/build/stm32u5_freertos/project.ewp

# With measurement method:
@MCU-Benchmark-Agent Build benchmark/ports/gd32_e507/project.ewp and measure timing with DWT

# ─────────────────────────────────────────────────────────────────────────────
# PATH D: Comparison (Prompt 04)
# ─────────────────────────────────────────────────────────────────────────────

# From platform names:
@MCU-Benchmark-Agent Compare STM32U5 vs NXP RT1060 on FreeRTOS task-switch fairly

# From measurement paths:
@MCU-Benchmark-Agent Compare measurements in benchmark/measurements/stm32_u575/ and benchmark/measurements/gd32_e507/

# ─────────────────────────────────────────────────────────────────────────────
# PATH E: STM32 improvement (Prompt 05)
# ─────────────────────────────────────────────────────────────────────────────

# From a known gap:
@MCU-Benchmark-Agent STM32U5 is 15% slower than GD32E5 on context switch — recommend improvements

# From comparison report:
@MCU-Benchmark-Agent Analyze benchmark/reports/usb-stm32h5-vs-rt1170/benchmark_report.html and recommend STM32 improvements

# ─────────────────────────────────────────────────────────────────────────────
# PATH F: Create from scratch (Prompt 06)
# ─────────────────────────────────────────────────────────────────────────────

# Detailed scenario:
@MCU-Benchmark-Agent Create a UART throughput benchmark for STM32H563 and Renesas RA6M4, measuring bytes/second at 115200 baud

# High-level scenario:
@MCU-Benchmark-Agent Create a crypto AES-256 benchmark comparing STM32U5 hardware accelerator vs software implementation on GD32E5

# ─────────────────────────────────────────────────────────────────────────────
# PATH G: Report generation only
# ─────────────────────────────────────────────────────────────────────────────

# From existing data:
@MCU-Benchmark-Agent Generate a benchmark report from benchmark/reports/freertos-taskswitch/report_data.yaml

# ─────────────────────────────────────────────────────────────────────────────
# PATH H: Build from firmware name (Prompt 10)
# ─────────────────────────────────────────────────────────────────────────────

# SDK example name:
@MCU-Benchmark-Agent Find and build "FreeRTOS_Queues" firmware for any STM32H5 board

# Vendor-specific firmware:
@MCU-Benchmark-Agent Find the GD32E507 USB Device HID example, build it with IAR
