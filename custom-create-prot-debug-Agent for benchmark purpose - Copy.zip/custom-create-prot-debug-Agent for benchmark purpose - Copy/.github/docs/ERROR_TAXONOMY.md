# Error Taxonomy

Classification of errors the agent encounters, severity levels, and expected agent responses.

---

## Error Categories

| Category | Code | Severity | Agent Response |
|---|---|---|---|
| Configuration error | `config_error` | Medium | Auto-fix project settings |
| Source error | `source_error` | High | Acquire missing source or flag |
| Build error | `build_error` | Medium | Classify, fix, rebuild |
| Linker error | `linker_error` | Medium–High | Fix .icf, add missing objects |
| Debug error | `debug_error` | Medium | Reconfigure probe/session |
| Measurement error | `measurement_error` | High | Retry or flag as blocked |
| Fairness error | `fairness_error` | Critical | Block comparison until resolved |
| Validation error | `validation_error` | Low–Medium | Fix artifact or report |
| Internal error | `internal_error` | Critical | Report and stop |
| Schema error | `schema_error` | Low | Fix artifact format |

---

## Configuration Errors (`config_error`)

Errors in IAR project configuration.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `missing_include` | Include path not found | Add path to project settings |
| `wrong_device` | Device mismatch in .ewp | Correct device field |
| `missing_define` | Preprocessor define missing | Add to project defines |
| `wrong_linker_config` | .icf not matching target | Point to correct .icf file |
| `missing_startup` | Startup file not in project | Add vendor startup file |
| `optimization_mismatch` | Debug vs Release confusion | Set to specified level |

**Agent behavior:** Attempts auto-fix up to 3 times per error. If unresolved, marks stage as `blocked` and reports.

---

## Source Errors (`source_error`)

Missing or incorrect source files.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `file_not_found` | Referenced .c/.h doesn't exist | Acquire from vendor source |
| `wrong_version` | SDK version mismatch | Download correct version |
| `corrupt_download` | Incomplete file transfer | Re-download |
| `license_restricted` | Source requires login | Flag as blocked, inform user |
| `ambiguous_source` | Multiple candidates | Select best match, document |

**Agent behavior:** Attempts acquisition from `vendor_sources.yaml`. Falls back through preference order (workspace → local SDK → vendor GitHub → vendor website → mirror).

---

## Build Errors (`build_error`)

Compilation failures from iarbuild.exe.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `undeclared_identifier` | Function/variable not declared | Add include or forward declaration |
| `type_mismatch` | Wrong argument type | Fix type or add cast |
| `syntax_error` | C syntax violation | Fix source |
| `deprecated_api` | Old HAL function removed | Replace with current equivalent |
| `missing_header` | #include file not found | Add to include paths |
| `redefinition` | Symbol defined twice | Remove duplicate or guard |

**Agent behavior:** Parses error output via `normalize_build_log.py`, classifies, applies minimal fix, rebuilds. Maximum 5 rebuild attempts.

---

## Linker Errors (`linker_error`)

Link-time failures.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `undefined_symbol` | Function not defined anywhere | Add missing .c to project |
| `multiple_definition` | Same symbol in two objects | Remove duplicate source |
| `section_overflow` | Flash or RAM exceeded | Optimize or report as legitimate gap |
| `missing_section` | .icf references nonexistent section | Fix linker script |
| `wrong_entry` | Entry point doesn't match | Fix linker entry symbol |

**Agent behavior:** Analyzes `.map` file and linker output. For `undefined_symbol`, searches workspace for definition. For overflow, reports as measurement data (not error).

---

## Debug Errors (`debug_error`)

Debug session failures.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `probe_not_found` | Debug probe not connected | Inform user |
| `flash_failed` | Programming failed | Retry once, then block |
| `connection_lost` | Probe disconnected mid-session | Report, request retry |
| `wrong_probe_config` | Probe type mismatch | Fix cspybat arguments |
| `breakpoint_failed` | Breakpoint at invalid address | Fix breakpoint location |

**Agent behavior:** Debug errors involving hardware are reported to user. Software config errors are auto-fixed.

---

## Measurement Errors (`measurement_error`)

Measurement extraction failures.

| Sub-type | Example | Auto-fix |
|---|---|---|
| `no_data` | No measurement captured | Verify instrumentation, retry |
| `incomplete_data` | Partial measurement | Flag confidence as low |
| `out_of_range` | Value outside expected bounds | Flag as anomaly, include anyway |
| `format_error` | UART output doesn't parse | Fix parser or report format |
| `dwt_overflow` | Cycle counter wrapped | Use smaller measurement window |

**Agent behavior:** For `no_data`, checks if instrumentation is correct. For others, includes data with reduced confidence level.

---

## Fairness Errors (`fairness_error`)

Conditions that compromise fair comparison.

| Sub-type | Example | Resolution |
|---|---|---|
| `optimization_mismatch` | One platform at -Og, other at -Oh | Rebuild with same settings |
| `clock_undocumented` | Clock frequency not recorded | Add to fairness baseline |
| `scope_mismatch` | Measurement covers different code | Fix instrumentation placement |
| `wrapper_asymmetry` | Extra abstraction on one side | Document as fairness caveat |
| `missing_equivalence` | Semantic check not performed | Run equivalence check first |

**Agent behavior:** **BLOCKS comparison** until resolved. Fairness errors are never ignored or suppressed.

---

## Severity Levels

| Level | Meaning | Agent Action |
|---|---|---|
| `low` | Cosmetic or non-blocking | Fix if trivial, otherwise note |
| `medium` | Affects quality but not correctness | Auto-fix and continue |
| `high` | May affect results | Fix required before proceeding |
| `critical` | Results would be invalid | **Block stage**, report to user |

---

## Error Escalation

```
Attempt auto-fix (up to N retries)
    │
    ├── Fixed → Continue to next stage
    │
    └── Not fixed
        │
        ├── Severity ≤ medium → Continue with caveat
        │
        └── Severity ≥ high → Block stage
            │
            ├── Alternative approach exists → Try alternative
            │
            └── No alternative → Report to user as blocked
```

---

## Error Artifacts

When errors occur, the agent records them in `execution_status.yaml`:

```yaml
stages:
  - name: "build"
    status: "failed"
    attempts: 3
    errors:
      - category: "build_error"
        subtype: "undefined_symbol"
        message: "Error[Li005]: undefined symbol 'HAL_GPIO_Init'"
        file: "main.c"
        line: 42
        fix_attempted: "Added stm32u5xx_hal_gpio.c to project"
        fix_result: "resolved"
```
