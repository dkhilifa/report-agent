# Naming Conventions

Standard naming rules for campaigns, comparisons, targets, artifacts, and files.

---

## Campaign IDs

**Pattern:** `<benchmark>-<platform_a>-vs-<platform_b>`

**Rules:**
- Lowercase with hyphens
- Benchmark name first
- Platforms separated by `-vs-`
- MCU family abbreviation preferred over full part number

**Examples:**
```
freertos-taskswitch-stm32u5-vs-gd32e5
coremark-stm32h5-vs-nxp-rt1060
usb-hid-stm32u5-vs-renesas-ra6m4
```

---

## Comparison IDs

**Pattern:** `<campaign_id>-<date>` or `<campaign_id>` (when date is in manifest)

**Examples:**
```
freertos-taskswitch-stm32u5-vs-gd32e5-20240115
coremark-stm32h5-vs-nxp-rt1060
```

---

## Target Names

**Pattern:** `<vendor_prefix>_<mcu_family>_<board_short>`

**Rules:**
- Lowercase with underscores
- Vendor prefix: `stm32`, `gd32`, `nxp`, `renesas`, `infineon`, `ti`, `wch`, `espressif`
- MCU family abbreviated
- Board name shortened (drop "NUCLEO-", "EVK-", etc.)

**Examples:**
```
stm32_u575_nucleo
gd32_e507_eval
nxp_rt1060_evk
renesas_ra6m4_ek
```

---

## Artifact Filenames

### Dossier Artifacts (YAML)

**Pattern:** `<artifact_type>.yaml`

Fixed names from the schema set:
```
campaign_manifest.yaml
execution_status.yaml
scenario_resolution.yaml
semantic_summary.yaml
source_provenance.yaml
measurement_metadata.yaml
comparison_delta.yaml
fairness_baseline.yaml
fairness_review.yaml
semantic_equivalence.yaml
hardware_approval.yaml
```

### Build Artifacts

**Pattern:** `<project_name>.<extension>`

```
project.ewp          # IAR project file
project.eww          # IAR workspace
project.out          # Built binary
project.map          # Linker map file
build_diagnostics.yaml  # Parsed build results
```

### Reports

**Pattern:** `benchmark_report.html` or `<campaign_id>_report.html`

```
benchmark_report.html    # Default report name
scenario.drawio          # Companion diagram
report_data.yaml         # Input data for generator
```

---

## Directory Names

### Under `benchmark/`

Fixed top-level directory names:
```
campaigns/
analysis/
ports/
build/
debug/
measurements/
comparisons/
enhancements/
validation/
reports/
```

### Subdirectory Pattern

`<top_level>/<campaign_id>/<target>/`

```
benchmark/build/freertos-taskswitch-stm32u5-vs-gd32e5/stm32_u575_nucleo/
benchmark/measurements/coremark-stm32h5-vs-nxp-rt1060/nxp_rt1060_evk/
```

---

## Source Files

### Ported Source

**Pattern:** Retain original filename, organize by target directory.

```
ports/<campaign_id>/<target>/src/main.c
ports/<campaign_id>/<target>/src/system_clock.c
ports/<campaign_id>/<target>/inc/main.h
```

### Vendor HAL/BSP

**Pattern:** Retain vendor naming, place in standard subdirectory.

```
ports/<campaign_id>/<target>/drivers/       # HAL drivers
ports/<campaign_id>/<target>/cmsis/         # CMSIS device headers
ports/<campaign_id>/<target>/startup/       # Startup files
```

---

## Prompt Files

**Pattern:** `NN_Description_In_Title_Case.prompt.md`

- Two-digit number prefix (01–99)
- Title case with underscores
- `.prompt.md` extension

```
01_Autonomous_Benchmark_From_Name.prompt.md
02_Port_Benchmark_To_Other_Board_Fairly.prompt.md
10_Build_From_Firmware_Name.prompt.md
```

---

## Config Files

**Pattern:** `<topic>.yaml`

- Lowercase with underscores
- Descriptive topic name
- YAML extension (not `.yml`)

```
boards.yaml
mcus.yaml
vendors.yaml
vendor_sources.yaml
toolchains.yaml
measurement_profiles.yaml
reporting.yaml
```

---

## Schema Files

**Pattern:** `<artifact_name>.schema.yaml`

- Matches the artifact filename it validates
- `.schema.yaml` double extension

```
campaign_manifest.schema.yaml
fairness_review.schema.yaml
```

---

## Agent and Skill Files

### Agents

**Pattern:** `<Name-With-Hyphens>.agent.md`

- Title case words separated by hyphens
- `.agent.md` extension
- `name` frontmatter must match filename (without extension)

```
MCU-Benchmark-Agent.agent.md
Creation-Porting.agent.md
Build-Project.agent.md
Debugger.agent.md
```

### Skills

**Pattern:** `skills/<name-with-hyphens>/SKILL.md`

- Folder name is the skill identifier
- Lowercase with hyphens
- Contains `SKILL.md` with matching `name` frontmatter

```
skills/benchmark-analysis/SKILL.md
skills/semantic-equivalence/SKILL.md
skills/stm32-enhancement/SKILL.md
```
