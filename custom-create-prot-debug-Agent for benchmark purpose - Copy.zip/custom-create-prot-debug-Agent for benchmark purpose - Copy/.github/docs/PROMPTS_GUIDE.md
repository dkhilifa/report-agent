# Prompts Guide

Complete reference for all 10 user-facing prompt templates.

---

## How Prompts Work

Prompts are pre-built conversation starters in `.github/prompts/`. They provide structured input to the agent system, ensuring optimal routing and context for each scenario type.

**To use:** Open the Copilot chat prompt picker, select a numbered prompt, fill in placeholders (marked with `{{...}}`), and send.

---

## Prompt 01: Autonomous Benchmark From Name

**File:** `prompts/01_Autonomous_Benchmark_From_Name.prompt.md`

**Use when:** You know only the benchmark or firmware name and want the agent to handle everything else.

**Inputs:**
- `{{benchmark_name}}` — e.g., "CoreMark", "FreeRTOS task-switch", "USB HID latency"
- `{{board}}` (optional) — target board; if omitted, agent selects from config

**Agent path:** MCU-Benchmark-Agent → scenario resolution → source acquisition → Creation-Porting → Build-Project → (hardware gate) → measurement → report

**Expected outputs:**
- Campaign manifest
- Source provenance records
- Built IAR project
- Measurement data (if hardware approved)
- Benchmark report

**Example:**
```
Benchmark the "Dhrystone" firmware on NUCLEO-H563ZI
```

---

## Prompt 02: Port Benchmark to Other Board Fairly

**File:** `prompts/02_Port_Benchmark_To_Other_Board_Fairly.prompt.md`

**Use when:** You have a working benchmark on one board and want a semantically equivalent port on another.

**Inputs:**
- `{{source_board}}` — board with the existing benchmark
- `{{target_board}}` — destination board
- `{{benchmark_path}}` (optional) — path to existing project; if omitted, agent searches workspace

**Agent path:** MCU-Benchmark-Agent → benchmark-analysis → Creation-Porting (semantic preservation) → Build-Project → semantic-equivalence verification

**Expected outputs:**
- Ported project (never modifies the reference)
- Semantic equivalence assessment
- Build artifacts for target
- Fairness baseline document

**Example:**
```
Port the FreeRTOS benchmark from NUCLEO-U575ZI to GD32E507V-EVAL fairly
```

---

## Prompt 03: Build, Debug, Measure Autonomously

**File:** `prompts/03_Build_Debug_Measure_Autonomously.prompt.md`

**Use when:** You have an existing project and want it built, debugged, and measured without manual steps.

**Inputs:**
- `{{project_path}}` — path to .ewp or project directory
- `{{measurement_method}}` (optional) — DWT, SysTick, UART, GPIO; defaults to DWT if available

**Agent path:** MCU-Benchmark-Agent → Build-Project → Debugger → measurement extraction

**Expected outputs:**
- Successful build with .map file
- Parsed footprint data
- Runtime measurements (requires hardware approval)
- Measurement metadata artifact

**Example:**
```
Build and measure benchmark/build/stm32u5_freertos/project.ewp using DWT cycle counter
```

---

## Prompt 04: Compare Two Boards Fairly

**File:** `prompts/04_Compare_Two_Boards_Fairly.prompt.md`

**Use when:** You have measurements (or projects) for two platforms and want a fair comparison.

**Inputs:**
- `{{platform_a}}` — first platform (board name or measurement path)
- `{{platform_b}}` — second platform
- `{{scenario}}` (optional) — benchmark scenario name for context

**Agent path:** MCU-Benchmark-Agent → result-interpretation → fairness review → report generation

**Expected outputs:**
- Comparison delta artifact
- Fairness review
- HTML comparison report with charts
- STM32-focused findings (if STM32 is involved)

**Example:**
```
Compare STM32U575 vs GD32E507 on USB HID benchmark fairly
```

---

## Prompt 05: Improve STM32 From Competitor Gap

**File:** `prompts/05_Improve_STM32_From_Competitor_Gap.prompt.md`

**Use when:** A comparison shows STM32 behind a competitor and you want actionable improvement recommendations.

**Inputs:**
- `{{comparison_path}}` — path to comparison results or report
- `{{gap_description}}` (optional) — specific area of concern (e.g., "flash footprint 15% larger")

**Agent path:** MCU-Benchmark-Agent → stm32-enhancement → recommendations with evidence

**Expected outputs:**
- Enhancement proposals with effort/risk/confidence
- Root cause analysis per gap area
- Concrete STM32 configuration or code recommendations

**Example:**
```
STM32U5 is 12% larger in flash than GD32E5 on FreeRTOS benchmark — recommend improvements
```

---

## Prompt 06: Create Benchmark From Scratch

**File:** `prompts/06_Create_Benchmark_From_Scratch.prompt.md`

**Use when:** You want to create a new benchmark that doesn't exist yet, given only a scenario description.

**Inputs:**
- `{{scenario_description}}` — what the benchmark should measure (e.g., "RTOS context switch latency")
- `{{platforms}}` — target platforms (e.g., "STM32U575 and GD32E507")
- `{{measurement_method}}` (optional) — preferred measurement approach

**Agent path:** MCU-Benchmark-Agent → scenario resolution → Creation-Porting (from scratch) → Build-Project

**Expected outputs:**
- New benchmark project for each platform
- Semantic summary defining observable behaviors
- Build artifacts
- Measurement instrumentation

**Example:**
```
Create a UART throughput benchmark for STM32H563 and Renesas RA6M4 measuring bytes/second at 115200 baud
```

---

## Prompt 07: Port STM32 to Competitor

**File:** `prompts/07_Port_STM32_To_Competitor.prompt.md`

**Use when:** You have an STM32 reference benchmark and want to create a competitor equivalent for comparison.

**Inputs:**
- `{{stm32_project}}` — path to STM32 reference project
- `{{competitor_board}}` — target competitor board
- `{{preserve_list}}` (optional) — specific behaviors to preserve

**Agent path:** MCU-Benchmark-Agent → benchmark-analysis → Creation-Porting (STM32→competitor) → semantic-equivalence

**Expected outputs:**
- Competitor port preserving all semantics
- Source provenance (competitor SDK)
- Semantic equivalence verification
- Build artifacts for competitor target

**Example:**
```
Port my STM32U5 CoreMark project to NXP MIMXRT1060-EVK
```

---

## Prompt 08: Port Competitor to STM32

**File:** `prompts/08_Port_Competitor_To_STM32.prompt.md`

**Use when:** You have a competitor benchmark and want to create an STM32 equivalent.

**Inputs:**
- `{{competitor_project}}` — path to competitor project or firmware name
- `{{stm32_board}}` — target STM32 board
- `{{acquire_source}}` (optional) — whether to download competitor SDK if not present

**Agent path:** MCU-Benchmark-Agent → source acquisition → benchmark-analysis → Creation-Porting (competitor→STM32) → Build-Project

**Expected outputs:**
- STM32 port preserving all semantics
- Source provenance for both sides
- Semantic equivalence verification
- Built STM32 project

**Example:**
```
Port the GD32E507 USB Device HID example to NUCLEO-U575ZI
```

---

## Prompt 09: Port Between Vendors

**File:** `prompts/09_Port_Between_Vendors.prompt.md`

**Use when:** You want to port a benchmark between two non-ST vendors (e.g., NXP → Infineon).

**Inputs:**
- `{{source_vendor}}` — source vendor and project
- `{{target_vendor}}` — target vendor and board
- `{{scenario}}` (optional) — benchmark scenario for context

**Agent path:** MCU-Benchmark-Agent → source acquisition (both sides) → benchmark-analysis → Creation-Porting → Build-Project

**Expected outputs:**
- Ported project for target vendor
- Semantic equivalence verification
- Build artifacts
- Fairness baseline

**Example:**
```
Port NXP i.MX RT1060 FreeRTOS demo to Infineon PSoC6 CY8CKIT-062-WIFI-BT
```

---

## Prompt 10: Build From Firmware Name

**File:** `prompts/10_Build_From_Firmware_Name.prompt.md`

**Use when:** You know only a firmware or SDK package name and want the agent to find, acquire, and build it.

**Inputs:**
- `{{firmware_name}}` — SDK package, firmware example, or middleware name
- `{{board}}` (optional) — target board; agent selects if omitted
- `{{vendor}}` (optional) — vendor hint to narrow search

**Agent path:** MCU-Benchmark-Agent → scenario resolution → source acquisition → Creation-Porting → Build-Project

**Expected outputs:**
- Source acquisition with provenance
- Working IAR project
- Successful build with .map file
- Footprint summary

**Example:**
```
Find and build "FreeRTOS_Queues" firmware for any STM32H5 board using IAR
```

---

## Prompt Selection Flowchart

```
Do you have existing measurements?
├── Yes → Prompt 04 (Compare) or Prompt 05 (Improve STM32)
└── No
    ├── Do you have existing projects?
    │   ├── Yes, need to build/measure → Prompt 03
    │   ├── Yes, need to port → Prompt 02, 07, 08, or 09
    │   └── No
    │       ├── Know a benchmark name → Prompt 01 or 10
    │       └── Know what to measure → Prompt 06 (From Scratch)
    └── Want STM32 improvements → Prompt 05
```
