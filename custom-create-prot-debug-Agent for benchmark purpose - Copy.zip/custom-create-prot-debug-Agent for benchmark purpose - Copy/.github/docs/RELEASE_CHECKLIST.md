# Release Checklist

Pre-release verification for the MCU Benchmark Agent system.

---

## Automated Checks

Run these before any release:

```powershell
# 1. Repository validation
py -3 tools/validate_benchmark_repo.py

# 2. Report generator smoke test
py -3 tools/generate_benchmark_report.py benchmark/sample-comparison/report_data.yaml

# 3. Verify HTML outputs exist and are non-empty
Test-Path MCU_Benchmark_Agent_Presentation.html
Test-Path MCU_Benchmark_Agent_Technical_Overview.html
```

---

## Manual Verification Checklist

### Configuration Integrity

- [ ] `config/boards.yaml` — all boards have valid vendor + MCU references
- [ ] `config/mcus.yaml` — all MCU families have valid vendor references
- [ ] `config/vendors.yaml` — no duplicate aliases across vendors
- [ ] `config/vendor_sources.yaml` — all URLs are reachable (spot-check 3)
- [ ] `config/toolchains.yaml` — IAR path matches local installation
- [ ] `config/measurement_profiles.yaml` — all methods have required fields
- [ ] `config/reporting.yaml` — theme colors and thresholds are valid

### Agent System

- [ ] All 4 agents load in VS Code (visible in chat `@` picker)
- [ ] Agent frontmatter: `name` matches filename slug
- [ ] Agent `tools:` lists use valid tool identifiers
- [ ] Agent `description:` is properly quoted (if contains colons)
- [ ] `copilot-instructions.md` — no syntax errors, loads as always-on

### Skills

- [ ] All 5 skill folders contain `SKILL.md`
- [ ] Each SKILL.md `name` matches its parent folder name exactly
- [ ] Skill descriptions contain trigger phrases
- [ ] Skill step workflows reference valid tools and artifacts

### Prompts

- [ ] All 10 prompts are accessible from VS Code prompt picker
- [ ] Prompts reference correct agents and workflows
- [ ] Placeholder variables are clearly marked with `{{...}}`
- [ ] No broken references to renamed files or moved content

### Schemas & Templates

- [ ] 11 schema files present in `schemas/benchmark/`
- [ ] 15 template files present in `templates/benchmark-dossier/`
- [ ] Templates have placeholder values for all required schema fields
- [ ] Schema `required` lists match template field presence

### Tools

- [ ] All 11 tool scripts present in `tools/`
- [ ] Python scripts run with `py -3` without import errors
- [ ] PowerShell scripts have valid syntax (`Test-ScriptSyntax` or manual check)
- [ ] `generate_benchmark_report.py` produces valid HTML from sample data
- [ ] `validate_benchmark_repo.py` exits 0 on clean repository

### Reports & Presentation

- [ ] `MCU_Benchmark_Agent_Presentation.html` opens in browser without errors
- [ ] `MCU_Benchmark_Agent_Technical_Overview.html` opens in browser without errors
- [ ] Sample report (`benchmark/sample-comparison/`) renders correctly
- [ ] All HTML files are self-contained (no external resource references)
- [ ] Print styles work (Ctrl+P shows readable output)

### Documentation

- [ ] `README.md` — repository structure matches actual filesystem
- [ ] `docs/QUICKSTART.md` — prerequisites are accurate
- [ ] `docs/PROMPTS_GUIDE.md` — all 10 prompts documented
- [ ] `docs/WORKFLOW_AND_ARTIFACTS.md` — 14 steps match agent behavior
- [ ] `docs/REPORTING_GUIDE.md` — sections match report generator output
- [ ] `docs/PORTING_GUIDE.md` — vendor notes are current
- [ ] `docs/VALIDATION_GUIDE.md` — check descriptions match script behavior
- [ ] `docs/NAMING_CONVENTIONS.md` — patterns match actual file names
- [ ] `docs/ERROR_TAXONOMY.md` — categories match agent error handling
- [ ] `docs/examples/` — all examples are syntactically valid

### End-to-End Smoke Test

- [ ] Invoke `@MCU-Benchmark-Agent` in chat — responds appropriately
- [ ] Try Prompt 01 with a known benchmark name — agent resolves scenario
- [ ] Try Prompt 04 with sample data — produces comparison output
- [ ] Agent delegates to Build-Project when build is needed
- [ ] Agent stops at hardware gate (step 10) without approval

---

## Release Artifacts

Final release package should contain:

```
.github/
├── copilot-instructions.md
├── README.md
├── MCU_Benchmark_Agent_Presentation.html
├── MCU_Benchmark_Agent_Technical_Overview.html
├── agents/ (4 files)
├── skills/ (5 folders)
├── prompts/ (10 files)
├── config/ (7 files)
├── schemas/benchmark/ (11 files)
├── templates/benchmark-dossier/ (15 files)
├── tools/ (11 files)
├── benchmark/ (10 subdirectories + sample-comparison)
└── docs/ (9 files + examples/)
```

**Total file count:** ~100+ files

---

## Version Tagging

When ready to release:

```powershell
git tag -a v1.0.0 -m "MCU Benchmark Agent v1.0.0 - Full release with documentation"
```

Versioning follows semver:
- **Major** — breaking changes to agent behavior or artifact format
- **Minor** — new features (boards, prompts, tools)
- **Patch** — fixes, documentation updates
