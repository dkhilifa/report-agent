# IAR Board Template Storage

This directory stores materialized IAR project templates per vendor and board.

## Structure

```
iar/
  <vendor>/
    <board-id>/
      template_manifest.yaml   — local state, acquisition status, file inventory
      provenance.yaml          — source tracking (URL, version, date, method)
      project/                 — materialized template files (.ewp, .eww, startup, linker, etc.)
```

## Rules

1. **Read-only baseline**: Template content is board firmware infrastructure. Do not modify.
2. **Application-layer integration only**: Benchmark logic goes through app entry points and user source groups.
3. **Provenance required**: Every template must have a `provenance.yaml` recording how it was obtained.
4. **No invented templates**: If no official IAR template exists, document the gap. Do not fabricate.
5. **Deterministic**: Same board ID always resolves to the same template content.

## Resolution

Templates are resolved via `.github/config/iar_templates.yaml` registry:
1. Exact board_id match
2. Family-level fallback (with device/linker adjustment)
3. Board-type fallback within same vendor
4. Unresolved (gap documented, no template used)

## Acquisition

Templates are acquired autonomously by the benchmark agent when `status: needs_download`:
1. Clone/download from `source_url` or `repo`
2. Extract relevant template path (`template_path_in_source`)
3. Place in `project/` subdirectory
4. Update `template_manifest.yaml` with file inventory
5. Record provenance in `provenance.yaml`
6. Update registry status to `available`

## Mutability Policy

| Surface | Modifiable? | Approval Required? |
|---------|-------------|-------------------|
| Application entry point (main.c / app.c) | Yes | No |
| User source groups | Yes | No |
| Startup file | No | Protected-surface deviation |
| Linker file | No | Protected-surface deviation |
| HAL/BSP source | No | Protected-surface deviation |
| Device/debugger config in .ewp | No | Protected-surface deviation |
| Include paths (additions only) | Yes | No |
| Preprocessor defines (additions only) | Yes | No |
